-- ============================================================
-- GALAPSY' — plateforme contributive
-- 1. Schéma
--
-- Les tables vivent dans un schéma privé « galapsy » que l'API
-- n'expose pas : personne ne peut lire ni écrire une table
-- directement. Tout passe par les fonctions du fichier 02, qui
-- vérifient l'identité, la charte, les sources et la modération.
-- ============================================================

create schema if not exists galapsy;
revoke all on schema galapsy from public;

-- Réglages modifiables sans toucher au code
create table if not exists galapsy.config (
  cle    text primary key,
  valeur text not null
);

-- Contributeurs (un profil = un compte qui a signé la charte)
create table if not exists galapsy.profils (
  id               uuid primary key references auth.users(id) on delete cascade,
  pseudo           text not null unique check (char_length(pseudo) between 3 and 40),
  role             text not null default 'contributeur'
                   check (role in ('contributeur','confirme','moderateur','admin')),
  charte_version   int  not null,
  charte_signee_le timestamptz not null default now(),
  suspendu         boolean not null default false,
  cree_le          timestamptz not null default now()
);

-- Tout ce qui compose l'atlas : galaxies, systèmes, planètes, lunes,
-- trous de ver et zones non cartographiées. « donnees » garde la
-- forme exacte qu'utilise l'interface (n, r, f, i, c, t, a, k…).
create table if not exists galapsy.objets (
  id        text primary key,
  type      text not null,
  parent    text references galapsy.objets(id),
  ordre     int  not null default 0,
  donnees   jsonb not null,
  statut    text not null check (statut in ('publie','en_attente','refuse','retire')),
  cree_par  uuid references galapsy.profils(id) on delete set null,
  cree_le   timestamptz not null default now(),
  maj_le    timestamptz not null default now()
);
-- types : l'atlas, plus les textes de présentation que les administrateurs peuvent modifier
alter table galapsy.objets drop constraint if exists objets_type_check;
alter table galapsy.objets add constraint objets_type_check
  check (type in ('galaxie','systeme','planete','lune','trou','zone','texte'));
create index if not exists objets_parent_idx on galapsy.objets(parent);
create index if not exists objets_statut_idx on galapsy.objets(statut);

-- Historique complet : chaque création, correction, retrait ou
-- restauration est une version, publiée ou en attente de relecture.
create table if not exists galapsy.revisions (
  id            uuid primary key default gen_random_uuid(),
  objet         text not null references galapsy.objets(id) on delete cascade,
  action        text not null check (action in ('creation','correction','restauration','retrait','republication')),
  donnees       jsonb not null,
  justification text,
  auteur        uuid references galapsy.profils(id) on delete set null,
  cree_le       timestamptz not null default now(),
  statut        text not null check (statut in ('en_attente','acceptee','refusee','annulee')),
  moderateur    uuid references galapsy.profils(id) on delete set null,
  modere_le     timestamptz,
  motif         text
);
create index if not exists revisions_objet_idx  on galapsy.revisions(objet, cree_le desc);
create index if not exists revisions_statut_idx on galapsy.revisions(statut);
create index if not exists revisions_auteur_idx on galapsy.revisions(auteur);

-- Invitations : une adresse désignée par un administrateur reçoit son rôle
-- dès que la personne crée son compte et signe la charte
create table if not exists galapsy.invitations (
  email   text primary key check (email = lower(email)),
  role    text not null check (role in ('moderateur','admin')),
  par     uuid references galapsy.profils(id) on delete set null,
  le      timestamptz not null default now()
);

-- Signalements des lecteurs inscrits
create table if not exists galapsy.signalements (
  id         uuid primary key default gen_random_uuid(),
  objet      text not null references galapsy.objets(id) on delete cascade,
  auteur     uuid references galapsy.profils(id) on delete set null,
  motif      text not null check (char_length(motif) between 10 and 1000),
  cree_le    timestamptz not null default now(),
  statut     text not null default 'ouvert' check (statut in ('ouvert','traite','rejete')),
  traite_par uuid references galapsy.profils(id) on delete set null,
  traite_le  timestamptz,
  note       text
);
create index if not exists signalements_statut_idx on galapsy.signalements(statut);

-- Défense en profondeur : sécurité ligne à ligne activée, aucune
-- règle d'accès direct. Seules les fonctions du fichier 02 lisent
-- et écrivent ces tables.
alter table galapsy.config       enable row level security;
alter table galapsy.profils      enable row level security;
alter table galapsy.objets       enable row level security;
alter table galapsy.revisions    enable row level security;
alter table galapsy.signalements enable row level security;
alter table galapsy.invitations  enable row level security;
revoke all on all tables in schema galapsy from public;

-- la source en lien qui accompagne chaque proposition (adresse web, DOI ou ISBN)
alter table galapsy.revisions add column if not exists source text;

insert into galapsy.config(cle, valeur) values
  ('charte_version', '1'),
  ('seuil_confirmation', '5'),   -- contributions validées avant le badge « confirmé »
  ('max_en_attente', '20'),      -- propositions en attente par contributeur
  ('mots_resume', '50'),         -- longueur des fiches, réglable par les administrateurs
  ('mots_niveau', '45')          -- fait établi, interprétation, controverse
on conflict (cle) do nothing;

-- ============================================================
-- GALAPSY' — plateforme contributive
-- 2. Règles et fonctions
--
-- Toute lecture et toute écriture passent par ces fonctions.
-- Le modèle :
--   · toute personne qui a signé la charte peut proposer une création
--     ou une modification, sur le modèle de Wikipédia ;
--   · chaque proposition comporte obligatoirement une source en lien
--     (adresse web, DOI ou ISBN) : sans lien, elle n'est pas reçue ;
--   · rien n'est publié avant qu'un administrateur (ou le fondateur)
--     ait vérifié la source et validé ; les publications des
--     administrateurs paraissent aussitôt ;
--   · les modérateurs traitent les signalements et peuvent retirer
--     en urgence un contenu publié ;
--   · chacun peut modifier ou retirer sa proposition tant qu'elle
--     n'a pas été examinée.
-- ============================================================

-- ---------- Outils internes (schéma privé) ----------

create or replace function galapsy.cfg(p_cle text) returns text
language sql stable set search_path = galapsy, pg_temp as $$
  select valeur from galapsy.config where cle = p_cle
$$;

-- Texte nettoyé et contrôlé : obligatoire, longueur min/max, nombre de mots
-- (les fiches restent courtes, comme dans le corpus fondateur)
drop function if exists galapsy.txt(jsonb, text, text, int, int, boolean);
create or replace function galapsy.txt(d jsonb, cle text, nom text, mini int, maxi int,
                                       requis boolean default true, mots int default null)
returns text language plpgsql immutable set search_path = galapsy, pg_temp as $$
declare v text; n int;
begin
  v := btrim(regexp_replace(coalesce(d ->> cle, ''), '[[:cntrl:]]+', ' ', 'g'));
  v := regexp_replace(v, '\s{2,}', ' ', 'g');
  if v = '' then
    if requis then raise exception 'Le champ « % » est obligatoire.', nom; end if;
    return null;
  end if;
  if char_length(v) < mini then
    raise exception 'Le champ « % » est trop court (% caractères minimum).', nom, mini;
  end if;
  if char_length(v) > maxi then
    raise exception 'Le champ « % » est trop long (% caractères maximum).', nom, maxi;
  end if;
  n := coalesce(array_length(regexp_split_to_array(v, '\s+'), 1), 0);
  if mots is not null and n > mots then
    raise exception 'Le champ « % » compte % mots ; la limite est de % mots, pour garder des fiches courtes.', nom, n, mots;
  end if;
  return v;
end $$;

-- Une source « en lien » : adresse web, DOI ou ISBN. Renvoie la forme normalisée, ou null.
create or replace function galapsy.lien(p text) returns text
language plpgsql immutable set search_path = galapsy, pg_temp as $$
declare v text := btrim(coalesce(p, '')); m text[]; isbn text;
begin
  if v ~* '^https?://[^\s/$.?#][^\s]*\.[^\s]{2,}' and v !~ '\s' then return v; end if;
  m := regexp_match(v, '(10\.\d{4,9}/\S+)');
  if m is not null then return 'https://doi.org/' || m[1]; end if;
  if v ~* 'isbn' or v ~ '^[0-9][0-9 -]{8,}[0-9Xx]$' then
    isbn := upper(regexp_replace(v, '[^0-9Xx]', '', 'g'));
    if char_length(isbn) in (10, 13) then return 'ISBN ' || isbn; end if;
  end if;
  return null;
end $$;

create or replace function galapsy.exiger_lien(p text, nom text) returns text
language plpgsql immutable set search_path = galapsy, pg_temp as $$
declare v text := galapsy.lien(p);
begin
  if v is null then
    raise exception '« % » doit être un lien vérifiable : une adresse web (https://…), un DOI (10.…) ou un ISBN. Sans lien, la proposition ne peut pas être reçue.', nom;
  end if;
  if char_length(v) > 500 then raise exception 'Le lien de la source est trop long (500 caractères maximum).'; end if;
  return v;
end $$;

-- Galaxie à laquelle appartient un objet
create or replace function galapsy.galaxie_de(p_id text) returns text
language sql stable set search_path = galapsy, pg_temp as $$
  with recursive c(id, type, parent) as (
    select id, type, parent from galapsy.objets where id = p_id
    union all
    select o.id, o.type, o.parent from galapsy.objets o join c on o.id = c.parent
  )
  select id from c where type = 'galaxie' limit 1
$$;

-- « Historique › L'aliénisme › Traitement moral »
create or replace function galapsy.chemin(p_id text) returns text
language sql stable set search_path = galapsy, pg_temp as $$
  with recursive c(id, parent, nom, niveau) as (
    select id, parent, coalesce(donnees->>'n', donnees->>'t', donnees->>'l', id), 0
      from galapsy.objets where id = p_id
    union all
    select o.id, o.parent, coalesce(o.donnees->>'n', o.donnees->>'t', o.donnees->>'l', o.id), c.niveau + 1
      from galapsy.objets o join c on o.id = c.parent
  )
  select string_agg(nom, ' › ' order by niveau desc) from c
$$;

create or replace function galapsy.moi() returns galapsy.profils
language sql stable set search_path = galapsy, pg_temp as $$
  select * from galapsy.profils where id = auth.uid()
$$;

-- le compte fondateur : celui dont l'adresse figure dans config.email_admin
create or replace function galapsy.est_proprietaire(p_id uuid) returns boolean
language sql stable set search_path = galapsy, pg_temp as $$
  select exists (select 1 from auth.users u where u.id = p_id
                  and lower(u.email) = lower(coalesce(galapsy.cfg('email_admin'), '')))
$$;

create or replace function galapsy.est_moderateur() returns boolean
language sql stable set search_path = galapsy, pg_temp as $$
  select exists (select 1 from galapsy.profils
                 where id = auth.uid() and role in ('moderateur','admin') and not suspendu)
$$;

create or replace function galapsy.exiger_contributeur() returns galapsy.profils
language plpgsql stable set search_path = galapsy, pg_temp as $$
declare p galapsy.profils;
begin
  if auth.uid() is null then
    raise exception 'Connectez-vous pour contribuer.';
  end if;
  select * into p from galapsy.profils where id = auth.uid();
  if not found then
    raise exception 'Signez la charte des contributeurs avant de contribuer.';
  end if;
  if p.suspendu then
    raise exception 'Votre compte contributeur est suspendu.';
  end if;
  if p.charte_version < galapsy.cfg('charte_version')::int then
    raise exception 'La charte a évolué : relisez-la et signez la nouvelle version.';
  end if;
  return p;
end $$;

create or replace function galapsy.exiger_moderateur() returns galapsy.profils
language plpgsql stable set search_path = galapsy, pg_temp as $$
declare p galapsy.profils;
begin
  p := galapsy.exiger_contributeur();
  if p.role not in ('moderateur','admin') then
    raise exception 'Réservé aux modérateurs.';
  end if;
  return p;
end $$;

create or replace function galapsy.exiger_admin() returns galapsy.profils
language plpgsql stable set search_path = galapsy, pg_temp as $$
declare p galapsy.profils;
begin
  p := galapsy.exiger_contributeur();
  if p.role <> 'admin' then
    raise exception 'Réservé aux administrateurs : ce sont eux qui vérifient les sources et publient.';
  end if;
  return p;
end $$;

create or replace function galapsy.nouvel_id(p_type text) returns text
language sql volatile set search_path = galapsy, pg_temp as $$
  select case p_type when 'galaxie' then 'g_' when 'systeme' then 's_' when 'planete' then 'p_'
                     when 'lune' then 'l_' when 'trou' then 't_' else 'x_' end
         || substr(md5(gen_random_uuid()::text), 1, 10)
$$;

-- Le parent doit exister, être publié et du bon type
create or replace function galapsy.verifier_parent(p_type text, p_parent text) returns void
language plpgsql stable set search_path = galapsy, pg_temp as $$
declare attendu text; o galapsy.objets;
begin
  if p_type = 'galaxie' then
    if p_parent is not null then raise exception 'Une galaxie n''a pas d''élément de rattachement.'; end if;
    return;
  end if;
  attendu := case p_type when 'systeme' then 'galaxie' when 'planete' then 'systeme'
                         when 'lune' then 'planete' when 'trou' then 'planete' end;
  if attendu is null then
    raise exception 'On ne peut pas créer ce type d''élément : %.', p_type;
  end if;
  select * into o from galapsy.objets where id = p_parent;
  if not found or o.statut <> 'publie' or o.type <> attendu then
    raise exception 'L''élément de rattachement est introuvable ou n''est pas encore publié.';
  end if;
end $$;

-- Contrôle et normalisation du contenu, selon le type.
-- p_ancien : données actuelles (correction) — on y conserve les
-- champs que les contributeurs ne modifient pas (teinte, supernova…).
create or replace function galapsy.valider(p_type text, d jsonb, p_parent text, p_ancien jsonb default null)
returns jsonb language plpgsql stable set search_path = galapsy, pg_temp as $$
declare v jsonb; s text; k text; cible galapsy.objets; sys_cible galapsy.objets;
begin
  if d is null or jsonb_typeof(d) <> 'object' then
    raise exception 'Contenu manquant.';
  end if;
  case p_type
  when 'galaxie' then
    v := jsonb_build_object(
      'n',  galapsy.txt(d,'n','Nom',2,60,true,4),
      's',  galapsy.txt(d,'s','Axe',2,80,true,6),
      'r',  galapsy.txt(d,'r','Présentation',20,900,true,30),
      'd',  galapsy.txt(d,'d','Définition',20,900,true,30),
      'th', galapsy.txt(d,'th','Hypothèse centrale',10,400,true,40));
    if p_ancien is null then
      -- nouvelle galaxie : une teinte aussi éloignée que possible des autres
      v := v || jsonb_build_object('hue', (
        select h from generate_series(0, 355, 5) h
         order by (select coalesce(min(least(abs(h - (o.donnees->>'hue')::int), 360 - abs(h - (o.donnees->>'hue')::int))), 180)
                     from galapsy.objets o where o.type = 'galaxie' and o.statut in ('publie','en_attente')) desc, h
         limit 1));
      if nullif(d->>'depuis_zone', '') is not null then
        if not exists (select 1 from galapsy.objets where id = d->>'depuis_zone' and type = 'zone' and statut = 'publie') then
          raise exception 'Cette zone n''existe plus ou a déjà été cartographiée.';
        end if;
        v := v || jsonb_build_object('depuis_zone', d->>'depuis_zone');
      end if;
    end if;
  when 'texte' then
    v := jsonb_build_object('v', btrim(regexp_replace(coalesce(d->>'v',''), '[\x00-\x08\x0B\x0C\x0E-\x1F]', '', 'g')));
    if char_length(v->>'v') < 1 then raise exception 'Le texte ne peut pas être vide.'; end if;
    if char_length(v->>'v') > 3000 then raise exception 'Le texte est trop long (3000 caractères maximum).'; end if;
  when 'zone' then
    v := jsonb_build_object(
      'n', galapsy.txt(d,'n','Nom',2,60,true,4),
      'd', galapsy.txt(d,'d','Ce que cette région contiendrait',20,900,true,30));
  when 'systeme' then
    v := jsonb_build_object(
      'n', galapsy.txt(d,'n','Nom',2,80,true,6),
      'r', galapsy.txt(d,'r','Présentation',20,700,true,25));
    s := galapsy.txt(d,'s','Repère (époque, auteur)',2,60,false,6);
    if s is not null then v := v || jsonb_build_object('s', s); end if;
  when 'planete' then
    v := jsonb_build_object(
      'n', galapsy.txt(d,'n','Nom de la notion',2,80,true,6),
      'r', galapsy.txt(d,'r','Résumé',20,1200,true,coalesce(galapsy.cfg('mots_resume')::int, 50)),
      'f', galapsy.txt(d,'f','Fait établi',20,1100,true,coalesce(galapsy.cfg('mots_niveau')::int, 45)),
      'i', galapsy.txt(d,'i','Interprétation',20,1100,true,coalesce(galapsy.cfg('mots_niveau')::int, 45)),
      'c', galapsy.txt(d,'c','Controverse',20,1100,true,coalesce(galapsy.cfg('mots_niveau')::int, 45)));
  when 'lune' then
    k := d ->> 'k';
    if k is null or k not in ('primaire','synthese','revue','donnees','essai','temoignage','droit') then
      raise exception 'Choisissez le statut de fiabilité de la source.';
    end if;
    v := jsonb_build_object(
      't',   galapsy.txt(d,'t','Titre',3,300,true,25),
      'a',   galapsy.txt(d,'a','Auteur·e·s et année',3,200,true,12),
      'ref', galapsy.exiger_lien(d->>'ref', 'Lien de la source'),
      'k',   k);
  when 'trou' then
    if p_ancien is not null then
      v := jsonb_build_object('cible', p_ancien->>'cible');
    else
      select * into cible from galapsy.objets where id = d->>'cible';
      if not found or cible.type <> 'planete' or cible.statut <> 'publie' then
        raise exception 'Choisissez la planète vers laquelle ouvrir le passage.';
      end if;
      select * into sys_cible from galapsy.objets where id = cible.parent;
      if sys_cible.donnees ? 'ne_de' then
        raise exception 'Les étoiles nées d''une supernova ne peuvent pas encore recevoir de trou de ver.';
      end if;
      if galapsy.galaxie_de(cible.id) = galapsy.galaxie_de(p_parent) then
        raise exception 'Un trou de ver relie deux galaxies différentes.';
      end if;
      v := jsonb_build_object('cible', cible.id);
    end if;
    v := v || jsonb_build_object('l', galapsy.txt(d,'l','Ce qui relie les deux notions',10,160,true,10));
  else
    raise exception 'Type inconnu : %.', p_type;
  end case;

  if p_ancien is not null then
    if p_type = 'galaxie' then v := v || jsonb_strip_nulls(jsonb_build_object('hue', p_ancien->'hue', 'depuis_zone', p_ancien->'depuis_zone')); end if;
    if p_type = 'systeme' then
      v := v || jsonb_strip_nulls(jsonb_build_object('nova', p_ancien->'nova', 'ne_de', p_ancien->'ne_de'));
    end if;
    if p_type = 'texte' then
      v := v || jsonb_strip_nulls(jsonb_build_object('cle', p_ancien->'cle', 'groupe', p_ancien->'groupe', 'libelle', p_ancien->'libelle'));
    end if;
  end if;
  return v;
end $$;

-- Passage au rang « confirmé » après N contributions acceptées par un modérateur
create or replace function galapsy.promouvoir_si_besoin(p_auteur uuid) returns void
language plpgsql volatile set search_path = galapsy, pg_temp as $$
begin
  update galapsy.profils set role = 'confirme'
   where id = p_auteur and role = 'contributeur'
     and (select count(*) from galapsy.revisions
           where auteur = p_auteur and statut = 'acceptee' and moderateur is not null
             and action in ('creation','correction'))
         >= galapsy.cfg('seuil_confirmation')::int;
end $$;

-- Quand une galaxie naît d'une zone non cartographiée, la zone disparaît de la frontière
create or replace function galapsy.cartographier_zone(p_galaxie text, p_par uuid) returns void
language plpgsql volatile set search_path = galapsy, pg_temp as $$
declare g galapsy.objets; z galapsy.objets;
begin
  select * into g from galapsy.objets where id = p_galaxie and type = 'galaxie';
  if not found or nullif(g.donnees->>'depuis_zone', '') is null then return; end if;
  select * into z from galapsy.objets where id = g.donnees->>'depuis_zone' and statut = 'publie' for update;
  if not found then return; end if;
  update galapsy.objets set statut = 'retire', maj_le = now() where id = z.id;
  insert into galapsy.revisions(objet, action, donnees, justification, auteur, statut, moderateur, modere_le)
  values (z.id, 'retrait', z.donnees, 'Zone cartographiée : elle est devenue la galaxie « ' || (g.donnees->>'n') || ' ».',
          p_par, 'acceptee', p_par, now());
end $$;

-- File à relire : les lunes créées avec leur planète sont relues avec elle
create or replace function galapsy.file_a_relire() returns setof galapsy.revisions
language sql stable set search_path = galapsy, pg_temp as $$
  select r.* from galapsy.revisions r join galapsy.objets o on o.id = r.objet
   where r.statut = 'en_attente'
     and not (o.type = 'lune' and r.action = 'creation' and exists (
           select 1 from galapsy.revisions rp join galapsy.objets op on op.id = rp.objet
            where op.id = o.parent and op.statut = 'en_attente' and rp.statut = 'en_attente'
              and rp.action = 'creation' and rp.auteur is not distinct from r.auteur))
$$;

-- ---------- Fonctions appelables depuis l'application ----------

-- Tout le contenu publié, en une fois (lecture libre, sans compte)
create or replace function public.galapsy_corpus() returns jsonb
language sql stable security definer set search_path = galapsy, pg_temp as $$
  select jsonb_build_object(
    'maj', (select max(maj_le) from galapsy.objets),
    'limites', jsonb_build_object('resume', coalesce(galapsy.cfg('mots_resume')::int, 50), 'niveau', coalesce(galapsy.cfg('mots_niveau')::int, 45)),
    'objets', coalesce((
      select jsonb_agg(jsonb_build_object(
               'id', o.id, 'type', o.type, 'parent', o.parent, 'ordre', o.ordre,
               'd', o.donnees, 'par', p.pseudo)
             order by o.ordre, o.cree_le, o.id)
        from galapsy.objets o left join galapsy.profils p on p.id = o.cree_par
       where o.statut = 'publie'), '[]'::jsonb))
$$;

-- Qui suis-je ? (null pour un visiteur)
create or replace function public.galapsy_profil() returns jsonb
language plpgsql stable security definer set search_path = galapsy, pg_temp as $$
declare p galapsy.profils; v_email text;
begin
  if auth.uid() is null then return null; end if;
  select email into v_email from auth.users where id = auth.uid();
  select * into p from galapsy.profils where id = auth.uid();
  return jsonb_build_object(
    'email', v_email,
    'charte_actuelle', galapsy.cfg('charte_version')::int,
    'seuil_confirmation', galapsy.cfg('seuil_confirmation')::int,
    'limites', jsonb_build_object('resume', coalesce(galapsy.cfg('mots_resume')::int, 50), 'niveau', coalesce(galapsy.cfg('mots_niveau')::int, 45)),
    'profil', case when p.id is null then null else jsonb_build_object(
        'pseudo', p.pseudo, 'role', p.role, 'charte_version', p.charte_version,
        'suspendu', p.suspendu, 'cree_le', p.cree_le, 'proprietaire', galapsy.est_proprietaire(p.id),
        'acceptees', (select count(*) from galapsy.revisions
                       where auteur = p.id and statut = 'acceptee'
                         and action in ('creation','correction')),
        'en_attente', (select count(*) from galapsy.revisions
                        where auteur = p.id and statut = 'en_attente')) end,
    'peut_valider', coalesce(p.role = 'admin' and not p.suspendu, false),
    'a_relire', case when p.role in ('moderateur','admin') and not p.suspendu then
        (select count(*) from galapsy.file_a_relire())
        + (select count(*) from galapsy.signalements where statut = 'ouvert') else null end);
end $$;

-- Signature (ou nouvelle signature) de la charte
create or replace function public.galapsy_signer_charte(p_pseudo text, p_version int) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare v_uid uuid := auth.uid(); v_pseudo text; v_email text; v_admin boolean;
begin
  if v_uid is null then raise exception 'Connectez-vous d''abord.'; end if;
  if p_version is distinct from galapsy.cfg('charte_version')::int then
    raise exception 'Cette version de la charte n''est plus la version en vigueur. Rechargez la page.';
  end if;
  if exists (select 1 from galapsy.profils where id = v_uid) then
    update galapsy.profils set charte_version = p_version, charte_signee_le = now() where id = v_uid;
    return public.galapsy_profil();
  end if;
  v_pseudo := btrim(regexp_replace(coalesce(p_pseudo,''), '\s+', ' ', 'g'));
  if v_pseudo !~ '^[[:alnum:]À-ÖØ-öø-ÿŒœ][[:alnum:]À-ÖØ-öø-ÿŒœ ._''-]{1,38}[[:alnum:]À-ÖØ-öø-ÿŒœ.]$' then
    raise exception 'Pseudonyme : 3 à 40 caractères (lettres, chiffres, espace, point, tiret, apostrophe).';
  end if;
  if exists (select 1 from galapsy.profils where lower(pseudo) = lower(v_pseudo)) then
    raise exception 'Ce pseudonyme est déjà pris.';
  end if;
  select email into v_email from auth.users where id = v_uid;
  v_admin := v_email is not null and lower(v_email) = lower(coalesce(galapsy.cfg('email_admin'), ''));
  insert into galapsy.profils(id, pseudo, role, charte_version)
  values (v_uid, v_pseudo,
          case when v_admin then 'admin'
               else coalesce((select role from galapsy.invitations where email = lower(v_email)), 'contributeur') end,
          p_version);
  delete from galapsy.invitations where email = lower(v_email);
  return public.galapsy_profil();
end $$;

-- Proposer une galaxie, une étoile, une planète (avec ses satellites), un satellite ou un trou de ver.
-- Une source en lien est obligatoire : celle des satellites pour une planète,
-- p_source pour les autres types.
drop function if exists public.galapsy_proposer(text, text, jsonb, text);
create or replace function public.galapsy_proposer(p_type text, p_parent text, p_donnees jsonb,
                                                   p_message text default null, p_source text default null)
returns jsonb language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare
  me galapsy.profils; v_d jsonb; v_id text; v_auto boolean; v_statut text; v_rev text;
  v_lunes jsonb := '[]'::jsonb; l jsonb; v_lid text; v_ordre int; v_msg text; v_source text;
begin
  me := galapsy.exiger_contributeur();
  perform galapsy.verifier_parent(p_type, p_parent);
  v_d := galapsy.valider(p_type, p_donnees, p_parent);
  v_msg := nullif(btrim(coalesce(p_message,'')), '');
  if v_msg is not null and char_length(v_msg) > 1000 then
    raise exception 'Le message aux administrateurs est trop long (1000 caractères maximum).';
  end if;
  if p_type = 'lune' then
    v_source := v_d->>'ref';
  elsif p_type = 'planete' then
    v_source := galapsy.lien(p_source);
  else
    v_source := galapsy.exiger_lien(p_source, 'Source de la proposition');
  end if;

  if p_type = 'planete' then
    if jsonb_typeof(p_donnees->'lunes') is distinct from 'array'
       or jsonb_array_length(p_donnees->'lunes') < 1 then
      raise exception 'Une planète doit avoir au moins un satellite, c''est-à-dire une source vérifiable.';
    end if;
    if jsonb_array_length(p_donnees->'lunes') > 12 then
      raise exception 'Une planète peut être créée avec douze satellites au plus ; les suivants pourront être ajoutés ensuite.';
    end if;
    for l in select * from jsonb_array_elements(p_donnees->'lunes') loop
      v_lunes := v_lunes || jsonb_build_array(galapsy.valider('lune', l, null));
    end loop;
  end if;

  if p_type = 'lune' and exists (
      select 1 from galapsy.objets where parent = p_parent and type = 'lune'
         and statut in ('publie','en_attente')
         and lower(donnees->>'t') = lower(v_d->>'t')) then
    raise exception 'Cette source est déjà un satellite de cette planète.';
  end if;
  if p_type = 'trou' and exists (
      select 1 from galapsy.objets where parent = p_parent and type = 'trou'
         and statut in ('publie','en_attente') and donnees->>'cible' = v_d->>'cible') then
    raise exception 'Ce passage existe déjà.';
  end if;

  if p_type = 'galaxie' then
    if exists (select 1 from galapsy.objets where type = 'galaxie' and statut in ('publie','en_attente')
                 and lower(donnees->>'n') = lower(v_d->>'n')) then
      raise exception 'Une galaxie porte déjà ce nom.';
    end if;
  end if;

  v_auto := me.role = 'admin';                -- seuls les administrateurs publient directement
  if not v_auto and (select count(*) from galapsy.revisions
                      where auteur = me.id and statut = 'en_attente')
                    >= galapsy.cfg('max_en_attente')::int then
    raise exception 'Vous avez déjà % propositions en attente de relecture. Merci de patienter.',
      galapsy.cfg('max_en_attente');
  end if;
  v_statut := case when v_auto then 'publie' else 'en_attente' end;

  select coalesce(max(ordre), 0) + 1 into v_ordre from galapsy.objets
   where parent is not distinct from p_parent and (p_parent is not null or type = p_type);
  v_id := galapsy.nouvel_id(p_type);
  insert into galapsy.objets(id, type, parent, ordre, donnees, statut, cree_par)
  values (v_id, p_type, p_parent, v_ordre, v_d, v_statut, me.id);
  insert into galapsy.revisions(objet, action, donnees, justification, auteur, statut, source)
  values (v_id, 'creation', v_d, v_msg, me.id, case when v_auto then 'acceptee' else 'en_attente' end, v_source)
  returning id::text into v_rev;

  v_ordre := 0;
  for l in select * from jsonb_array_elements(v_lunes) loop
    v_ordre := v_ordre + 1;
    v_lid := galapsy.nouvel_id('lune');
    insert into galapsy.objets(id, type, parent, ordre, donnees, statut, cree_par)
    values (v_lid, 'lune', v_id, v_ordre, l, v_statut, me.id);
    insert into galapsy.revisions(objet, action, donnees, auteur, statut, source)
    values (v_lid, 'creation', l, me.id, case when v_auto then 'acceptee' else 'en_attente' end, l->>'ref');
  end loop;
  if v_auto then perform galapsy.cartographier_zone(v_id, me.id); end if;

  return jsonb_build_object('id', v_id, 'statut', v_statut, 'revision', v_rev);
end $$;

-- Proposer une modification d'un élément publié : ce qui change, et la source en lien qui le justifie
drop function if exists public.galapsy_corriger(text, jsonb, text);
create or replace function public.galapsy_corriger(p_objet text, p_donnees jsonb, p_justification text, p_source text default null)
returns jsonb language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; o galapsy.objets; v_d jsonb; v_auto boolean; v_just text; v_source text;
begin
  me := galapsy.exiger_contributeur();
  select * into o from galapsy.objets where id = p_objet for update;
  if not found or o.statut <> 'publie' then
    raise exception 'Cet élément n''est pas publié : il ne peut pas être corrigé.';
  end if;
  v_just := btrim(regexp_replace(coalesce(p_justification,''), '[[:cntrl:]]+', ' ', 'g'));
  if o.type = 'texte' then
    if me.role <> 'admin' then raise exception 'Seuls les administrateurs modifient les textes du site.'; end if;
    if v_just = '' then v_just := 'Texte du site mis à jour'; end if;
  else
    if char_length(v_just) < 10 then
      raise exception 'Dites en une phrase ce que vous modifiez (10 caractères minimum).';
    end if;
    v_source := galapsy.exiger_lien(p_source, 'Source de la modification');
  end if;
  if char_length(v_just) > 1000 then
    raise exception 'La justification est trop longue (1000 caractères maximum).';
  end if;
  v_d := galapsy.valider(o.type, p_donnees, o.parent, o.donnees);
  if v_d = o.donnees then
    raise exception 'Aucune modification à enregistrer.';
  end if;
  if exists (select 1 from galapsy.revisions where objet = o.id and auteur = me.id
               and statut = 'en_attente' and action = 'correction') then
    raise exception 'Vous avez déjà une correction en attente sur cet élément.';
  end if;
  v_auto := me.role = 'admin';
  if not v_auto and (select count(*) from galapsy.revisions
                      where auteur = me.id and statut = 'en_attente')
                    >= galapsy.cfg('max_en_attente')::int then
    raise exception 'Vous avez déjà % propositions en attente de relecture. Merci de patienter.',
      galapsy.cfg('max_en_attente');
  end if;
  insert into galapsy.revisions(objet, action, donnees, justification, auteur, statut, source)
  values (o.id, 'correction', v_d, v_just, me.id, case when v_auto then 'acceptee' else 'en_attente' end, v_source);
  if v_auto then
    update galapsy.objets set donnees = v_d, maj_le = now() where id = o.id;
  end if;
  return jsonb_build_object('id', o.id, 'statut', case when v_auto then 'publie' else 'en_attente' end);
end $$;

-- Modifier sa proposition tant qu'elle n'a pas été examinée
create or replace function public.galapsy_modifier_proposition(p_revision uuid, p_donnees jsonb,
                                                               p_source text default null, p_message text default null)
returns jsonb language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; r galapsy.revisions; o galapsy.objets; v_d jsonb; v_source text; v_msg text;
begin
  me := galapsy.exiger_contributeur();
  select * into r from galapsy.revisions where id = p_revision for update;
  if not found or r.auteur is distinct from me.id then raise exception 'Proposition introuvable.'; end if;
  if r.statut <> 'en_attente' then
    raise exception 'Cette proposition a déjà été examinée : proposez plutôt une modification de l''élément publié.';
  end if;
  select * into o from galapsy.objets where id = r.objet for update;
  v_d := galapsy.valider(o.type, p_donnees, o.parent, case when r.action = 'correction' then o.donnees end);
  if o.type = 'lune' then v_source := v_d->>'ref';
  elsif o.type = 'planete' and r.action = 'creation' then v_source := coalesce(galapsy.lien(p_source), r.source);
  else v_source := galapsy.exiger_lien(p_source, 'Source de la proposition');
  end if;
  v_msg := nullif(btrim(coalesce(p_message, '')), '');
  if r.action = 'correction' and (v_msg is null or char_length(v_msg) < 10) then
    raise exception 'Dites en une phrase ce que vous modifiez (10 caractères minimum).';
  end if;
  update galapsy.revisions set donnees = v_d, source = v_source,
         justification = coalesce(v_msg, justification), cree_le = now()
   where id = r.id;
  if r.action = 'creation' then
    update galapsy.objets set donnees = v_d, maj_le = now() where id = o.id;
  end if;
  return jsonb_build_object('ok', true);
end $$;

-- Retirer sa proposition tant qu'elle n'a pas été examinée
create or replace function public.galapsy_annuler_proposition(p_revision uuid) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; r galapsy.revisions;
begin
  me := galapsy.exiger_contributeur();
  select * into r from galapsy.revisions where id = p_revision for update;
  if not found or r.auteur is distinct from me.id then raise exception 'Proposition introuvable.'; end if;
  if r.statut <> 'en_attente' then raise exception 'Cette proposition a déjà été examinée.'; end if;
  update galapsy.revisions set statut = 'annulee', modere_le = now(), motif = 'Retirée par son auteur' where id = r.id;
  if r.action = 'creation' then
    update galapsy.objets set statut = 'refuse', maj_le = now() where id = r.objet;
    update galapsy.revisions set statut = 'annulee', modere_le = now(), motif = 'Retirée par son auteur'
     where statut = 'en_attente' and action = 'creation'
       and objet in (select id from galapsy.objets where parent = r.objet and type = 'lune' and cree_par = me.id);
    update galapsy.objets set statut = 'refuse', maj_le = now()
     where parent = r.objet and type = 'lune' and statut = 'en_attente' and cree_par = me.id;
  end if;
  return jsonb_build_object('ok', true);
end $$;

-- Réglages de l'atlas (administrateurs) : longueur des fiches, propositions en attente
create or replace function public.galapsy_regler(p_cle text, p_valeur int) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils;
begin
  me := galapsy.exiger_admin();
  if p_cle = 'mots_resume' and p_valeur between 20 and 120 then null;
  elsif p_cle = 'mots_niveau' and p_valeur between 20 and 100 then null;
  elsif p_cle = 'max_en_attente' and p_valeur between 1 and 200 then null;
  else raise exception 'Réglage inconnu ou valeur hors limites.';
  end if;
  insert into galapsy.config(cle, valeur) values (p_cle, p_valeur::text)
  on conflict (cle) do update set valeur = excluded.valeur;
  return jsonb_build_object('ok', true);
end $$;

-- Signaler un contenu
create or replace function public.galapsy_signaler(p_objet text, p_motif text) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; v_motif text;
begin
  me := galapsy.exiger_contributeur();
  if not exists (select 1 from galapsy.objets where id = p_objet and statut = 'publie') then
    raise exception 'Élément introuvable.';
  end if;
  v_motif := btrim(regexp_replace(coalesce(p_motif,''), '[[:cntrl:]]+', ' ', 'g'));
  if char_length(v_motif) < 10 then
    raise exception 'Décrivez le problème en quelques mots (10 caractères minimum).';
  end if;
  if (select count(*) from galapsy.signalements where auteur = me.id and statut = 'ouvert') >= 10 then
    raise exception 'Vous avez déjà 10 signalements en cours d''examen.';
  end if;
  insert into galapsy.signalements(objet, auteur, motif) values (p_objet, me.id, left(v_motif, 1000));
  return jsonb_build_object('ok', true);
end $$;

-- Historique public d'un élément (versions acceptées) ;
-- l'auteur voit aussi ses propositions, les modérateurs voient tout.
create or replace function public.galapsy_historique(p_objet text) returns jsonb
language sql stable security definer set search_path = galapsy, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object(
      'id', r.id, 'action', r.action, 'date', r.cree_le, 'statut', r.statut,
      'auteur', coalesce(a.pseudo, case when r.auteur is null and r.justification = 'Corpus fondateur'
                                        then 'Corpus fondateur' else 'compte supprimé' end),
      'justification', r.justification, 'source', r.source,
      'moderateur', m.pseudo,
      'auto', (r.statut = 'acceptee' and r.moderateur is null and r.auteur is not null),
      'motif', case when r.auteur = auth.uid() or galapsy.est_moderateur() then r.motif end,
      'donnees', r.donnees)
    order by r.cree_le desc), '[]'::jsonb)
  from galapsy.revisions r
  left join galapsy.profils a on a.id = r.auteur
  left join galapsy.profils m on m.id = r.moderateur
  where r.objet = p_objet
    and (r.statut = 'acceptee' or (auth.uid() is not null and r.auteur = auth.uid())
         or galapsy.est_moderateur())
$$;

-- Mes contributions et leur sort
create or replace function public.galapsy_mes_contributions() returns jsonb
language plpgsql stable security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils;
begin
  me := galapsy.exiger_contributeur();
  return coalesce((select jsonb_agg(jsonb_build_object(
      'id', r.id, 'objet', r.objet, 'type', o.type, 'action', r.action, 'statut', r.statut,
      'objet_statut', o.statut, 'date', r.cree_le, 'motif', r.motif,
      'chemin', galapsy.chemin(o.id), 'auto', r.moderateur is null and r.statut = 'acceptee',
      'donnees', r.donnees, 'source', r.source, 'justification', r.justification,
      'modifiable', r.statut = 'en_attente')
    order by r.cree_le desc)
    from galapsy.revisions r join galapsy.objets o on o.id = r.objet
    where r.auteur = me.id), '[]'::jsonb);
end $$;

-- File de modération : propositions, signalements, publications récentes
create or replace function public.galapsy_file_moderation() returns jsonb
language plpgsql stable security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils;
begin
  me := galapsy.exiger_moderateur();
  return jsonb_build_object(
    'peut_valider', me.role = 'admin',
    'a_relire', coalesce((select jsonb_agg(jsonb_build_object(
        'id', r.id, 'objet', r.objet, 'type', o.type, 'action', r.action,
        'chemin', galapsy.chemin(o.parent), 'date', r.cree_le,
        'auteur', a.pseudo, 'auteur_role', a.role,
        'auteur_acceptees', (select count(*) from galapsy.revisions x
                              where x.auteur = r.auteur and x.statut = 'acceptee'),
        'auteur_refusees', (select count(*) from galapsy.revisions x
                             where x.auteur = r.auteur and x.statut = 'refusee'),
        'donnees', r.donnees,
        'actuel', case when r.action = 'correction' then o.donnees end,
        'cible', case when o.type = 'trou' then galapsy.chemin(r.donnees->>'cible') end,
        'justification', r.justification, 'source', r.source,
        'propre', r.auteur = me.id,
        'lunes', case when o.type = 'planete' and r.action = 'creation' then
           (select coalesce(jsonb_agg(c.donnees order by c.ordre), '[]'::jsonb)
              from galapsy.objets c where c.parent = o.id and c.type = 'lune'
               and c.statut = 'en_attente' and c.cree_par is not distinct from r.auteur) end)
      order by r.cree_le)
      from galapsy.file_a_relire() r
      join galapsy.objets o on o.id = r.objet
      left join galapsy.profils a on a.id = r.auteur
    ), '[]'::jsonb),
    'signalements', coalesce((select jsonb_agg(jsonb_build_object(
        'id', s.id, 'objet', s.objet, 'type', o.type, 'chemin', galapsy.chemin(o.id),
        'objet_statut', o.statut, 'motif', s.motif, 'date', s.cree_le, 'auteur', a.pseudo,
        'donnees', o.donnees)
      order by s.cree_le)
      from galapsy.signalements s join galapsy.objets o on o.id = s.objet
      left join galapsy.profils a on a.id = s.auteur
      where s.statut = 'ouvert'), '[]'::jsonb),
    'recents', coalesce((select jsonb_agg(x.j order by x.d desc) from (
        select jsonb_build_object(
          'id', r.id, 'objet', r.objet, 'type', o.type, 'action', r.action,
          'chemin', galapsy.chemin(o.id), 'date', r.cree_le, 'auteur', a.pseudo,
          'objet_statut', o.statut, 'justification', r.justification, 'source', r.source, 'donnees', r.donnees) j,
          r.cree_le d
        from galapsy.revisions r join galapsy.objets o on o.id = r.objet
        left join galapsy.profils a on a.id = r.auteur
        where r.statut = 'acceptee' and r.moderateur is null and r.auteur is not null
          and r.action in ('creation','correction')
          and r.cree_le > now() - interval '30 days'
        order by r.cree_le desc limit 60) x), '[]'::jsonb));
end $$;

-- Accepter ou refuser une proposition
create or replace function public.galapsy_moderer(p_revision uuid, p_decision text, p_motif text default null)
returns jsonb language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; r galapsy.revisions; o galapsy.objets; v_motif text;
begin
  me := galapsy.exiger_admin();
  select * into r from galapsy.revisions where id = p_revision for update;
  if not found then raise exception 'Proposition introuvable.'; end if;
  if r.statut <> 'en_attente' then raise exception 'Cette proposition a déjà été traitée.'; end if;
  select * into o from galapsy.objets where id = r.objet for update;
  v_motif := nullif(btrim(coalesce(p_motif,'')), '');

  if p_decision = 'accepter' then
    if r.action = 'creation' then
      if o.parent is not null and not exists (select 1 from galapsy.objets where id = o.parent and statut = 'publie') then
        raise exception 'L''élément de rattachement n''est plus publié.';
      end if;
      update galapsy.objets set statut = 'publie', donnees = r.donnees, maj_le = now() where id = o.id;
      perform galapsy.cartographier_zone(o.id, me.id);
      -- lunes proposées avec la planète
      update galapsy.revisions set statut = 'acceptee', moderateur = me.id, modere_le = now()
       where statut = 'en_attente' and action = 'creation'
         and objet in (select id from galapsy.objets where parent = o.id and type = 'lune'
                        and statut = 'en_attente' and cree_par is not distinct from r.auteur);
      update galapsy.objets set statut = 'publie', maj_le = now()
       where parent = o.id and type = 'lune' and statut = 'en_attente'
         and cree_par is not distinct from r.auteur;
    elsif r.action = 'correction' then
      if o.statut <> 'publie' then raise exception 'Cet élément n''est plus publié.'; end if;
      update galapsy.objets set donnees = r.donnees, maj_le = now() where id = o.id;
    end if;
    update galapsy.revisions set statut = 'acceptee', moderateur = me.id, modere_le = now(), motif = v_motif
     where id = r.id;
    if r.auteur is not null then perform galapsy.promouvoir_si_besoin(r.auteur); end if;
  elsif p_decision = 'refuser' then
    if v_motif is null or char_length(v_motif) < 5 then
      raise exception 'Indiquez au contributeur le motif du refus.';
    end if;
    update galapsy.revisions set statut = 'refusee', moderateur = me.id, modere_le = now(), motif = v_motif
     where id = r.id;
    if r.action = 'creation' then
      update galapsy.objets set statut = 'refuse', maj_le = now() where id = o.id;
      update galapsy.revisions set statut = 'refusee', moderateur = me.id, modere_le = now(),
             motif = 'Refusée avec sa planète : ' || v_motif
       where statut = 'en_attente' and action = 'creation'
         and objet in (select id from galapsy.objets where parent = o.id and type = 'lune'
                        and statut = 'en_attente' and cree_par is not distinct from r.auteur);
      update galapsy.objets set statut = 'refuse', maj_le = now()
       where parent = o.id and type = 'lune' and statut = 'en_attente'
         and cree_par is not distinct from r.auteur;
    end if;
  else
    raise exception 'Décision inconnue.';
  end if;
  return jsonb_build_object('ok', true);
end $$;

-- Revenir à une version antérieure (crée une nouvelle version)
create or replace function public.galapsy_restaurer(p_revision uuid) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; r galapsy.revisions; o galapsy.objets;
begin
  me := galapsy.exiger_admin();
  select * into r from galapsy.revisions where id = p_revision;
  if not found or r.statut <> 'acceptee' or r.action not in ('creation','correction','restauration') then
    raise exception 'Seule une version publiée peut être restaurée.';
  end if;
  select * into o from galapsy.objets where id = r.objet for update;
  if o.type = 'texte' and me.role <> 'admin' then raise exception 'Seuls les administrateurs modifient les textes du site.'; end if;
  if o.donnees = r.donnees then raise exception 'C''est déjà la version en ligne.'; end if;
  insert into galapsy.revisions(objet, action, donnees, justification, auteur, statut, moderateur, modere_le)
  values (o.id, 'restauration', r.donnees,
          'Retour à la version du ' || to_char(r.cree_le at time zone 'Europe/Paris', 'DD/MM/YYYY HH24:MI'),
          me.id, 'acceptee', me.id, now());
  update galapsy.objets set donnees = r.donnees, maj_le = now() where id = o.id;
  return jsonb_build_object('ok', true);
end $$;

-- Retirer un élément publié (il reste dans l'historique)
create or replace function public.galapsy_retirer(p_objet text, p_motif text) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; o galapsy.objets; v_motif text;
begin
  me := galapsy.exiger_moderateur();
  select * into o from galapsy.objets where id = p_objet for update;
  if not found or o.statut <> 'publie' then raise exception 'Élément introuvable ou déjà retiré.'; end if;
  if o.type in ('galaxie','zone','texte') then
    raise exception 'Les galaxies, les zones et les textes du site ne se retirent pas ; corrigez-les plutôt.';
  end if;
  v_motif := btrim(coalesce(p_motif,''));
  if char_length(v_motif) < 5 then raise exception 'Indiquez le motif du retrait.'; end if;
  update galapsy.objets set statut = 'retire', maj_le = now() where id = o.id;
  insert into galapsy.revisions(objet, action, donnees, justification, auteur, statut, moderateur, modere_le)
  values (o.id, 'retrait', o.donnees, v_motif, me.id, 'acceptee', me.id, now());
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.galapsy_republier(p_objet text) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; o galapsy.objets;
begin
  me := galapsy.exiger_moderateur();
  select * into o from galapsy.objets where id = p_objet for update;
  if not found or o.statut <> 'retire' then raise exception 'Cet élément n''est pas retiré.'; end if;
  update galapsy.objets set statut = 'publie', maj_le = now() where id = o.id;
  insert into galapsy.revisions(objet, action, donnees, justification, auteur, statut, moderateur, modere_le)
  values (o.id, 'republication', o.donnees, 'Remis en ligne', me.id, 'acceptee', me.id, now());
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.galapsy_traiter_signalement(p_id uuid, p_decision text, p_note text default null)
returns jsonb language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils;
begin
  me := galapsy.exiger_moderateur();
  if p_decision not in ('traite','rejete') then raise exception 'Décision inconnue.'; end if;
  update galapsy.signalements set statut = p_decision, traite_par = me.id, traite_le = now(),
         note = nullif(btrim(coalesce(p_note,'')), '')
   where id = p_id and statut = 'ouvert';
  if not found then raise exception 'Signalement introuvable ou déjà traité.'; end if;
  return jsonb_build_object('ok', true);
end $$;

-- Membres et rôles (administrateur)
create or replace function public.galapsy_membres() returns jsonb
language plpgsql stable security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils;
begin
  me := galapsy.exiger_moderateur();
  return coalesce((select jsonb_agg(jsonb_build_object(
      'pseudo', p.pseudo, 'role', p.role, 'suspendu', p.suspendu, 'cree_le', p.cree_le,
      'proprietaire', galapsy.est_proprietaire(p.id), 'moi', p.id = me.id,
      'acceptees', (select count(*) from galapsy.revisions r where r.auteur = p.id and r.statut = 'acceptee'
                      and r.action in ('creation','correction')),
      'refusees', (select count(*) from galapsy.revisions r where r.auteur = p.id and r.statut = 'refusee'))
    order by p.cree_le desc) from galapsy.profils p), '[]'::jsonb);
end $$;

create or replace function public.galapsy_definir_role(p_pseudo text, p_role text, p_suspendu boolean default null)
returns jsonb language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; cible galapsy.profils;
begin
  me := galapsy.exiger_moderateur();
  if me.role <> 'admin' then raise exception 'Réservé à l''administrateur.'; end if;
  select * into cible from galapsy.profils where pseudo = p_pseudo for update;
  if not found then raise exception 'Membre introuvable.'; end if;
  if cible.id = me.id then raise exception 'Vous ne pouvez pas modifier votre propre rôle.'; end if;
  if galapsy.est_proprietaire(cible.id) then raise exception 'Le compte fondateur ne peut pas être modifié.'; end if;
  if p_role not in ('contributeur','confirme','moderateur','admin') then raise exception 'Rôle inconnu.'; end if;
  if (p_role = 'admin' or cible.role = 'admin') and not galapsy.est_proprietaire(me.id) then
    raise exception 'Seul le fondateur nomme ou retire les administrateurs.';
  end if;
  update galapsy.profils set role = p_role, suspendu = coalesce(p_suspendu, suspendu) where id = cible.id;
  return jsonb_build_object('ok', true);
end $$;

-- Nommer un modérateur ou un administrateur par son adresse e-mail
create or replace function public.galapsy_inviter(p_email text, p_role text) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils; v_email text; v_uid uuid;
begin
  me := galapsy.exiger_moderateur();
  if me.role <> 'admin' then raise exception 'Réservé aux administrateurs.'; end if;
  v_email := lower(btrim(coalesce(p_email,'')));
  if v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]{2,}$' then raise exception 'Adresse e-mail invalide.'; end if;
  if p_role not in ('moderateur','admin') then raise exception 'Rôle inconnu.'; end if;
  if p_role = 'admin' and not galapsy.est_proprietaire(me.id) then
    raise exception 'Seul le fondateur nomme les administrateurs.';
  end if;
  select u.id into v_uid from auth.users u join galapsy.profils p on p.id = u.id where lower(u.email) = v_email;
  if v_uid is not null then
    if v_uid = me.id then raise exception 'Vous ne pouvez pas modifier votre propre rôle.'; end if;
    if galapsy.est_proprietaire(v_uid) then raise exception 'Le compte fondateur ne peut pas être modifié.'; end if;
    if (select role from galapsy.profils where id = v_uid) = 'admin' and not galapsy.est_proprietaire(me.id) then
      raise exception 'Seul le fondateur nomme ou retire les administrateurs.';
    end if;
    update galapsy.profils set role = p_role where id = v_uid;
    return jsonb_build_object('statut', 'nomme', 'pseudo', (select pseudo from galapsy.profils where id = v_uid));
  end if;
  insert into galapsy.invitations(email, role, par) values (v_email, p_role, me.id)
  on conflict (email) do update set role = excluded.role, par = excluded.par, le = now();
  return jsonb_build_object('statut', 'invite');
end $$;

create or replace function public.galapsy_invitations() returns jsonb
language plpgsql stable security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils;
begin
  me := galapsy.exiger_moderateur();
  if me.role <> 'admin' then raise exception 'Réservé aux administrateurs.'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('email', i.email, 'role', i.role, 'le', i.le, 'par', p.pseudo) order by i.le desc)
                     from galapsy.invitations i left join galapsy.profils p on p.id = i.par), '[]'::jsonb);
end $$;

create or replace function public.galapsy_annuler_invitation(p_email text) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare me galapsy.profils;
begin
  me := galapsy.exiger_moderateur();
  if me.role <> 'admin' then raise exception 'Réservé aux administrateurs.'; end if;
  delete from galapsy.invitations where email = lower(btrim(p_email));
  return jsonb_build_object('ok', true);
end $$;

-- ---------- Suppression de son propre compte ----------
-- Exigée par Google Play et par le RGPD. Les propositions en attente sont retirées ;
-- les contributions déjà publiées restent dans l'atlas, sans nom d'auteur :
-- comme sur Wikipédia, elles font désormais partie du savoir partagé.
create or replace function public.galapsy_supprimer_compte(p_confirmation text) returns jsonb
language plpgsql volatile security definer set search_path = galapsy, pg_temp as $$
declare v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'Connectez-vous pour supprimer votre compte.'; end if;
  if upper(btrim(coalesce(p_confirmation, ''))) <> 'SUPPRIMER' then
    raise exception 'Pour confirmer, écrivez le mot SUPPRIMER.';
  end if;
  if galapsy.est_proprietaire(v_uid) then
    raise exception 'Le compte fondateur ne peut pas être supprimé depuis l''application.';
  end if;
  update galapsy.revisions set statut = 'annulee', modere_le = now(), motif = 'Compte supprimé par son titulaire'
   where auteur = v_uid and statut = 'en_attente';
  update galapsy.objets set statut = 'refuse', maj_le = now() where cree_par = v_uid and statut = 'en_attente';
  delete from galapsy.invitations where email = (select lower(u.email) from auth.users u where u.id = v_uid);
  -- le profil disparaît avec le compte ; les traces publiques perdent leur nom d'auteur
  delete from auth.users where id = v_uid;
  return jsonb_build_object('ok', true);
end $$;

-- ---------- Droits d'exécution ----------
revoke execute on all functions in schema galapsy from public;

do $$
declare f record;
begin
  for f in select p.oid::regprocedure as sig, p.proname
             from pg_proc p join pg_namespace n on n.oid = p.pronamespace
            where n.nspname = 'public' and p.proname like 'galapsy\_%' loop
    execute format('revoke execute on function %s from public', f.sig);
    if exists (select 1 from pg_roles where rolname = 'anon') then
      execute format('revoke execute on function %s from anon', f.sig);
      execute format('revoke execute on function %s from authenticated', f.sig);
      if f.proname in ('galapsy_corpus','galapsy_profil','galapsy_historique') then
        execute format('grant execute on function %s to anon', f.sig);
      end if;
      execute format('grant execute on function %s to authenticated', f.sig);
    end if;
  end loop;
end $$;

-- ============================================================
-- GALAPSY' — plateforme contributive
-- 3. Corpus fondateur (état publié le 18/09/2026)
-- 282 éléments : 12 galaxie, 37 systeme, 79 planete, 109 lune, 39 trou, 6 zone
-- ============================================================
begin;
insert into galapsy.objets(id, type, parent, ordre, donnees, statut, cree_le, maj_le) values
  ('hist', 'galaxie', null, 1, '{"n":"Historique","s":"Généalogie des catégories","hue":36,"r":"Les troubles n''ont pas toujours existé sous leur nom actuel. Cette galaxie suit ce que chaque époque a pu voir, dire et enfermer.","d":"Étude de la formation des catégories psychiatriques dans le temps : quand un trouble est apparu, sous quel nom, dans quelles institutions, et ce qu''il est devenu.","th":"Les troubles psychiques sont aussi des catégories historiques : leurs noms, leurs frontières et leurs traitements naissent, se transforment et disparaissent avec les savoirs et les institutions de chaque époque."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('pheno', 'galaxie', null, 2, '{"n":"Phénoménologique","s":"L''expérience vécue","hue":268,"r":"Avant de classer, décrire. Cette galaxie demande ce que c''est que d''être, du dedans, la personne qui souffre.","d":"Description rigoureuse de l''expérience vécue telle qu''elle se donne, avant toute explication causale : comment le temps, l''espace, le corps et autrui apparaissent à la personne.","th":"Le trouble est d''abord une altération de l''expérience vécue : du rapport au temps, à l''espace, au corps et à autrui. Les symptômes observables n''en sont que l''expression seconde."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('epist', 'galaxie', null, 3, '{"n":"Épistémologique","s":"Qu''est-ce qu''un trouble ?","hue":202,"r":"La galaxie qui prend les autres pour objet : de quoi parle-t-on quand on dit qu''une chose est un trouble ?","d":"Examen critique des conditions de validité du savoir psychiatrique : ce qui compte comme trouble, comme preuve, comme classification, et selon quels critères.","th":"Toute explication du trouble repose sur une définition préalable du normal et du pathologique. C''est cette définition, ses critères et l''autorité qui l''établit qu''il faut d''abord examiner."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('psy', 'galaxie', null, 4, '{"n":"Psychodynamique","s":"Conflit, inconscient, structure","hue":335,"r":"Le symptôme veut dire quelque chose, et ce quelque chose n''est pas su de celui qui le porte.","d":"Approches issues de la psychanalyse : le psychisme est en conflit avec lui-même, et le symptôme est une formation de compromis interprétable dans la relation.","th":"Le symptôme est l''expression d''un conflit psychique en partie inconscient. Il a un sens, qui s''éclaire à la lumière de l''histoire singulière du sujet."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('neuro', 'galaxie', null, 5, '{"n":"Neurobiologique","s":"Circuits et molécules","hue":162,"r":"Chercher dans le cerveau la cause de ce qui se passe dans la vie — et découvrir que le chemin de retour est plus difficile que prévu.","d":"Recherche des substrats matériels des troubles : neurotransmetteurs, circuits, génétique, imagerie, et modèles computationnels du fonctionnement cérébral.","th":"La souffrance psychique a un substrat cérébral : elle s''explique par des altérations des circuits neuronaux et des neurotransmetteurs, sous l''influence conjointe de facteurs génétiques et environnementaux."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('cog', 'galaxie', null, 6, '{"n":"Cognitive","s":"Pensées, schémas, apprentissage","hue":22,"r":"Ce ne sont pas les événements qui déterminent l''humeur, mais leur traitement — hypothèse rendue testable, et testée.","d":"Étude du traitement de l''information — croyances, schémas, attention, mémoire, apprentissage — et des thérapies qui visent à le modifier de façon structurée.","th":"Le trouble est entretenu par des schémas de pensée, des modes de traitement de l''information et des comportements appris. Ce qui a été appris peut être modifié."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('soc', 'galaxie', null, 7, '{"n":"Sociale & politique","s":"Conditions de vie, pouvoir","hue":358,"r":"La souffrance psychique n''est pas distribuée au hasard dans la population. Cette galaxie demande pourquoi.","d":"Analyse des déterminants sociaux — précarité, discrimination, urbanicité, migration — et critique politique des institutions de soin et de leur pouvoir.","th":"La fréquence et les formes de la souffrance psychique dépendent des conditions de vie, des inégalités et des rapports de pouvoir : elle est socialement distribuée."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('anthro', 'galaxie', null, 8, '{"n":"Anthropologique","s":"Culture et transculturel","hue":96,"r":"La détresse s''exprime dans une langue. Cette galaxie compare les langues, et se méfie de celle qui se croit universelle.","d":"Comparaison des formes de détresse et de leurs remèdes entre cultures : ce qui compte comme trouble, qui le soigne, et ce que produit l''exportation des catégories occidentales.","th":"Chaque culture fournit les catégories, les idiomes de détresse et les dispositifs de soin à travers lesquels la souffrance s''exprime, se reconnaît et se traite."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('dev', 'galaxie', null, 9, '{"n":"Développementale","s":"Trajectoires et trauma","hue":296,"r":"Ce qui arrive tôt ne produit pas un trouble unique, mais infléchit une trajectoire entière.","d":"Étude des trajectoires de vie : attachement précoce, adversités et traumatismes de l''enfance, et la manière dont ils modulent le risque à l''âge adulte.","th":"Le trouble s''inscrit dans une trajectoire : il résulte de l''interaction, au fil du développement, entre vulnérabilités précoces, événements de vie et facteurs de protection."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('jur', 'galaxie', null, 10, '{"n":"Juridique","s":"Contrainte et responsabilité","hue":222,"r":"La seule spécialité médicale qui peut soigner sans consentement. Cette galaxie examine ce pouvoir.","d":"Cadres juridiques du soin psychique : contrainte et hospitalisation sans consentement, responsabilité pénale, capacité juridique et droits fondamentaux.","th":"Le droit ne dit pas d''où vient le trouble ; il fixe ce qui peut être imposé au nom du soin et les droits que la personne conserve : consentement, liberté, responsabilité."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('exp', 'galaxie', null, 11, '{"n":"Le rétablissement","s":"Se reconstruire avec le trouble","hue":44,"r":"Un trouble psychique n''est pas un destin. Se rétablir peut vouloir dire : moins de symptômes, une vie choisie, une place parmi les autres, des capacités retrouvées.","d":"Étude des chemins par lesquels une personne se reconstruit avec ou après un trouble psychique, sur les plans personnel, clinique, psychosocial et fonctionnel.","th":"On peut se rétablir sans guérir : le rétablissement ne se réduit pas à la disparition des symptômes. Il se joue aussi dans la reconstruction d''une vie choisie — identité, liens, place sociale — à laquelle contribue le savoir des personnes concernées."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('repr', 'galaxie', null, 12, '{"n":"Représentations","s":"Art, récit, image","hue":186,"r":"Comment la folie se donne à voir — et comment ces images reviennent dans la clinique.","d":"Étude des figures de la folie dans l''art, le récit autobiographique et l''image, et de leur effet en retour sur la clinique et sur la stigmatisation.","th":"Les représentations collectives de la folie, dans les arts, les médias et le langage, façonnent la stigmatisation, l''expérience des personnes concernées et les attentes des soignants."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02')
on conflict (id) do nothing;
insert into galapsy.objets(id, type, parent, ordre, donnees, statut, cree_le, maj_le) values
  ('f1', 'zone', null, 1, '{"n":"Addictions","d":"Usages, dépendance, sevrage, réduction des risques — et le débat, toujours ouvert, sur ce qui relève de la maladie, du choix ou de la contrainte sociale."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('f2', 'zone', null, 2, '{"n":"Enfance & adolescence","d":"Psychopathologie développementale, place de l''école, protection de l''enfance, et la question de ce qu''on peut diagnostiquer chez un sujet en construction."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('f3', 'zone', null, 3, '{"n":"Neurodiversité","d":"Autisme, TDAH, dys : des catégories cliniques devenues des identités revendiquées. La galaxie qui conteste le mot « trouble » lui-même."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('f4', 'zone', null, 4, '{"n":"Grand âge","d":"Démences, dépression tardive, isolement, fin de vie. Un continent entier, très peu relié aux autres galaxies de cet atlas."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('f5', 'zone', null, 5, '{"n":"Économie du soin","d":"Financement, industrie pharmaceutique, essais cliniques, accès aux soins : la matière noire qui structure tout le reste sans jamais être nommée."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('f6', 'zone', null, 6, '{"n":"Sens et spiritualités","d":"Rituels, communautés, quête de sens, pratiques non médicales du soin psychique — massives dans le monde, presque absentes des manuels."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02')
on conflict (id) do nothing;
insert into galapsy.objets(id, type, parent, ordre, donnees, statut, cree_le, maj_le) values
  ('alien', 'systeme', 'hist', 1, '{"n":"L''aliénisme","s":"1793 – 1838","r":"Le moment où la folie devient objet médical, et l''asile son instrument."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('krae', 'systeme', 'hist', 2, '{"n":"Le grand partage","s":"Kraepelin, 1899","r":"Deux grandes maladies, distinguées par leur évolution : le geste qui structure encore les manuels."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('hyst', 'systeme', 'hist', 3, '{"n":"L''hystérie","s":"Salpêtrière, 1870 – 1900","r":"Une maladie spectaculaire, massivement diagnostiquée, puis évanouie. Le cas d''école de l''instabilité des catégories.","nova":{"q":"Cette étoile est instable.","w":"L''hystérie disparaît des classifications en 1980, avec le DSM-III — sans que ce qu''elle désignait disparaisse. Son effondrement a projeté sa matière dans quatre directions, toutes vivantes aujourd''hui."}}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('tnf', 'systeme', 'hist', 120, '{"n":"Trouble fonctionnel","s":"né de l''implosion","r":"L''héritier neurologique : des symptômes réels, sans lésion, avec des marqueurs cliniques positifs.","ne_de":"hyst"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('disso', 'systeme', 'hist', 121, '{"n":"Dissociation","s":"né de l''implosion","r":"L''héritier de la part « amnésie, dédoublement, absences » — lignée Janet plutôt que Freud.","ne_de":"hyst"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('psom', 'systeme', 'hist', 122, '{"n":"Somatisation","s":"né de l''implosion","r":"L''héritier des plaintes corporelles durables, aujourd''hui « trouble à symptomatologie somatique ».","ne_de":"hyst"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('trau', 'systeme', 'hist', 123, '{"n":"Trauma","s":"né de l''implosion","r":"L''héritier étiologique : l''événement réel comme cause, réinstallé au centre.","ne_de":"hyst"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('melan', 'systeme', 'hist', 4, '{"n":"Mélancolie → dépression","s":"2400 ans","r":"La plus longue orbite de l''atlas : un même objet traversant l''humeur noire, le péché, l''âme et le neurotransmetteur."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('desinst', 'systeme', 'hist', 5, '{"n":"La fin de l''asile","s":"1952 – 1990","r":"Comment un dispositif vieux de 150 ans s''est démonté — inégalement, et sans que sa fonction disparaisse."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('temps', 'systeme', 'pheno', 1, '{"n":"Le temps vécu","s":"Minkowski, 1933","r":"Et si la structure élémentaire du trouble n''était pas un symptôme, mais un rapport au temps ?"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('dasein', 'systeme', 'pheno', 2, '{"n":"Daseinsanalyse","s":"Binswanger","r":"Appliquer l''analytique heideggérienne à la clinique : lire la maladie comme une forme de présence au monde."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('evid', 'systeme', 'pheno', 3, '{"n":"L''évidence naturelle","s":"Blankenburg, 1971","r":"Le cœur du trouble schizophrénique serait la perte de ce qui, pour tous, va de soi."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('corps', 'systeme', 'pheno', 4, '{"n":"Ipséité et corps vécu","s":"recherche contemporaine","r":"La phénoménologie revient dans la recherche empirique : on peut mesurer une anomalie de l''expérience de soi."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('canguil', 'systeme', 'epist', 1, '{"n":"Normal et pathologique","s":"Canguilhem, 1943","r":"Le pathologique n''est pas une quantité moindre de normal. C''est une autre norme."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('categ', 'systeme', 'epist', 2, '{"n":"Fabriquer des catégories","s":"Hacking","r":"Les catégories psychiatriques ne décrivent pas des espèces indifférentes : elles agissent sur ceux qu''elles nomment."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('dsm', 'systeme', 'epist', 3, '{"n":"Le DSM et ses critiques","s":"1972 → aujourd''hui","r":"Comment la psychiatrie a choisi la reproductibilité — et ce que ce choix a coûté."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('def', 'systeme', 'epist', 4, '{"n":"Définir le trouble","s":"philosophie analytique","r":"Trois réponses incompatibles à la question de ce qui fait qu''un état est un trouble."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('socepi', 'systeme', 'epist', 5, '{"n":"Épistémologie sociale","s":"Fricker, 2007","r":"Qui est reconnu comme sachant ? Cette approche examine comment le crédit accordé à une parole dépend du statut de celui qui parle."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('freud', 'systeme', 'psy', 1, '{"n":"L''inconscient freudien","s":"1895 – 1939","r":"Un appareil psychique en conflit avec lui-même, dont les productions sont déchiffrables."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('lacan', 'systeme', 'psy', 2, '{"n":"Retour à Freud","s":"Lacan","r":"L''inconscient structuré comme un langage, et une clinique des structures plutôt que des symptômes."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('objet', 'systeme', 'psy', 3, '{"n":"Relations d''objet","s":"Klein, Winnicott","r":"Le psychisme se construit dans le lien, pas dans la pulsion seule."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('attach', 'systeme', 'psy', 4, '{"n":"Attachement","s":"Bowlby → recherche","r":"La branche de la psychanalyse qui est passée à l''observation directe et a survécu au test empirique."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('mono', 'systeme', 'neuro', 1, '{"n":"Hypothèses monoaminergiques","s":"1960 – 2022","r":"Un demi-siècle de raisonnement à rebours : le médicament agit sur une molécule, donc la maladie vient de cette molécule.","nova":{"q":"Cette étoile est en fin de vie.","w":"Le raisonnement pharmacologique inversé — « le traitement touche X, donc le trouble est un déficit de X » — a été démonté. Son effondrement libère trois programmes de recherche qui n''auraient pas pu exister sous son régime."}}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('plast', 'systeme', 'neuro', 100, '{"n":"Plasticité","s":"né de l''implosion","r":"Ce ne serait pas le niveau d''un neurotransmetteur qui compte, mais la capacité du réseau à se remodeler.","ne_de":"mono"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('inflam', 'systeme', 'neuro', 101, '{"n":"Immuno-psychiatrie","s":"né de l''implosion","r":"Une part des dépressions s''accompagne de marqueurs inflammatoires élevés.","ne_de":"mono"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('critpharm', 'systeme', 'neuro', 102, '{"n":"Critique de l''inférence","s":"né de l''implosion","r":"Ce que l''effondrement enseigne sur la méthode elle-même.","ne_de":"mono"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('pred', 'systeme', 'neuro', 2, '{"n":"Cerveau prédictif","s":"modèle actif","r":"Percevoir n''est pas recevoir : c''est prédire, puis corriger. Les troubles seraient des déséquilibres de cette pondération."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('beck', 'systeme', 'cog', 1, '{"n":"Modèle cognitif","s":"Beck","r":"Des schémas acquis filtrent l''information et se confirment eux-mêmes."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('determ', 'systeme', 'soc', 1, '{"n":"Déterminants sociaux","s":"épidémiologie","r":"Les faits les plus robustes de la psychiatrie sont peut-être sociaux."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('culture', 'systeme', 'anthro', 1, '{"n":"Culture et folie","s":"ethnopsychiatrie","r":"Ce qui compte comme trouble, et ce qui en détermine l''issue, varie selon les mondes sociaux."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('trauma', 'systeme', 'dev', 1, '{"n":"Trauma","s":"1980 → aujourd''hui","r":"La catégorie la plus expansive de la psychiatrie contemporaine — un trou noir conceptuel qui attire tout."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('contr', 'systeme', 'jur', 1, '{"n":"Contrainte et capacité","s":"droit et clinique","r":"Trois textes qui ne disent pas la même chose du même sujet."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('perso', 'systeme', 'exp', 1, '{"n":"Rétablissement personnel","s":"Deegan, 1988 · Anthony, 1993","r":"Le rétablissement vu de l''intérieur : un cheminement singulier pour retrouver espoir, identité et pouvoir d''agir, que les symptômes persistent ou non."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('clin', 'systeme', 'exp', 2, '{"n":"Rétablissement clinique","s":"critères de rémission, 2005","r":"Le point de vue du soin : une réduction durable des symptômes, mesurée par des échelles et des critères de durée."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('psysoc', 'systeme', 'exp', 3, '{"n":"Rétablissement psychosocial","s":"réhabilitation, 1980 →","r":"Retrouver une place parmi les autres : logement, liens, rôles sociaux et citoyenneté, avec l''appui de pairs et de dispositifs adaptés."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('fonct', 'systeme', 'exp', 4, '{"n":"Rétablissement fonctionnel","s":"autonomie au quotidien","r":"Retrouver ses capacités dans la vie de tous les jours : prendre soin de soi, se loger, étudier, travailler, entretenir des relations."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('figurer', 'systeme', 'repr', 1, '{"n":"Figurer la folie","s":"1903 →","r":"Trois manières d''en produire une image : par le malade, par l''art, par l''écran."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02')
on conflict (id) do nothing;
insert into galapsy.objets(id, type, parent, ordre, donnees, statut, cree_le, maj_le) values
  ('moral', 'planete', 'alien', 1, '{"n":"Traitement moral","r":"Pinel soutient qu''on peut parler à l''aliéné : il lui reste une part de raison sur laquelle s''appuyer. L''asile devient un lieu de cure, pas seulement de garde.","f":"Pinel publie en 1801 un traité fondant une thérapeutique par la relation et le règlement de la vie quotidienne.","i":"Gladys Swain y lit l''acte de naissance du sujet : si l''on peut parler au fou, c''est qu''il n''est pas tout entier hors de la raison.","c":"Foucault lit le même geste à l''inverse : le traitement moral serait une contrainte intériorisée, plus efficace que les chaînes."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('alien.mono', 'planete', 'alien', 2, '{"n":"Monomanie","r":"Esquirol isole des délires partiels : on peut être fou sur un seul point et lucide partout ailleurs. La catégorie envahit les tribunaux, puis disparaît en une génération.","f":"Théorisée par Esquirol en 1838, la monomanie a presque disparu des nosographies vers 1870.","i":"Jan Goldstein y voit un outil de conquête : elle donne à l''aliéniste une compétence d''expert judiciaire.","c":"Catégorie éteinte, mais sa lumière voyage encore : les débats sur la responsabilité partielle en portent la trace."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('loi38', 'planete', 'alien', 3, '{"n":"La loi de 1838","r":"Le placement d''office et le placement volontaire entrent dans le droit français. L''asile devient une obligation départementale.","f":"Loi du 30 juin 1838 sur les aliénés : elle organisera l''internement en France pendant 152 ans.","i":"Le soin et la police se nouent dans un même texte, nœud que la psychiatrie n''a pas défait depuis.","c":"Abrogée en 1990, mais sa structure — décision médicale, contrôle administratif, recours judiciaire tardif — revient dans chaque réforme."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('dp', 'planete', 'krae', 1, '{"n":"Démence précoce","r":"Kraepelin regroupe catatonie, hébéphrénie et paranoïde sous une seule entité, définie non par ses symptômes mais par son issue : la détérioration.","f":"La 6ᵉ édition du manuel de Kraepelin (1899) oppose démence précoce et folie maniaco-dépressive selon le pronostic.","i":"Le critère devient temporel : ce n''est pas le tableau qui fait la maladie, c''est son destin.","c":"Le pronostic sombre était en partie un artefact de recrutement — Kraepelin voyait surtout les cas qui restaient à l''asile."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('schizo', 'planete', 'krae', 2, '{"n":"Schizophrénie","r":"Bleuler renomme et redéfinit : ce n''est pas une démence, et pas forcément précoce. Le trouble central est la dissociation des fonctions psychiques.","f":"Bleuler introduit le terme en 1908 et publie en 1911 ; il crée aussi le mot « autisme ».","i":"Le glissement du pronostic vers le mécanisme ouvre la porte à une psychopathologie, et à l''espoir thérapeutique.","c":"La validité de l''entité est contestée depuis : spectre continu, hétérogénéité massive, propositions de renommage."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('autisme', 'planete', 'krae', 3, '{"n":"Autisme","r":"Mot forgé par Bleuler pour le repli schizophrénique, repris trente ans plus tard par Kanner pour tout autre chose. Un même signifiant, deux objets.","f":"Bleuler, 1911 : retrait du monde chez l''adulte psychotique. Kanner, 1943 : trouble précoce du contact affectif chez l''enfant.","i":"L''histoire d''un mot n''est pas l''histoire d''une chose : la continuité lexicale masque une rupture conceptuelle.","c":"La filiation entre les deux usages est longtemps restée impensée, avec des conséquences cliniques durables."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('grande', 'planete', 'hyst', 1, '{"n":"Grande hystérie","r":"Charcot décrit une crise en quatre phases, réglée comme une partition, qu''il photographie et présente publiquement.","f":"Les Leçons du mardi (1887-88) fixent une sémiologie très codifiée de l''attaque hystérique.","i":"La régularité du tableau doit beaucoup au dispositif : les patientes apprenaient la forme attendue de leur crise.","c":"Les formes décrites par Charcot se sont raréfiées dès sa mort — argument central pour penser la plasticité culturelle des symptômes."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('conv', 'planete', 'hyst', 2, '{"n":"Conversion","r":"Freud et Breuer proposent un mécanisme : un affect qui ne peut être dit se traduit dans le corps. Le symptôme devient interprétable.","f":"Les Études sur l''hystérie paraissent en 1895.","i":"C''est la première fois qu''un symptôme somatique est traité comme un énoncé, porteur d''un sens à déchiffrer.","c":"L''hypothèse énergétique sous-jacente n''a jamais reçu de validation indépendante."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('sugg', 'planete', 'hyst', 3, '{"n":"Suggestion","r":"L''école de Nancy conteste Charcot : l''hypnose n''est pas un état pathologique réservé aux hystériques, c''est un effet de suggestion, présent chez tous.","f":"Bernheim publie De la suggestion en 1886 ; la controverse Nancy–Paris dure jusqu''aux années 1890.","i":"Nancy a gagné — et la question de ce que le dispositif d''observation produit chez l''observé ne l''a plus quittée.","c":"Le même débat se rejoue aujourd''hui autour des effets d''attente et de l''effet placebo en psychothérapie."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('hoover', 'planete', 'tnf', 1, '{"n":"Signes positifs","r":"Le diagnostic ne se fait plus par élimination mais par des signes propres — signe de Hoover, distractibilité du tremblement.","f":"Le DSM-5 reclasse la conversion en « trouble à symptomatologie neurologique fonctionnelle » et exige des signes d''incompatibilité interne.","i":"On passe d''un diagnostic de ce qui manque à un diagnostic de ce qui est là.","c":"La question du rôle du psychisme reste ouverte : le DSM-5 a retiré l''exigence d''un facteur psychologique déclenchant."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('janet', 'planete', 'disso', 1, '{"n":"Désagrégation psychologique","r":"Janet décrit un rétrécissement du champ de conscience laissant des fragments d''expérience hors de la synthèse personnelle.","f":"L''automatisme psychologique (1889) précède de six ans les Études sur l''hystérie.","i":"Une psychopathologie sans refoulement : ce n''est pas caché, c''est détaché.","c":"La lignée janétienne, éclipsée par Freud, a été réactivée par les recherches sur le trauma dans les années 1980."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('tss', 'planete', 'psom', 1, '{"n":"Symptômes somatiques","r":"Le critère s''est déplacé du corps vers le rapport au corps : ce ne sont plus les symptômes qui comptent, mais la détresse et le temps qu''on y consacre.","f":"Le DSM-5 abandonne le critère « médicalement inexpliqué ».","i":"Un trouble peut coexister avec une maladie organique — la frontière n''est plus une condition.","c":"Le risque de surinclusion a été largement discuté lors de la publication du DSM-5."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('retour', 'planete', 'trau', 1, '{"n":"Retour de l''événement","r":"Ce que Freud avait déplacé vers le fantasme revient comme fait : l''expérience traumatique est reconnue comme cause directe.","f":"Le TSPT entre dans le DSM-III en 1980.","i":"Une étiologie externe dans un manuel qui se voulait athéorique : l''exception dit la force du mouvement.","c":"Certains historiens y voient une catégorie autant politique que clinique."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('bile', 'planete', 'melan', 1, '{"n":"Bile noire","r":"Dans la médecine humorale, la mélancolie est un excès d''humeur noire — une affaire de tempérament et de régime, pas de biographie.","f":"Le corpus hippocratique, puis Galien, font de la bile noire la cause des états mélancoliques.","i":"Le modèle est déjà somatique et déjà dimensionnel : un tempérament peut virer à la maladie par excès.","c":"Aristote y ajoute une tout autre valeur : le mélancolique est aussi l''homme de génie."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('aced', 'planete', 'melan', 2, '{"n":"Acédie","r":"Chez les moines du désert, le dégoût, la torpeur et l''incapacité à tenir en place sont un combat spirituel, pas une maladie.","f":"Évagre le Pontique décrit au IVᵉ siècle le « démon de midi » qui fait paraître le jour interminable.","i":"Même phénoménologie, autre cadre d''imputation : ce qui est décrit est une épreuve, non un symptôme.","c":"L''acédie a été relue comme dépression par certains, comme catégorie irréductiblement théologique par d''autres."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('deuil', 'planete', 'melan', 3, '{"n":"Deuil et mélancolie","r":"Freud distingue les deux : dans le deuil c''est le monde qui s''appauvrit, dans la mélancolie c''est le moi. L''objet perdu a été incorporé, et les reproches qui lui étaient destinés frappent le sujet.","f":"Texte écrit en 1915, publié en 1917.","i":"L''autodépréciation cesse d''être un contenu absurde : elle devient adressée à quelqu''un d''autre.","c":"Modèle sans validation expérimentale, mais qui reste l''une des rares explications de la spécificité de la culpabilité mélancolique."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('edm', 'planete', 'melan', 4, '{"n":"Épisode dépressif majeur","r":"Le DSM-III fait de la dépression une liste de critères opérationnalisés, comptables, sans hypothèse causale. Le diagnostic devient reproductible.","f":"Le DSM-III (1980) définit l''épisode dépressif majeur par une humeur dépressive ou une perte d''intérêt, associée à au moins quatre symptômes sur huit, pendant au moins deux semaines.","i":"La fidélité inter-juges monte — mais la validité de l''entité reste une question distincte et non réglée.","c":"Ehrenberg y lit un fait social : la dépression devient la maladie d''une société qui exige de chacun d''être soi-même."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('neuro52', 'planete', 'desinst', 1, '{"n":"Chlorpromazine","r":"Le premier neuroleptique rend pensable la vie hors les murs. La condition chimique de la désinstitutionnalisation.","f":"Delay et Deniker publient sur la chlorpromazine en psychiatrie en 1952.","i":"L''ordre causal est discuté : le mouvement de sortie avait commencé avant, porté par des raisons politiques et économiques.","c":"Attribuer la fermeture des asiles au médicament est une simplification largement critiquée par les historiens."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('pi', 'planete', 'desinst', 2, '{"n":"Psychothérapie institutionnelle","r":"Si l''institution rend malade, il faut soigner l''institution elle-même. Le collectif devient l''outil.","f":"Née à Saint-Alban pendant l''Occupation autour de François Tosquelles, prolongée à La Borde par Jean Oury.","i":"Le soin n''est pas seulement dans l''entretien : il est dans l''organisation quotidienne, les rôles, la circulation de la parole.","c":"Peu évaluée par les méthodes standard, ce qui a nourri sa marginalisation autant que son aura."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('secteur', 'planete', 'desinst', 3, '{"n":"Le secteur","r":"Découper le territoire et rattacher chaque habitant à une équipe : soigner là où l''on vit, plutôt que déplacer vers l''asile.","f":"Circulaire du 15 mars 1960 instituant le secteur psychiatrique en France.","i":"Modèle d''une continuité des soins par équipe unique, largement imité à l''étranger.","c":"Sa mise en œuvre a été très inégale, et la réduction des lits a souvent devancé la création des structures d''aval."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('goff', 'planete', 'desinst', 4, '{"n":"Institution totale","r":"Goffman décrit l''asile comme une machine à produire le comportement qu''elle prétend constater : le patient apprend son rôle.","f":"Asylums paraît en 1961, à partir d''une enquête au St Elizabeths Hospital de Washington.","i":"Une partie de la symptomatologie chronique est un effet de l''institution, non de la maladie.","c":"La part respective de la maladie et de l''institution dans la chronicité reste débattue."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('vital', 'planete', 'temps', 1, '{"n":"Contact vital avec la réalité","r":"Ce qui manque au schizophrène n''est pas l''intelligence ni la perception, mais une adhérence spontanée au monde qui rend les choses évidentes.","f":"Minkowski forge la notion à partir de l''élan vital bergsonien, dans La schizophrénie (1927).","i":"Le trouble se situe en deçà des symptômes : c''est une modification du mode d''être, pas une collection de signes.","c":"Notion difficilement opérationnalisable — reproche adressé à toute la tradition, et repris depuis par les échelles d''expérience anormale de soi."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('blocage', 'planete', 'temps', 2, '{"n":"Blocage du futur","r":"Dans la mélancolie, l''avenir cesse de s''ouvrir. Le temps ne s''écoule plus vers quelque chose ; le passé prend toute la place et devient irréparable.","f":"Minkowski décrit chez un patient délirant un futur totalement obstrué par l''attente d''un supplice.","i":"La culpabilité mélancolique découle de la structure temporelle, et non l''inverse.","c":"Les descriptions restent qualitatives ; les travaux expérimentaux récents sur la perception du temps en dépression les recoupent partiellement."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('formes', 'planete', 'dasein', 1, '{"n":"Formes manquées de la présence","r":"Binswanger décrit trois manières dont l''existence se déséquilibre : l''exaltation qui monte trop haut, la bizarrerie qui dévie, le maniérisme qui se fige dans un rôle.","f":"Drei Formen missglückten Daseins (1956) : Verstiegenheit, Verschrobenheit, Manieriertheit.","i":"Chaque forme est une disproportion entre la hauteur des projets et la largeur de l''expérience.","c":"Vocabulaire difficilement traduisible, ce qui a limité la diffusion internationale de l''œuvre."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ellen', 'planete', 'dasein', 2, '{"n":"Le cas Ellen West","r":"Une patiente anorexique suivie des années, dont Binswanger publie l''histoire jusqu''au suicide qu''il décrit comme l''accomplissement de son existence.","f":"Étude publiée en 1944-45 ; la patiente quitte la clinique avec l''accord des médecins et met fin à ses jours.","i":"Texte majeur sur l''enfermement dans un idéal, et sur ce que la description phénoménologique donne à voir qu''une nosographie manque.","c":"Cas devenu un problème d''éthique clinique : la beauté de la description a-t-elle servi à justifier un renoncement au soin ?"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('perte', 'planete', 'evid', 1, '{"n":"Perte de l''évidence naturelle","r":"Une patiente explique qu''il lui manque quelque chose de tout petit et de si bête que personne ne peut le nommer : savoir comment on fait pour être une personne parmi les autres.","f":"Blankenburg publie en 1971 à partir du cas d''Anne Rau, schizophrénie pauci-symptomatique.","i":"Le sens commun n''est pas un savoir mais un arrière-plan ; son effondrement produit une perplexité que les échelles de symptômes ne captent pas.","c":"Peu de cas, aucune quantification — mais la notion a été reprise et opérationnalisée trente ans plus tard."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ipse', 'planete', 'corps', 1, '{"n":"Trouble de l''ipséité","r":"La schizophrénie serait un trouble du soi minimal : le sentiment d''être celui qui pense ses propres pensées se relâche, et l''expérience doit être re-rapportée à soi par un effort réflexif.","f":"Sass et Parnas formalisent le modèle hyperréflexivité / diminution de l''auto-affection en 2003.","i":"Cela relie sous un même principe des symptômes hétéroclites : pensées imposées, perplexité, déréalisation, automatisme mental.","c":"La spécificité à la schizophrénie est discutée — des anomalies proches sont décrites dans la dépersonnalisation et l''autisme."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('normativ', 'planete', 'canguil', 1, '{"n":"Normativité vitale","r":"Est en bonne santé le vivant capable d''instituer de nouvelles normes quand le milieu change. La maladie, c''est la réduction de cette marge de manœuvre.","f":"Thèse de médecine de 1943, augmentée en 1966.","i":"La santé devient une capacité, pas un état — ce qui déplace l''objectif du soin vers le pouvoir d''agir.","c":"Difficile à traduire en critères : comment mesurer une capacité normative ?"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('moins', 'planete', 'canguil', 2, '{"n":"Pas le normal en moins","r":"Une lésion ne produit pas un organisme amputé d''une fonction : elle produit un organisme réorganisé, qui fonctionne autrement.","f":"Canguilhem s''appuie sur la neurologie de Goldstein et les travaux sur les blessés de guerre.","i":"Le symptôme peut être une solution, pas seulement un déficit — principe repris par toute la clinique du rétablissement.","c":"Ce principe entre en tension avec les modèles déficitaires dominants en neuropsychologie."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('loop', 'planete', 'categ', 1, '{"n":"Effet de boucle","r":"Nommer un type de personne modifie la manière dont ces personnes se comprennent, donc leur comportement, donc la catégorie elle-même. Cible mouvante.","f":"Hacking formule l''effet de boucle des espèces humaines en 1995.","i":"Cela distingue radicalement les objets psychiatriques des objets des sciences naturelles : le quark ne lit pas l''article qui le classe.","c":"L''ampleur réelle de la boucle varie fortement d''une catégorie à l''autre et se mesure mal."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('transit', 'planete', 'categ', 2, '{"n":"Maladies mentales transitoires","r":"Certains tableaux n''apparaissent que dans une « niche écologique » précise — un moment, un lieu, un système de savoir — puis s''éteignent.","f":"Hacking analyse la fugue dissociative des voyageurs pathologiques dans la France de 1887-1909.","i":"Modèle explicatif direct pour la disparition de la grande hystérie, et grille de lecture pour les tableaux contemporains.","c":"La frontière entre mode diagnostique et émergence réelle d''une souffrance est très difficile à tracer."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('fid', 'planete', 'dsm', 1, '{"n":"Fidélité ≠ validité","r":"Le DSM-III résout un problème réel : deux cliniciens ne portaient pas le même diagnostic. Il le résout par des critères explicites — sans démontrer que les entités existent.","f":"Critères de Feighner en 1972, puis DSM-III en 1980 sous la direction de Robert Spitzer.","i":"On a acheté un accord entre observateurs ; la question de savoir ce qu''ils observent est restée ouverte.","c":"Comorbidité massive, hétérogénéité interne des catégories, usage très fréquent des diagnostics « non spécifiés » : autant de symptômes de ce report."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('rdoc', 'planete', 'dsm', 2, '{"n":"RDoC et HiTOP","r":"Deux tentatives de sortir des catégories : l''une par les circuits et les dimensions biologiques, l''autre par une hiérarchie statistique des symptômes.","f":"Le NIMH annonce en 2013 réorienter ses financements vers le cadre RDoC ; HiTOP est formalisé en 2017.","i":"Les deux abandonnent la catégorie comme unité d''analyse, mais pour des raisons opposées — biologie contre psychométrie.","c":"Aucun des deux n''a produit à ce jour de classification utilisable au chevet du patient."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('wake', 'planete', 'def', 1, '{"n":"Dysfonction préjudiciable","r":"Un trouble exige deux conditions : un mécanisme qui ne remplit pas la fonction pour laquelle il a été sélectionné, et un préjudice selon les valeurs du milieu.","f":"Wakefield formule l''analyse en 1992 dans American Psychologist.","i":"La définition combine délibérément un fait biologique et un jugement de valeur, au lieu de choisir.","c":"Elle suppose de connaître la fonction évolutive des mécanismes mentaux — ce qui est rarement le cas."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('szasz', 'planete', 'def', 2, '{"n":"Le mythe de la maladie mentale","r":"Szasz soutient qu''une maladie suppose une lésion corporelle ; à défaut, parler de maladie mentale est une métaphore qui sert à médicaliser des problèmes de vie.","f":"The Myth of Mental Illness paraît en 1961.","i":"L''argument a nourri toute la critique de la contrainte psychiatrique.","c":"Position très minoritaire en clinique, et contestée sur son point de départ : la définition lésionnelle de la maladie ne tient pas non plus en médecine somatique."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('reseau', 'planete', 'def', 3, '{"n":"Approche en réseau","r":"Et si le trouble n''était pas une cause commune derrière les symptômes, mais le réseau des symptômes eux-mêmes, qui s''entretiennent ? L''insomnie cause la fatigue qui cause la rumination.","f":"Borsboom formalise la théorie en réseau des troubles mentaux en 2017.","i":"L''entité disparaît comme chose ; il reste des états auto-entretenus, avec des seuils et des boucles.","c":"Solidité des réseaux estimés à partir de données transversales : question méthodologique encore vive."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('injust', 'planete', 'socepi', 1, '{"n":"Injustice épistémique","r":"On accorde moins de crédit à la parole d''une personne en raison de son diagnostic. Le préjudice n''est pas seulement social : il atteint sa capacité à être reconnue comme sujet de savoir.","f":"Miranda Fricker théorise l''injustice épistémique en 2007 ; Paul Crichton, Havi Carel et Ian James Kidd en développent l''application à la psychiatrie en 2017.","i":"Ce cadre donne une forme argumentée à une expérience très largement rapportée par les usagers des services de santé mentale.","c":"Sa mise en œuvre clinique reste délicate : comment accorder crédit à la parole d''une personne tout en évaluant, par exemple, un délire ?"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('refoul', 'planete', 'freud', 1, '{"n":"Refoulement","r":"Une représentation inacceptable est maintenue hors de la conscience, mais continue d''agir et revient déformée : lapsus, rêve, symptôme.","f":"Concept central dès 1895, retravaillé dans les textes métapsychologiques de 1915.","i":"Le symptôme devient une formation de compromis : il satisfait et interdit à la fois.","c":"La preuve expérimentale du refoulement au sens fort reste contestée ; les travaux sur l''oubli motivé n''en couvrent qu''une part."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('transf', 'planete', 'freud', 2, '{"n":"Transfert","r":"Le patient rejoue avec l''analyste des relations anciennes. Obstacle d''abord, puis reconnu comme l''outil central de la cure.","f":"Freud en fait le levier thérapeutique principal à partir de 1912.","i":"Le passé n''est pas raconté, il est répété dans la relation — donc modifiable là.","c":"La recherche contemporaine sur l''alliance thérapeutique en recoupe une partie, sans valider l''appareil théorique complet."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('miroir', 'planete', 'lacan', 1, '{"n":"Stade du miroir","r":"L''enfant s''identifie à une image de lui unifiée alors qu''il n''a pas encore cette unité. Le moi se fonde sur une méconnaissance.","f":"Communication de 1949 au congrès de Zurich.","i":"L''aliénation n''est pas un accident : elle est constitutive de la formation du moi.","c":"La chronologie développementale invoquée ne correspond pas aux données actuelles sur la reconnaissance de soi."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('forcl', 'planete', 'lacan', 2, '{"n":"Forclusion","r":"Dans la psychose, un signifiant fondamental n''a pas été intégré : il ne revient pas de l''intérieur comme un refoulé, il surgit du dehors, dans le réel — la voix, le regard.","f":"Développé dans le Séminaire III, Les psychoses (1955-1956).","i":"Cela donne une différence de structure, et non de degré, entre névrose et psychose.","c":"Modèle non falsifiable au sens empirique ; sa valeur est revendiquée comme orientation de la conduite de cure."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('depress', 'planete', 'objet', 1, '{"n":"Position dépressive","r":"Le moment où l''enfant reconnaît que la mère aimée et la mère haïe sont la même personne. Naissent alors la culpabilité et le souci de réparer.","f":"Klein formule la position dépressive en 1935.","i":"La capacité à l''ambivalence est un acquis développemental, pas un état de départ.","c":"Datation très précoce contestée par la psychologie du développement."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('trans', 'planete', 'objet', 2, '{"n":"Objet transitionnel","r":"Le doudou n''est ni tout à fait le bébé ni tout à fait le monde : il occupe une aire intermédiaire où l''illusion est permise, et d''où sortiront le jeu et la culture.","f":"Winnicott publie sur les objets et phénomènes transitionnels en 1953.","i":"Une zone d''expérience qui n''a pas à être tranchée entre subjectif et objectif — proposition étonnamment moderne.","c":"La généralisation à la culture entière relève de l''essai plus que de l''observation."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('base', 'planete', 'attach', 1, '{"n":"Base de sécurité","r":"L''enfant explore d''autant plus loin qu''il sait pouvoir revenir. La figure d''attachement n''est pas un frein à l''autonomie, elle en est la condition.","f":"Bowlby développe la théorie dans Attachment and Loss (1969-1980).","i":"Le besoin de lien est primaire, et non dérivé du besoin alimentaire.","c":"Rupture avec la psychanalyse de son temps, qui le marginalisa durablement."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('etrange', 'planete', 'attach', 2, '{"n":"Situation étrange","r":"Une procédure de vingt minutes qui rend observables des styles d''attachement stables — sécure, évitant, ambivalent, puis désorganisé.","f":"Ainsworth et al. publient les patterns en 1978 ; Main et Solomon ajoutent la catégorie désorganisée en 1990.","i":"Un concept psychodynamique traduit en protocole reproductible : cas rare et instructif.","c":"La validité transculturelle des proportions observées a été largement débattue."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('dopa', 'planete', 'mono', 1, '{"n":"Hypothèse dopaminergique","r":"Version III : le point commun des voies menant à la psychose serait un excès de dopamine présynaptique dans le striatum, qui attribue une importance anormale à des perceptions banales.","f":"Howes et Kapur reformulent l''hypothèse en 2009 sur la base de l''imagerie moléculaire.","i":"La notion de saillance aberrante fait le pont entre une anomalie de circuit et l''expérience délirante vécue.","c":"L''anomalie n''est ni nécessaire ni suffisante ; une part importante des patients n''y répond pas."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('sero', 'planete', 'mono', 2, '{"n":"Hypothèse sérotoninergique","r":"Le récit du déséquilibre chimique : la dépression viendrait d''un manque de sérotonine. Popularisé massivement, il n''a jamais été démontré.","f":"Une revue systématique de revues publiée en 2022 ne trouve pas de preuve convergente d''une association entre sérotonine et dépression.","i":"L''efficacité des ISRS ne dépend pas de la validité de ce modèle : un traitement peut marcher sans que l''explication soit la bonne.","c":"La publication a déclenché un débat public intense sur la différence entre mécanisme d''action et cause de la maladie."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('keta', 'planete', 'plast', 1, '{"n":"Action rapide","r":"La kétamine produit un effet antidépresseur en quelques heures, hors du système monoaminergique — argument décisif contre le modèle du déficit.","f":"L''eskétamine intranasale est autorisée par la FDA en 2019 pour la dépression résistante.","i":"Le décalage entre l''action moléculaire immédiate et l''effet clinique différé des ISRS devenait difficile à expliquer ; la plasticité offre une autre échelle de temps.","c":"Durabilité de l''effet, risque d''usage détourné et qualité de l''aveugle dans les essais restent discutés."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('crp', 'planete', 'inflam', 1, '{"n":"Inflammation","r":"Des taux élevés de CRP et d''IL-6 sont associés à certains profils dépressifs, notamment avec fatigue et ralentissement.","f":"Une méta-analyse de 2019 estime qu''environ un quart des personnes déprimées présentent une inflammation de bas grade, définie par une CRP supérieure à 3 mg/L (Osimo et al.).","i":"Cela suggère des sous-groupes biologiques plutôt qu''une maladie unique.","c":"L''association n''établit pas la direction causale, et les essais anti-inflammatoires donnent des résultats hétérogènes."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('exjuv', 'planete', 'critpharm', 1, '{"n":"L''inférence ex juvantibus","r":"Conclure de l''efficacité d''un traitement à la cause d''une maladie est un raisonnement invalide — l''aspirine soulage la migraine sans qu''il y ait déficit d''aspirine.","f":"L''argument est ancien, mais il n''a été appliqué systématiquement aux psychotropes que récemment.","i":"L''erreur a structuré la communication publique sur la dépression pendant trente ans.","c":"Certains cliniciens estiment que l''abandon du récit du déséquilibre chimique nuit à l''observance des traitements, qui restent efficaces indépendamment du modèle."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('prior', 'planete', 'pred', 1, '{"n":"Priors trop forts","r":"Si les attentes pèsent plus que le signal sensoriel, on perçoit ce qu''on attend : une hallucination devient une prédiction non corrigée.","f":"Powers, Mathys et Corlett montrent en 2017 que des sujets entendeurs de voix sont plus susceptibles d''halluciner un son conditionné.","i":"Un protocole expérimental qui rend une hallucination inductible en laboratoire, chez des sujets sains comme cliniques.","c":"La généralisation du modèle à l''ensemble de la psychopathologie va bien au-delà des données disponibles."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('triade', 'planete', 'beck', 1, '{"n":"Triade cognitive","r":"En dépression, trois biais convergent : vision négative de soi, du monde et de l''avenir. Chacun alimente les deux autres.","f":"Beck formule le modèle en 1967, puis publie le manuel de thérapie cognitive de la dépression en 1979.","i":"Le modèle rend le trouble accessible à une intervention structurée et brève, ce qui a permis son évaluation massive.","c":"L''efficacité est solidement établie ; la question de savoir si le changement passe réellement par les cognitions ciblées l''est beaucoup moins."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('rumi', 'planete', 'beck', 2, '{"n":"Ruminations","r":"Ce n''est pas seulement le contenu des pensées qui compte, mais le mode : ressasser le problème prolonge l''épisode au lieu de le résoudre.","f":"La théorie des styles de réponse (Nolen-Hoeksema, 1991) prédit la durée des épisodes dépressifs.","i":"Déplacement du contenu vers le processus, qui a ouvert la voie aux approches fondées sur l''attention.","c":"La distinction entre rumination et réflexion adaptative reste difficile à opérationnaliser."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('urb', 'planete', 'determ', 1, '{"n":"Urbanicité","r":"Grandir en milieu urbain dense est associé à un risque accru de psychose, selon un gradient dose-effet.","f":"Une méta-analyse de 2012 retrouve un risque environ doublé dans les environnements les plus urbains.","i":"Le gradient, la dépendance à la durée d''exposition dans l''enfance et la cohérence entre pays rendent une explication purement sélective peu probable.","c":"Le mécanisme reste inconnu : adversité sociale, fragmentation, pollution, sélection résiduelle sont tous discutés."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('migr', 'planete', 'determ', 2, '{"n":"Migration","r":"Le risque de psychose est élevé chez les migrants, et souvent plus encore à la deuxième génération.","f":"Méta-analyse de Cantor-Graae et Selten, 2005.","i":"Que la seconde génération soit plus touchée oriente vers l''expérience sociale — statut minoritaire, discrimination — plutôt que vers le voyage ou la sélection.","c":"Les biais de diagnostic selon l''origine, réels et documentés, expliquent une part de l''écart mais pas sa totalité."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('anti', 'planete', 'determ', 3, '{"n":"Antipsychiatrie","r":"Un courant hétérogène qui a placé la folie du côté du sens et de la protestation, et l''institution du côté de la violence.","f":"Laing publie The Divided Self en 1960 ; Basaglia obtient la loi 180 en Italie en 1978, qui interdit les nouvelles admissions en hôpital psychiatrique.","i":"L''expérience italienne reste l''expérimentation la plus radicale de démantèlement asilaire jamais conduite à l''échelle d''un pays.","c":"Ses résultats sont contrastés et très inégaux selon les régions ; le bilan reste un objet de controverse."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('idiom', 'planete', 'culture', 1, '{"n":"Idiomes de détresse","r":"Chaque culture fournit des formes disponibles pour dire et vivre la souffrance : possession, attaque de nerfs, épuisement, somatisation.","f":"Notion développée en anthropologie médicale à partir des années 1980.","i":"La forme n''est pas un habillage superficiel d''un noyau universel : elle organise l''expérience elle-même.","c":"La frontière entre variation d''expression et variation de l''objet lui-même reste théoriquement indécise."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('oms', 'planete', 'culture', 2, '{"n":"L''énigme du pronostic","r":"Les grandes études de l''OMS ont trouvé une évolution plus favorable de la schizophrénie dans les pays à faible revenu que dans les pays riches.","f":"Résultat rapporté par les études IPSS (1973) puis DOSMeD (1992).","i":"S''il tient, il indique que l''environnement social pèse lourdement sur l''évolution, et pas seulement sur le déclenchement.","c":"Fortement contesté depuis : différences d''échantillonnage, de définition de l''issue, perdus de vue. Le résultat n''est ni établi ni réfuté."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('export', 'planete', 'culture', 3, '{"n":"Exportation des catégories","r":"La diffusion mondiale des catégories occidentales modifie les formes locales de détresse qu''elle prétend seulement mesurer.","f":"Watters documente notamment l''introduction du TSPT au Sri Lanka après le tsunami de 2004.","i":"Application à grande échelle de l''effet de boucle : exporter la catégorie, c''est aussi exporter la manière de souffrir.","c":"L''ouvrage est un essai journalistique ; ses études de cas sont discutées mais ont nourri une littérature académique réelle."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('tspt', 'planete', 'trauma', 1, '{"n":"Naissance du TSPT","r":"Le TSPT entre dans le DSM-III porté par la mobilisation des vétérans du Vietnam et de leurs cliniciens.","f":"Inscrit au DSM-III en 1980.","i":"Un diagnostic dont la cause est un événement extérieur, dans un manuel qui se voulait sans hypothèse causale.","c":"Sa genèse militante est documentée et discutée : catégorie clinique, ou victoire politique consolidée en clinique ?"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ace', 'planete', 'trauma', 2, '{"n":"Expériences adverses","r":"Un score simple d''adversités de l''enfance prédit, à l''âge adulte, un risque accru de troubles psychiques et de maladies somatiques, selon un gradient.","f":"Felitti et al. publient en 1998 les premiers résultats de l''étude ACE, menée auprès de plus de 9 500 adultes.","i":"Le gradient dose-effet et l''ampleur des associations ont rendu l''adversité précoce impossible à écarter du raisonnement clinique.","c":"Étude rétrospective sur une population assurée ; le score agrège des expériences très hétérogènes et ne prédit rien à l''échelle individuelle."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('complexe', 'planete', 'trauma', 3, '{"n":"Trauma complexe","r":"Après une exposition prolongée et inéchappable, s''ajoutent au TSPT une dysrégulation émotionnelle, une altération de l''image de soi et des difficultés relationnelles durables.","f":"Herman propose le concept en 1992 ; la CIM-11 reconnaît le TSPT complexe comme diagnostic distinct.","i":"Reconnaissance que la durée et l''inéluctabilité de l''exposition changent la nature des séquelles, pas seulement leur intensité.","c":"Le DSM-5 ne l''a pas retenu comme entité séparée : la distinction avec le trouble de la personnalité borderline reste discutée."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('122', 'planete', 'contr', 1, '{"n":"Article 122-1","r":"N''est pas pénalement responsable la personne dont le discernement était aboli au moment des faits ; s''il était seulement altéré, la peine est modulée.","f":"Article 122-1 du code pénal français, dans sa rédaction issue du code de 1994, modifié en 2014.","i":"C''est l''expertise psychiatrique qui traduit un état clinique en catégorie juridique — traduction, jamais décalque.","c":"La part d''irresponsabilité totale prononcée a fortement diminué, évolution discutée dans ses causes comme dans ses effets."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('sanscons', 'planete', 'contr', 2, '{"n":"Soins sans consentement","r":"Depuis 2011, un juge des libertés et de la détention contrôle systématiquement les hospitalisations sous contrainte prolongées.","f":"Loi du 5 juillet 2011, à la suite d''une décision du Conseil constitutionnel.","i":"Le contrôle judiciaire entre dans un dispositif qui était resté essentiellement médico-administratif depuis 1838.","c":"L''effectivité du contrôle et le développement des programmes de soins en ambulatoire sous contrainte font l''objet de critiques documentées."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('cdph', 'planete', 'contr', 3, '{"n":"Article 12 de la CDPH","r":"La Convention de l''ONU relative aux droits des personnes handicapées affirme que toutes les personnes jouissent de la capacité juridique sur la base de l''égalité.","f":"Convention adoptée en 2006 ; l''Observation générale n° 1 (2014) appelle à supprimer la substitution dans la prise de décision.","i":"Lecture qui rend difficilement compatible avec le droit international toute décision prise à la place d''une personne du fait de son état psychique.","c":"Interprétation contestée par de nombreux États et par une partie des sociétés savantes, qui y voient un risque d''abandon."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('chime', 'planete', 'perso', 1, '{"n":"Processus de rétablissement","r":"Pour W. Anthony, se rétablir, c''est mener une vie satisfaisante, porteuse d''espoir et utile aux autres, même avec les limites imposées par la maladie. Le critère se déplace des symptômes vers la vie que la personne reconstruit.","f":"Une revue systématique de 97 études (Leamy et al., 2011) dégage cinq processus récurrents : le lien aux autres, l''espoir, l''identité, le sens donné à sa vie et le pouvoir d''agir. C''est le cadre « CHIME ».","i":"Patricia Deegan, elle-même diagnostiquée schizophrène à l''adolescence, décrit le rétablissement comme une attitude et une manière d''affronter chaque journée, non comme un état final : un chemin qui n''a rien de linéaire.","c":"Devenu un objectif officiel des politiques de santé mentale, le rétablissement peut être détourné : faire porter à la personne seule la responsabilité de son parcours, ou justifier la réduction des services. Des usagers dénoncent cette récupération."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('savoir', 'planete', 'perso', 2, '{"n":"Savoir expérientiel","r":"Vivre un trouble et ses traitements produit un savoir propre, distinct du savoir clinique : reconnaître ses signes d''alerte, savoir ce qui aide et ce qui nuit. Ce savoir fonde la pair-aidance et la participation des usagers.","f":"La sociologue Thomasina Borkman définit en 1976 le savoir expérientiel comme une connaissance acquise par l''expérience personnelle d''un phénomène, et non par le raisonnement ou l''observation extérieure.","i":"Emmanuelle Jouet, Luigi Flora et Olivier Las Vergnas montrent comment ce savoir se construit, se formalise et peut être reconnu, jusqu''à associer des patients experts aux soins, à la formation et à la recherche.","c":"Comment valider un savoir singulier ? Sa reconnaissance pose des questions de représentativité, de formation et de statut, et risque de servir de caution sans réel partage des décisions."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('voix', 'planete', 'perso', 3, '{"n":"Entendre des voix","r":"Certaines personnes entendent des voix sans être malades : la différence tient au rapport à la voix plus qu''à la voix elle-même. D''où une démarche : apprendre à dialoguer avec elle plutôt que chercher seulement à la faire taire.","f":"En 1987, le psychiatre Marius Romme et sa patiente Patsy Hage appellent à la télévision néerlandaise les personnes qui entendent des voix : des centaines répondent. Romme et Sandra Escher en rendent compte en 1989 ; le mouvement des entendeurs de voix en est issu.","i":"Le mouvement fait de l''entente de voix une expérience à comprendre dans l''histoire de la personne, souvent en lien avec des événements de vie, plutôt qu''un simple symptôme à éteindre.","c":"Les groupes d''entendeurs de voix restent peu évalués par des essais contrôlés : leurs effets sont surtout documentés par des études qualitatives."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('remis', 'planete', 'clin', 1, '{"n":"Rémission symptomatique","r":"Pour comparer les évolutions, la psychiatrie s''est dotée de critères : un trouble est dit en rémission lorsque ses symptômes principaux restent faibles pendant une durée définie, même si un traitement se poursuit.","f":"En 2005, un groupe de consensus (Andreasen et al.) définit la rémission dans la schizophrénie : huit symptômes clés cotés au plus « léger » pendant au moins six mois.","i":"Ces critères donnent un objectif commun aux essais et aux équipes, et montrent qu''une part importante des patients atteint la rémission au cours de leur suivi.","c":"La rémission ne dit rien de la qualité de vie : on peut avoir peu de symptômes et rester isolé, sans activité, ou vivre bien malgré des symptômes. Le point de vue des patients sur leur rémission reste peu pris en compte."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('devenir', 'planete', 'clin', 2, '{"n":"Évolution au long cours","r":"La schizophrénie a longtemps été présentée comme une dégradation inéluctable. Les suivis sur plusieurs décennies dessinent un tableau plus varié, où l''amélioration durable n''est pas l''exception.","f":"Dans l''étude du Vermont, environ trente ans après leur première hospitalisation, la moitié à deux tiers des patients suivis étaient nettement améliorés ou rétablis (Harding et al., 1987).","i":"Comparé à un groupe du Maine, le devenir plus favorable des patients du Vermont pourrait tenir à un programme de réhabilitation et à un retour plus précoce dans la cité : le pronostic ne serait pas inscrit dans le diagnostic (DeSisto et al., 1995).","c":"Les chiffres dépendent des définitions : avec des critères stricts et durables, à la fois cliniques et sociaux, une méta-analyse ne retient qu''une proportion médiane de 13,5 % de personnes rétablies (Jääskeläinen et al., 2013)."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('deroe', 'planete', 'clin', 3, '{"n":"Se rétablir « de » ou « dans »","r":"Deux sens du mot se côtoient : se rétablir de la maladie, c''est en être libéré ; se rétablir dans la maladie, c''est vivre pleinement malgré elle. Confondre les deux brouille les débats.","f":"Larry Davidson et David Roe proposent en 2007 de distinguer « recovery from » et « recovery in » pour lever la confusion entre approche clinique et approche personnelle.","i":"Mike Slade en tire une distinction devenue classique : le rétablissement clinique est défini et mesuré par les professionnels, le rétablissement personnel est défini par la personne elle-même.","c":"La distinction est discutée : elle risque d''opposer artificiellement le soin et le vécu, alors que la plupart des personnes visent les deux à la fois."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('rehab', 'planete', 'psysoc', 1, '{"n":"Réhabilitation psychosociale","r":"Un ensemble de pratiques qui partent des projets et des capacités de la personne plutôt que de ses déficits : évaluation fonctionnelle, entraînement des habiletés sociales, remédiation cognitive, soutien au logement et à l''emploi.","f":"En France, une instruction ministérielle du 16 janvier 2019 organise le déploiement de centres de réhabilitation psychosociale sur l''ensemble du territoire.","i":"Pour l''école de Boston (William Anthony, Marianne Farkas), la réhabilitation vise à aider la personne à réussir et à être satisfaite dans le milieu de vie qu''elle a choisi, avec le moins d''intervention professionnelle possible.","c":"Le mot « réhabilitation » est critiqué : il suggère une remise en état de la personne, alors que les difficultés tiennent aussi aux obstacles que la société lui oppose."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('pairs', 'planete', 'psysoc', 2, '{"n":"Pair-aidance","r":"Des personnes rétablies, formées, mettent leur expérience au service d''autres usagers, au sein des équipes de soin ou d''associations. Leur présence montre que le rétablissement est possible.","f":"En France, le programme « médiateurs de santé-pairs », conçu par le Centre collaborateur de l''OMS de Lille et lancé en 2012, a formé des pairs et les a intégrés comme salariés dans des équipes de psychiatrie.","i":"Les revues de la littérature associent le soutien par les pairs à davantage d''espoir, de sentiment de maîtrise et d''engagement chez les personnes accompagnées (Repper et Carter, 2011).","c":"Les essais contrôlés donnent des résultats contrastés : peu d''effet démontré sur les hospitalisations ou les symptômes, des effets plus nets sur l''espoir et le rétablissement (Lloyd-Evans et al., 2014)."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('chezsoi', 'planete', 'psysoc', 3, '{"n":"Un chez-soi d''abord","r":"Plutôt que d''exiger d''abord des soins ou l''abstinence, on propose d''emblée un logement ordinaire aux personnes sans abri vivant avec un trouble psychique sévère, avec un accompagnement intensif à domicile.","f":"Né à New York sous le nom de « Housing First » (Tsemberis et al., 2004), le modèle a été évalué en France par un essai randomisé à Lille, Marseille, Paris et Toulouse, puis pérennisé fin 2016.","i":"L''essai français, mené auprès de 703 personnes, montre une plus grande stabilité dans le logement et moins de journées d''hospitalisation que le suivi habituel (Tinland et al., 2020).","c":"Le rétablissement mesuré par échelle ne diffère pas du suivi habituel, et les symptômes diminuent dans les deux groupes. Le modèle dépend aussi du nombre de logements disponibles."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('remfonc', 'planete', 'fonct', 1, '{"n":"Rémission fonctionnelle","r":"La disparition des symptômes ne suffit pas : beaucoup de personnes en rémission gardent des difficultés à travailler, à gérer leur quotidien ou à entretenir des relations. D''où l''idée de mesurer aussi le fonctionnement.","f":"Liberman et ses collègues proposent en 2002 des critères opérationnels : pendant deux ans, des symptômes au plus modérés, une activité professionnelle ou des études au moins à mi-temps, une vie autonome et des relations sociales régulières.","i":"Philip Harvey et Alan Bellack rappellent que le fonctionnement quotidien ne dépend pas seulement des capacités de la personne : la motivation, l''effort et les obstacles que la société lui oppose comptent aussi.","c":"Aucun consensus n''existe sur la « rémission fonctionnelle » : seuils, domaines et durées varient d''une étude à l''autre, et les normes retenues reflètent souvent celles des chercheurs."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('cogn', 'planete', 'fonct', 2, '{"n":"Cognition et autonomie","r":"Attention, mémoire, planification : les difficultés cognitives associées à certains troubles pèsent lourdement sur l''autonomie. Elles peuvent faire l''objet d''un entraînement.","f":"Michael F. Green montre en 1996 que les capacités cognitives prédisent mieux le fonctionnement social et professionnel que l''intensité des symptômes psychotiques.","i":"La remédiation cognitive améliore modérément la cognition et le fonctionnement, davantage lorsqu''elle est associée à un programme de réhabilitation (méta-analyse de Wykes et al., 2011).","c":"Le transfert des progrès obtenus en séance vers la vie réelle reste discuté, de même que la durée des effets."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ips', 'planete', 'fonct', 3, '{"n":"Emploi accompagné","r":"Le modèle IPS (Individual Placement and Support) inverse la logique classique : chercher d''abord un emploi ordinaire, selon les préférences de la personne, puis la soutenir dans la durée, plutôt que de la préparer longuement en milieu protégé.","f":"Un essai mené dans six villes européennes (Burns et al., 2007) montre que 55 % des participants accompagnés selon ce modèle ont travaillé, contre 28 % avec l''orientation professionnelle classique.","i":"Une méta-analyse internationale (Modini et al., 2016) confirme l''avantage de ce modèle sur les approches classiques, y compris hors des États-Unis.","c":"Les effets varient selon le marché du travail local et les systèmes d''allocations, et les emplois obtenus restent souvent à temps partiel."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('schreber', 'planete', 'figurer', 1, '{"n":"Mémoires d''un névropathe","r":"Un haut magistrat écrit de l''intérieur un système délirant d''une cohérence saisissante, et publie pour obtenir sa sortie.","f":"Schreber publie en 1903 ; Freud en propose une analyse en 1911, sans jamais l''avoir rencontré.","i":"Un document de première main d''une richesse rare — et le cas princeps de l''analyse sur texte.","c":"Analyser à distance un texte publié pour un but judiciaire pose des problèmes méthodologiques massifs."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('brut', 'planete', 'figurer', 2, '{"n":"Art brut","r":"Des œuvres produites hors du champ artistique, d''abord collectées comme documents cliniques, puis reconnues comme art à part entière.","f":"Prinzhorn publie sa collection en 1922 ; Dubuffet forge le terme « art brut » en 1945.","i":"Le déplacement du statut — pièce clinique vers œuvre — change le regard porté sur celui qui l''a produite.","c":"La question du consentement des auteurs et du devenir des collections reste largement ouverte."}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02')
on conflict (id) do nothing;
insert into galapsy.objets(id, type, parent, ordre, donnees, statut, cree_le, maj_le) values
  ('moral.l1', 'lune', 'moral', 1, '{"t":"Traité médico-philosophique sur l''aliénation mentale, ou la manie","a":"Philippe Pinel, 1801","k":"primaire","ref":"https://gallica.bnf.fr/ark:/12148/bpt6k432033"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('moral.l2', 'lune', 'moral', 2, '{"t":"Le sujet de la folie : naissance de la psychiatrie","a":"Gladys Swain, 1977","k":"essai","ref":"ISBN 9782708930131"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('moral.l3', 'lune', 'moral', 3, '{"t":"Folie et déraison. Histoire de la folie à l''âge classique","a":"Michel Foucault, 1961","k":"essai","ref":"ISBN 9782070295821"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('alien.mono.l1', 'lune', 'alien.mono', 1, '{"t":"Des maladies mentales considérées sous les rapports médical, hygiénique et médico-légal","a":"J.-É. Esquirol, 1838","k":"primaire","ref":"https://wellcomecollection.org/works/vxnag2an"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('alien.mono.l2', 'lune', 'alien.mono', 2, '{"t":"Console and Classify: The French Psychiatric Profession in the Nineteenth Century","a":"Jan Goldstein, 1987","k":"synthese","ref":"ISBN 9780521322799"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('loi38.l1', 'lune', 'loi38', 1, '{"t":"Loi du 30 juin 1838 sur les aliénés","a":"France, 1838","k":"droit","ref":"https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000882534"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('dp.l1', 'lune', 'dp', 1, '{"t":"Psychiatrie. Ein Lehrbuch für Studirende und Aerzte, 6ᵉ éd.","a":"Emil Kraepelin, 1899","k":"primaire","ref":"https://archive.org/details/psychiatrieeinle02krae"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('schizo.l1', 'lune', 'schizo', 1, '{"t":"Dementia praecox oder Gruppe der Schizophrenien","a":"Eugen Bleuler, 1911","k":"primaire","ref":"https://wellcomecollection.org/works/v2qqa9g4"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('autisme.l1', 'lune', 'autisme', 1, '{"t":"Autistic disturbances of affective contact","a":"Leo Kanner, Nervous Child, 1943","k":"primaire","ref":"https://pubmed.ncbi.nlm.nih.gov/4880460/"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('grande.l1', 'lune', 'grande', 1, '{"t":"Leçons du mardi à la Salpêtrière","a":"J.-M. Charcot, 1887-1888","k":"primaire","ref":"https://wellcomecollection.org/works/cfs5k95r"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('grande.l2', 'lune', 'grande', 2, '{"t":"Mad Travelers: Reflections on the Reality of Transient Mental Illnesses","a":"Ian Hacking, 1998","k":"essai","ref":"ISBN 9780813918235"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('conv.l1', 'lune', 'conv', 1, '{"t":"Études sur l''hystérie","a":"Joseph Breuer & Sigmund Freud, 1895","k":"primaire","ref":"https://wellcomecollection.org/works/zx99vg7t"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('sugg.l1', 'lune', 'sugg', 1, '{"t":"De la suggestion et de ses applications à la thérapeutique","a":"Hippolyte Bernheim, 1886","k":"primaire","ref":"https://archive.org/details/b28081833"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('hoover.l1', 'lune', 'hoover', 1, '{"t":"DSM-5, Conversion Disorder (Functional Neurological Symptom Disorder)","a":"APA, 2013","k":"primaire","ref":"10.1176/appi.books.9780890425596.dsm09"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('janet.l1', 'lune', 'janet', 1, '{"t":"L''automatisme psychologique","a":"Pierre Janet, 1889","k":"primaire","ref":"https://archive.org/details/lautomatismepsyc00jane"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('tss.l1', 'lune', 'tss', 1, '{"t":"DSM-5, Somatic Symptom Disorder","a":"APA, 2013","k":"primaire","ref":"10.1176/appi.books.9780890425596.dsm09"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('retour.l1', 'lune', 'retour', 1, '{"t":"The Harmony of Illusions: Inventing Post-Traumatic Stress Disorder","a":"Allan Young, 1995","k":"essai","ref":"10.1515/9781400821938"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('bile.l1', 'lune', 'bile', 1, '{"t":"Melancholia and Depression: From Hippocratic Times to Modern Times","a":"Stanley W. Jackson, 1986","k":"synthese","ref":"10.2307/j.ctt1xp3stn"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('aced.l1', 'lune', 'aced', 1, '{"t":"Traité pratique ou Le moine","a":"Évagre le Pontique, IVᵉ s. ; éd. A. et C. Guillaumont, Sources chrétiennes, 1971","k":"primaire","ref":"https://sourceschretiennes.org/collection/sc170"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('deuil.l1', 'lune', 'deuil', 1, '{"t":"Deuil et mélancolie","a":"Sigmund Freud, 1917","k":"primaire","ref":"https://www.freudedition.net/trauer-und-melancholie"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('edm.l1', 'lune', 'edm', 1, '{"t":"DSM-III","a":"APA, 1980","k":"primaire","ref":"https://psychiatryonline.org/doi/book/10.1176/appi.books.9780521315289.dsm-iii"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('edm.l2', 'lune', 'edm', 2, '{"t":"La fatigue d''être soi. Dépression et société","a":"Alain Ehrenberg, 1998","k":"essai","ref":"10.3917/oj.ehren.1998.01"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('neuro52.l1', 'lune', 'neuro52', 1, '{"t":"Utilisation en thérapeutique psychiatrique d''une phénothiazine d''action centrale élective (4560 RP)","a":"J. Delay, P. Deniker & J.-M. Harl, Annales médico-psychologiques, 1952","k":"primaire","ref":"https://pubmed.ncbi.nlm.nih.gov/12986408/"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('pi.l1', 'lune', 'pi', 1, '{"t":"Le collectif","a":"Jean Oury, 1986","k":"primaire","ref":"ISBN 9782714500380"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('secteur.l1', 'lune', 'secteur', 1, '{"t":"Circulaire du 15 mars 1960 relative au programme d''organisation et d''équipement des départements en matière de lutte contre les maladies mentales","a":"France, 1960","k":"droit"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('goff.l1', 'lune', 'goff', 1, '{"t":"Asylums: Essays on the Social Situation of Mental Patients and Other Inmates","a":"Erving Goffman, 1961","k":"synthese","ref":"10.4324/9781351327763"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('vital.l1', 'lune', 'vital', 1, '{"t":"La schizophrénie. Psychopathologie des schizoïdes et des schizophrènes","a":"Eugène Minkowski, 1927","k":"primaire","ref":"ISBN 9782228896030"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('vital.l2', 'lune', 'vital', 2, '{"t":"Le temps vécu. Études phénoménologiques et psychopathologiques","a":"Eugène Minkowski, 1933","k":"primaire","ref":"10.3917/puf.mink.2013.01"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('blocage.l1', 'lune', 'blocage', 1, '{"t":"Le temps vécu. Études phénoménologiques et psychopathologiques","a":"Eugène Minkowski, 1933","k":"primaire","ref":"10.3917/puf.mink.2013.01"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('formes.l1', 'lune', 'formes', 1, '{"t":"Drei Formen missglückten Daseins","a":"Ludwig Binswanger, 1956","k":"primaire","ref":"10.1515/9783111578071"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ellen.l1', 'lune', 'ellen', 1, '{"t":"Der Fall Ellen West","a":"Ludwig Binswanger, 1944-1945","k":"primaire"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('perte.l1', 'lune', 'perte', 1, '{"t":"Der Verlust der natürlichen Selbstverständlichkeit","a":"Wolfgang Blankenburg, 1971","k":"primaire","ref":"ISBN 9783938880579"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ipse.l1', 'lune', 'ipse', 1, '{"t":"Schizophrenia, consciousness, and the self","a":"L. Sass & J. Parnas, Schizophrenia Bulletin, 2003","k":"donnees","ref":"10.1093/oxfordjournals.schbul.a007017"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ipse.l2', 'lune', 'ipse', 2, '{"t":"EASE: Examination of Anomalous Self-Experience","a":"J. Parnas et al., Psychopathology, 2005","k":"donnees","ref":"10.1159/000088441"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('normativ.l1', 'lune', 'normativ', 1, '{"t":"Le normal et le pathologique","a":"Georges Canguilhem, 1943/1966","k":"essai","ref":"10.3917/puf.cangu.2013.01"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('moins.l1', 'lune', 'moins', 1, '{"t":"Der Aufbau des Organismus","a":"Kurt Goldstein, 1934","k":"primaire","ref":"10.1007/978-94-017-7141-2"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('loop.l1', 'lune', 'loop', 1, '{"t":"The looping effects of human kinds","a":"Ian Hacking, 1995","k":"essai","ref":"10.1093/acprof:oso/9780198524021.003.0012"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('loop.l2', 'lune', 'loop', 2, '{"t":"Rewriting the Soul: Multiple Personality and the Sciences of Memory","a":"Ian Hacking, 1995","k":"essai","ref":"10.1515/9781400821686"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('transit.l1', 'lune', 'transit', 1, '{"t":"Mad Travelers: Reflections on the Reality of Transient Mental Illnesses","a":"Ian Hacking, 1998","k":"essai","ref":"ISBN 9780813918235"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('fid.l1', 'lune', 'fid', 1, '{"t":"Diagnostic criteria for use in psychiatric research","a":"J. Feighner et al., Arch Gen Psychiatry, 1972","k":"primaire","ref":"10.1001/archpsyc.1972.01750190059011"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('fid.l2', 'lune', 'fid', 2, '{"t":"DSM-III","a":"APA, 1980","k":"primaire","ref":"https://psychiatryonline.org/doi/book/10.1176/appi.books.9780521315289.dsm-iii"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('rdoc.l1', 'lune', 'rdoc', 1, '{"t":"Transforming Diagnosis (RDoC)","a":"T. Insel, NIMH, 2013","k":"primaire"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('rdoc.l2', 'lune', 'rdoc', 2, '{"t":"The Hierarchical Taxonomy of Psychopathology (HiTOP): A dimensional alternative to traditional nosologies","a":"R. Kotov et al., J Abnorm Psychol, 2017","k":"donnees","ref":"10.1037/abn0000258"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('wake.l1', 'lune', 'wake', 1, '{"t":"The concept of mental disorder: on the boundary between biological facts and social values","a":"J. C. Wakefield, American Psychologist, 1992","k":"essai","ref":"10.1037/0003-066X.47.3.373"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('szasz.l1', 'lune', 'szasz', 1, '{"t":"The Myth of Mental Illness: Foundations of a Theory of Personal Conduct","a":"Thomas Szasz, 1961","k":"essai","ref":"https://archive.org/details/mythofmentalilln00szas"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('reseau.l1', 'lune', 'reseau', 1, '{"t":"A network theory of mental disorders","a":"D. Borsboom, World Psychiatry, 2017","k":"donnees","ref":"10.1002/wps.20375"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('injust.l1', 'lune', 'injust', 1, '{"t":"Epistemic Injustice: Power and the Ethics of Knowing","a":"Miranda Fricker, Oxford University Press, 2007","k":"essai","ref":"10.1093/acprof:oso/9780198237907.001.0001"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('injust.l2', 'lune', 'injust', 2, '{"t":"Epistemic injustice in psychiatry","a":"P. Crichton, H. Carel & I. J. Kidd, BJPsych Bulletin, 2017","k":"essai","ref":"10.1192/pb.bp.115.050682"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('refoul.l1', 'lune', 'refoul', 1, '{"t":"Le refoulement / L''inconscient","a":"Sigmund Freud, 1915","k":"primaire","ref":"https://www.freudedition.net/werke/freud-sigmund/die-verdrangung"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('transf.l1', 'lune', 'transf', 1, '{"t":"La dynamique du transfert","a":"Sigmund Freud, 1912","k":"primaire","ref":"https://www.freudedition.net/werke/freud-sigmund/zur-dynamik-der-ubertragung"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('miroir.l1', 'lune', 'miroir', 1, '{"t":"Le stade du miroir comme formateur de la fonction du Je, telle qu''elle nous est révélée dans l''expérience psychanalytique","a":"Jacques Lacan, 1949","k":"primaire","ref":"https://pep-web.org/browse/document/RFP.013.0449A"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('forcl.l1', 'lune', 'forcl', 1, '{"t":"Le Séminaire, livre III : Les psychoses","a":"Jacques Lacan, 1981 (séminaire de 1955-1956)","k":"primaire","ref":"ISBN 9782020060264"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('depress.l1', 'lune', 'depress', 1, '{"t":"A contribution to the psychogenesis of manic-depressive states","a":"Melanie Klein, 1935","k":"primaire","ref":"https://pep-web.org/browse/document/IJP.016.0145A"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('trans.l1', 'lune', 'trans', 1, '{"t":"Transitional objects and transitional phenomena","a":"D. W. Winnicott, 1953","k":"primaire","ref":"https://pep-web.org/browse/document/IJP.034.0089A"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('base.l1', 'lune', 'base', 1, '{"t":"Attachment and Loss, vol. 1: Attachment","a":"John Bowlby, 1969","k":"primaire","ref":"ISBN 9780701203009"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('etrange.l1', 'lune', 'etrange', 1, '{"t":"Patterns of Attachment: A Psychological Study of the Strange Situation","a":"M. D. S. Ainsworth, M. C. Blehar, E. Waters & S. Wall, 1978","k":"donnees","ref":"10.4324/9780203758045"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('etrange.l2', 'lune', 'etrange', 2, '{"t":"Procedures for identifying infants as disorganized/disoriented during the Ainsworth Strange Situation","a":"M. Main & J. Solomon, 1990","k":"donnees","ref":"ISBN 9780226306308"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('dopa.l1', 'lune', 'dopa', 1, '{"t":"The dopamine hypothesis of schizophrenia: version III—the final common pathway","a":"O. Howes & S. Kapur, Schizophrenia Bulletin, 2009","k":"revue","ref":"10.1093/schbul/sbp006"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('sero.l1', 'lune', 'sero', 1, '{"t":"The serotonin theory of depression: a systematic umbrella review of the evidence","a":"J. Moncrieff et al., Molecular Psychiatry, 2022","k":"revue","ref":"10.1038/s41380-022-01661-0"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('keta.l1', 'lune', 'keta', 1, '{"t":"Ketamine and rapid-acting antidepressants: a window into a new neurobiology for mood disorder therapeutics","a":"C. G. Abdallah, G. Sanacora, R. S. Duman & J. H. Krystal, Annual Review of Medicine, 2015","k":"revue","ref":"10.1146/annurev-med-053013-062946"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('crp.l1', 'lune', 'crp', 1, '{"t":"Prevalence of low-grade inflammation in depression: a systematic review and meta-analysis of CRP levels","a":"E. F. Osimo et al., Psychological Medicine, 2019","k":"revue","ref":"10.1017/S0033291719001454"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('exjuv.l1', 'lune', 'exjuv', 1, '{"t":"The serotonin theory of depression: a systematic umbrella review of the evidence","a":"J. Moncrieff et al., Molecular Psychiatry, 2022","k":"revue","ref":"10.1038/s41380-022-01661-0"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('prior.l1', 'lune', 'prior', 1, '{"t":"Pavlovian conditioning-induced hallucinations result from overweighting of perceptual priors","a":"A. Powers, C. Mathys & P. Corlett, Science, 2017","k":"donnees","ref":"10.1126/science.aan3458"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('triade.l1', 'lune', 'triade', 1, '{"t":"Cognitive Therapy of Depression","a":"A. T. Beck, A. J. Rush, B. F. Shaw & G. Emery, 1979","k":"primaire","ref":"ISBN 9780898620009"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('rumi.l1', 'lune', 'rumi', 1, '{"t":"Responses to depression and their effects on the duration of depressive episodes","a":"S. Nolen-Hoeksema, J Abnorm Psychol, 1991","k":"donnees","ref":"10.1037/0021-843X.100.4.569"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('urb.l1', 'lune', 'urb', 1, '{"t":"Meta-analysis of the association of urbanicity with schizophrenia","a":"E. Vassos et al., Schizophrenia Bulletin, 2012","k":"revue","ref":"10.1093/schbul/sbs096"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('migr.l1', 'lune', 'migr', 1, '{"t":"Schizophrenia and migration: a meta-analysis and review","a":"E. Cantor-Graae & J.-P. Selten, Am J Psychiatry, 2005","k":"revue","ref":"10.1176/appi.ajp.162.1.12"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('anti.l1', 'lune', 'anti', 1, '{"t":"The Divided Self: An Existential Study in Sanity and Madness","a":"R. D. Laing, 1960","k":"essai","ref":"https://archive.org/details/dividedselfexist0000rdla"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('anti.l2', 'lune', 'anti', 2, '{"t":"Legge 13 maggio 1978, n. 180 – Accertamenti e trattamenti sanitari volontari e obbligatori (« loi Basaglia »)","a":"Italie, 1978","k":"droit","ref":"https://www.gazzettaufficiale.it/eli/id/1978/05/16/078U0180/s"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('idiom.l1', 'lune', 'idiom', 1, '{"t":"Essais d''ethnopsychiatrie générale","a":"Georges Devereux, 1970","k":"essai","ref":"https://www.gallimard.fr/catalogue/essais-d-ethnopsychiatrie-generale/9782070282067"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('oms.l1', 'lune', 'oms', 1, '{"t":"Questioning an axiom: better prognosis for schizophrenia in the developing world?","a":"A. Cohen et al., Schizophrenia Bulletin, 2008","k":"revue","ref":"10.1093/schbul/sbm105"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('export.l1', 'lune', 'export', 1, '{"t":"Crazy Like Us: The Globalization of the American Psyche","a":"Ethan Watters, 2010","k":"essai","ref":"ISBN 9781416587088"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('tspt.l1', 'lune', 'tspt', 1, '{"t":"PTSD in DSM-III: a case in the politics of diagnosis and disease","a":"W. J. Scott, Social Problems, 1990","k":"donnees","ref":"10.2307/800744"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ace.l1', 'lune', 'ace', 1, '{"t":"Relationship of childhood abuse and household dysfunction to many of the leading causes of death in adults: the Adverse Childhood Experiences (ACE) Study","a":"V. Felitti et al., Am J Prev Med, 1998","k":"donnees","ref":"10.1016/S0749-3797(98)00017-8"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('complexe.l1', 'lune', 'complexe', 1, '{"t":"Trauma and Recovery: The Aftermath of Violence — From Domestic Abuse to Political Terror","a":"Judith Lewis Herman, 1992","k":"synthese","ref":"ISBN 9780465087662"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('complexe.l2', 'lune', 'complexe', 2, '{"t":"CIM-11, 6B41 Trouble de stress post-traumatique complexe","a":"OMS, 2018","k":"primaire","ref":"https://icd.who.int/browse/latest-release/mms/fr#585833559"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('122.l1', 'lune', '122', 1, '{"t":"Code pénal, article 122-1","a":"France","k":"droit","ref":"https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000029370748"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('sanscons.l1', 'lune', 'sanscons', 1, '{"t":"Loi n° 2011-803 du 5 juillet 2011 relative aux droits et à la protection des personnes faisant l''objet de soins psychiatriques et aux modalités de leur prise en charge","a":"France","k":"droit","ref":"https://www.legifrance.gouv.fr/loda/id/JORFTEXT000024312722"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('cdph.l1', 'lune', 'cdph', 1, '{"t":"Convention relative aux droits des personnes handicapées, art. 12","a":"ONU, 2006","k":"droit","ref":"https://www.ohchr.org/fr/instruments-mechanisms/instruments/convention-rights-persons-disabilities"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('chime.l1', 'lune', 'chime', 1, '{"t":"Recovery from mental illness: the guiding vision of the mental health service system in the 1990s","a":"W. A. Anthony, Psychosocial Rehabilitation Journal, 1993","k":"primaire","ref":"10.1037/h0095655"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('chime.l2', 'lune', 'chime', 2, '{"t":"Conceptual framework for personal recovery in mental health: systematic review and narrative synthesis","a":"M. Leamy et al., British Journal of Psychiatry, 2011","k":"revue","ref":"10.1192/bjp.bp.110.083733"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('chime.l3', 'lune', 'chime', 3, '{"t":"Recovery: the lived experience of rehabilitation","a":"P. E. Deegan, Psychosocial Rehabilitation Journal, 1988","k":"temoignage","ref":"10.1037/h0099565"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('chime.l4', 'lune', 'chime', 4, '{"t":"The mainstreaming of recovery","a":"D. Rose, Journal of Mental Health, 2014","k":"essai","ref":"10.3109/09638237.2014.928406"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('savoir.l1', 'lune', 'savoir', 1, '{"t":"Experiential knowledge: a new concept for the analysis of self-help groups","a":"T. Borkman, Social Service Review, 1976","k":"essai","ref":"10.1086/643401"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('savoir.l2', 'lune', 'savoir', 2, '{"t":"Construction et reconnaissance des savoirs expérientiels des patients : note de synthèse","a":"E. Jouet, L. Flora & O. Las Vergnas, Pratiques de formation – Analyses, 2010","k":"synthese","ref":"https://www.persee.fr/doc/pfa_0292-2215_2010_num_58_1_950"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('voix.l1', 'lune', 'voix', 1, '{"t":"Hearing voices","a":"M. Romme & S. Escher, Schizophrenia Bulletin, 1989","k":"donnees","ref":"10.1093/schbul/15.2.209"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('voix.l2', 'lune', 'voix', 2, '{"t":"Emerging perspectives from the hearing voices movement: implications for research and practice","a":"D. Corstens et al., Schizophrenia Bulletin, 2014","k":"synthese","ref":"10.1093/schbul/sbu007"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('remis.l1', 'lune', 'remis', 1, '{"t":"Remission in schizophrenia: proposed criteria and rationale for consensus","a":"N. C. Andreasen et al., American Journal of Psychiatry, 2005","k":"primaire","ref":"10.1176/appi.ajp.162.3.441"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('remis.l2', 'lune', 'remis', 2, '{"t":"Remission in schizophrenia: validity, frequency, predictors, and patients'' perspective 5 years later","a":"M. Lambert et al., Dialogues in Clinical Neuroscience, 2010","k":"synthese","ref":"10.31887/DCNS.2010.12.3/mlambert"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('devenir.l1', 'lune', 'devenir', 1, '{"t":"The Vermont longitudinal study of persons with severe mental illness, II: Long-term outcome of subjects who retrospectively met DSM-III criteria for schizophrenia","a":"C. M. Harding et al., American Journal of Psychiatry, 1987","k":"donnees","ref":"10.1176/ajp.144.6.727"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('devenir.l2', 'lune', 'devenir', 2, '{"t":"The Maine and Vermont three-decade studies of serious mental illness. I. Matched comparison of cross-sectional outcome","a":"M. J. DeSisto et al., British Journal of Psychiatry, 1995","k":"donnees","ref":"10.1192/bjp.167.3.331"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('devenir.l3', 'lune', 'devenir', 3, '{"t":"A systematic review and meta-analysis of recovery in schizophrenia","a":"E. Jääskeläinen et al., Schizophrenia Bulletin, 2013","k":"revue","ref":"10.1093/schbul/sbs130"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('deroe.l1', 'lune', 'deroe', 1, '{"t":"Recovery from versus recovery in serious mental illness: one strategy for lessening confusion plaguing recovery","a":"L. Davidson & D. Roe, Journal of Mental Health, 2007","k":"essai","ref":"10.1080/09638230701482394"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('deroe.l2', 'lune', 'deroe', 2, '{"t":"Personal Recovery and Mental Illness: A Guide for Mental Health Professionals","a":"M. Slade, Cambridge University Press, 2009","k":"synthese","ref":"10.1017/CBO9780511581649"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('rehab.l1', 'lune', 'rehab', 1, '{"t":"Instruction n° DGOS/R4/2019/10 du 16 janvier 2019 relative au développement des soins de réhabilitation psychosociale sur les territoires","a":"Ministère des Solidarités et de la Santé, 16 janvier 2019","k":"droit","ref":"https://www.legifrance.gouv.fr/circulaire/id/44293"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('rehab.l2', 'lune', 'rehab', 2, '{"t":"Psychiatric rehabilitation interventions: a review","a":"M. Farkas & W. A. Anthony, International Review of Psychiatry, 2010","k":"revue","ref":"10.3109/09540261003730372"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('pairs.l1', 'lune', 'pairs', 1, '{"t":"L''expérimentation des médiateurs de santé-pairs. Une révolution intranquille","a":"J.-L. Roelandt & B. Staedel (dir.), Doin, 2016","k":"donnees","ref":"https://stm.cairn.info/l-experimentation-des-mediateurs-de-sante-pairs--9782704014729"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('pairs.l2', 'lune', 'pairs', 2, '{"t":"A review of the literature on peer support in mental health services","a":"J. Repper & T. Carter, Journal of Mental Health, 2011","k":"revue","ref":"10.3109/09638237.2011.583947"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('pairs.l3', 'lune', 'pairs', 3, '{"t":"A systematic review and meta-analysis of randomised controlled trials of peer support for people with severe mental illness","a":"B. Lloyd-Evans et al., BMC Psychiatry, 2014","k":"revue","ref":"10.1186/1471-244X-14-39"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('chezsoi.l1', 'lune', 'chezsoi', 1, '{"t":"Housing First, consumer choice, and harm reduction for homeless individuals with a dual diagnosis","a":"S. Tsemberis, L. Gulcur & M. Nakae, American Journal of Public Health, 2004","k":"donnees","ref":"10.2105/AJPH.94.4.651"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('chezsoi.l2', 'lune', 'chezsoi', 2, '{"t":"Effectiveness of a housing support team intervention with a recovery-oriented approach on hospital and emergency department use by homeless people with severe mental illness: a randomised controlled trial","a":"A. Tinland et al., Epidemiology and Psychiatric Sciences, 2020","k":"donnees","ref":"10.1017/S2045796020000785"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('remfonc.l1', 'lune', 'remfonc', 1, '{"t":"Operational criteria and factors related to recovery from schizophrenia","a":"R. P. Liberman et al., International Review of Psychiatry, 2002","k":"primaire","ref":"10.1080/0954026021000016905"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('remfonc.l2', 'lune', 'remfonc', 2, '{"t":"Toward a terminology for functional recovery in schizophrenia: is functional remission a viable concept?","a":"P. D. Harvey & A. S. Bellack, Schizophrenia Bulletin, 2009","k":"essai","ref":"10.1093/schbul/sbn171"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('cogn.l1', 'lune', 'cogn', 1, '{"t":"What are the functional consequences of neurocognitive deficits in schizophrenia?","a":"M. F. Green, American Journal of Psychiatry, 1996","k":"donnees","ref":"10.1176/ajp.153.3.321"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('cogn.l2', 'lune', 'cogn', 2, '{"t":"A meta-analysis of cognitive remediation for schizophrenia: methodology and effect sizes","a":"T. Wykes et al., American Journal of Psychiatry, 2011","k":"revue","ref":"10.1176/appi.ajp.2010.10060855"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ips.l1', 'lune', 'ips', 1, '{"t":"The effectiveness of supported employment for people with severe mental illness: a randomised controlled trial","a":"T. Burns et al., The Lancet, 2007","k":"donnees","ref":"10.1016/S0140-6736(07)61516-5"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ips.l2', 'lune', 'ips', 2, '{"t":"Supported employment for people with severe mental illness: systematic review and meta-analysis of the international evidence","a":"M. Modini et al., British Journal of Psychiatry, 2016","k":"revue","ref":"10.1192/bjp.bp.115.165092"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('schreber.l1', 'lune', 'schreber', 1, '{"t":"Denkwürdigkeiten eines Nervenkranken","a":"Daniel Paul Schreber, 1903","k":"temoignage","ref":"http://www.zeno.org/Kulturgeschichte/M/Schreber,+Daniel+Paul/Denkw%C3%BCrdigkeiten+eines+Nervenkranken"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('brut.l1', 'lune', 'brut', 1, '{"t":"Bildnerei der Geisteskranken: Ein Beitrag zur Psychologie und Psychopathologie der Gestaltung","a":"Hans Prinzhorn, 1922","k":"primaire","ref":"10.1007/978-3-642-64934-9"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02')
on conflict (id) do nothing;
insert into galapsy.objets(id, type, parent, ordre, donnees, statut, cree_le, maj_le) values
  ('moral.t1', 'trou', 'moral', 101, '{"cible":"loop","l":"Une catégorie qui transforme ceux qu''elle nomme"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('alien.mono.t1', 'trou', 'alien.mono', 101, '{"cible":"122","l":"L''expertise psychiatrique au tribunal"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('loi38.t1', 'trou', 'loi38', 101, '{"cible":"sanscons","l":"La contrainte aujourd''hui"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('schizo.t1', 'trou', 'schizo', 101, '{"cible":"ipse","l":"La même entité vue du dedans"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('schizo.t2', 'trou', 'schizo', 102, '{"cible":"dopa","l":"La même entité vue comme circuit"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('schizo.t3', 'trou', 'schizo', 103, '{"cible":"oms","l":"La même entité, pronostic variable selon les pays"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('grande.t1', 'trou', 'grande', 101, '{"cible":"transit","l":"Une maladie mentale transitoire"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('conv.t1', 'trou', 'conv', 101, '{"cible":"refoul","l":"Le mécanisme, côté psychodynamique"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('deuil.t1', 'trou', 'deuil', 101, '{"cible":"refoul","l":"Le corpus freudien complet"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('edm.t1', 'trou', 'edm', 101, '{"cible":"fid","l":"Fidélité n''est pas validité"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('edm.t2', 'trou', 'edm', 102, '{"cible":"sero","l":"La version neurochimique — qui vient d''exploser"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('edm.t3', 'trou', 'edm', 103, '{"cible":"blocage","l":"La version en temps vécu"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('goff.t1', 'trou', 'goff', 101, '{"cible":"anti","l":"Le versant politique"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('blocage.t1', 'trou', 'blocage', 101, '{"cible":"edm","l":"La version critériologique"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ipse.t1', 'trou', 'ipse', 101, '{"cible":"schizo","l":"La même entité, vue par la nosographie"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ipse.t2', 'trou', 'ipse', 102, '{"cible":"voix","l":"La même expérience, vue par ceux qui la vivent"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('normativ.t1', 'trou', 'normativ', 101, '{"cible":"chime","l":"Se rétablir, c''est se donner de nouvelles normes"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('transit.t1', 'trou', 'transit', 101, '{"cible":"grande","l":"Le cas princeps"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('fid.t1', 'trou', 'fid', 101, '{"cible":"edm","l":"Le cas de la dépression"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('injust.t1', 'trou', 'injust', 101, '{"cible":"savoir","l":"Le savoir des personnes concernées"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('refoul.t1', 'trou', 'refoul', 101, '{"cible":"conv","l":"Le terrain clinique d''origine"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('etrange.t1', 'trou', 'etrange', 101, '{"cible":"ace","l":"L''adversité précoce, versant épidémiologique"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('dopa.t1', 'trou', 'dopa', 101, '{"cible":"schizo","l":"La même entité, vue par l''histoire"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('sero.t1', 'trou', 'sero', 101, '{"cible":"edm","l":"La construction de la catégorie visée"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('prior.t1', 'trou', 'prior', 101, '{"cible":"voix","l":"Entendre des voix, côté vécu"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('triade.t1', 'trou', 'triade', 101, '{"cible":"refoul","l":"L''autre lecture du même symptôme"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('anti.t1', 'trou', 'anti', 101, '{"cible":"goff","l":"L''analyse sociologique de l''asile"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('oms.t1', 'trou', 'oms', 101, '{"cible":"schizo","l":"L''entité dont on discute le pronostic"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('export.t1', 'trou', 'export', 101, '{"cible":"loop","l":"Le mécanisme théorique"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('ace.t1', 'trou', 'ace', 101, '{"cible":"etrange","l":"Le versant relationnel"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('122.t1', 'trou', '122', 101, '{"cible":"alien.mono","l":"L''ancêtre : la monomanie au tribunal"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('sanscons.t1', 'trou', 'sanscons', 101, '{"cible":"loi38","l":"Le texte qu''elle remplace"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('chime.t1', 'trou', 'chime', 101, '{"cible":"normativ","l":"Vivre selon ses propres normes"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('savoir.t1', 'trou', 'savoir', 101, '{"cible":"injust","l":"Quand ce savoir n''est pas cru"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('voix.t1', 'trou', 'voix', 101, '{"cible":"prior","l":"Le même phénomène, versant computationnel"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('voix.t2', 'trou', 'voix', 102, '{"cible":"ipse","l":"Le même phénomène, versant phénoménologique"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('devenir.t1', 'trou', 'devenir', 101, '{"cible":"oms","l":"Un pronostic qui varie selon les sociétés"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('rehab.t1', 'trou', 'rehab', 101, '{"cible":"secteur","l":"Soigner dans la cité"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02'),
  ('remfonc.t1', 'trou', 'remfonc', 101, '{"cible":"wake","l":"Qu''appelle-t-on une dysfonction ?"}'::jsonb, 'publie', '2026-09-18 18:45:56+02', '2026-09-18 18:45:56+02')
on conflict (id) do nothing;
insert into galapsy.revisions(objet, action, donnees, justification, auteur, statut, cree_le, modere_le)
select id, 'creation', donnees, 'Corpus fondateur', null, 'acceptee', cree_le, cree_le
  from galapsy.objets o
 where cree_par is null
   and not exists (select 1 from galapsy.revisions r where r.objet = o.id);
commit;

-- ============================================================
-- GALAPSY' — plateforme contributive
-- 4. Textes de présentation, modifiables par les administrateurs
--    (fichier généré par gen_textes.py à partir de textes.json)
-- ============================================================
-- anciens textes de la visite, remplacés par le récit
delete from galapsy.objets where type = 'texte' and id like 'texte.visite.%';
insert into galapsy.objets(id, type, parent, ordre, donnees, statut, cree_le, maj_le) values
  ('texte.porte.question', 'texte', null, 1, '{"v":"D''où vient la *souffrance psychique* ?","cle":"porte.question","groupe":"Écran d''ouverture","libelle":"Question"}'::jsonb, 'publie', now(), now()),
  ('texte.porte.texte', 'texte', null, 2, '{"v":"Toute la matière du savoir psy tient d''abord dans cette seule question, comprimée. Aucune réponse ne la soutient seule : elle s''effondre, et l''effondrement projette {galaxies} manières de répondre. C''est la première dispersion — tout le reste en descend.","cle":"porte.texte","groupe":"Écran d''ouverture","libelle":"Texte d''introduction"}'::jsonb, 'publie', now(), now()),
  ('texte.porte.bouton', 'texte', null, 3, '{"v":"Big Bang (Effondrement psychique)","cle":"porte.bouton","groupe":"Écran d''ouverture","libelle":"Bouton"}'::jsonb, 'publie', now(), now()),
  ('texte.porte.sous', 'texte', null, 4, '{"v":"les {galaxies} approches apparaîtront une à une","cle":"porte.sous","groupe":"Écran d''ouverture","libelle":"Sous le bouton"}'::jsonb, 'publie', now(), now()),
  ('texte.porte.gratuite', 'texte', null, 5, '{"v":"application entièrement gratuite, sans publicité","cle":"porte.gratuite","groupe":"Écran d''ouverture","libelle":"Mention de gratuité"}'::jsonb, 'publie', now(), now()),
  ('texte.releve.titre', 'texte', null, 6, '{"v":"{Galaxies} manières de répondre","cle":"releve.titre","groupe":"Relevé des galaxies","libelle":"Titre"}'::jsonb, 'publie', now(), now()),
  ('texte.releve.sous', 'texte', null, 7, '{"v":"issues de l''effondrement · chacune est une galaxie","cle":"releve.sous","groupe":"Relevé des galaxies","libelle":"Sous-titre"}'::jsonb, 'publie', now(), now()),
  ('texte.releve.pied1', 'texte', null, 8, '{"v":"Ces {galaxies} galaxies sont autant de façons d''aborder la souffrance psychique. Un même objet clinique — la mélancolie, la schizophrénie, le trauma — apparaît dans plusieurs d''entre elles, sous des angles différents. Les [trous de ver] relient ces points de vue : c''est en passant de l''un à l''autre qu''on le comprend vraiment.","cle":"releve.pied1","groupe":"Relevé des galaxies","libelle":"Texte de bas de page (1)"}'::jsonb, 'publie', now(), now()),
  ('texte.releve.pied2', 'texte', null, 9, '{"v":"{Galaxies} n''est pas un total. Au bord du cosmos dérivent {zones} [zones non cartographiées] — et elles ne sont que celles qu''on a déjà repérées.","cle":"releve.pied2","groupe":"Relevé des galaxies","libelle":"Texte de bas de page (2)"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.prelude', 'texte', null, 10, '{"v":"première sortie · secteur inexploré","cle":"recit.prelude","groupe":"Présentation (visite et vidéo)","libelle":"Ouverture"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.porte', 'texte', null, 11, '{"v":"Touchez « Big Bang » pour commencer.","cle":"recit.porte","groupe":"Présentation (visite et vidéo)","libelle":"Invitation au Big Bang"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.dispersion', 'texte', null, 12, '{"v":"Aucune réponse ne suffit à elle seule. La question se divise en {galaxies} façons d''aborder la souffrance psychique.","cle":"recit.dispersion","groupe":"Présentation (visite et vidéo)","libelle":"Première dispersion"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.releve', 'texte', null, 13, '{"v":"Le relevé présente chaque approche et son hypothèse centrale.","cle":"recit.releve","groupe":"Présentation (visite et vidéo)","libelle":"Le relevé"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.galaxies', 'texte', null, 14, '{"v":"Chaque galaxie est une approche, avec sa propre question, ses méthodes et ses concepts. Aucune ne détient seule la vérité : chacune éclaire une part du réel.","cle":"recit.galaxies","groupe":"Présentation (visite et vidéo)","libelle":"Les galaxies"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.zoom', 'texte', null, 15, '{"v":"Écartez deux doigts pour vous approcher, glissez pour parcourir le cosmos. Touchez une galaxie pour y entrer.","cle":"recit.zoom","groupe":"Présentation (visite et vidéo)","libelle":"Navigation"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.etoiles', 'texte', null, 16, '{"v":"Dans chaque galaxie brillent des étoiles : les écoles et les courants de pensée, situés dans le temps.","cle":"recit.etoiles","groupe":"Présentation (visite et vidéo)","libelle":"Les étoiles"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.planetes', 'texte', null, 17, '{"v":"Autour de chaque étoile gravitent des planètes : les notions cliniques. Leurs satellites sont les sources qui les documentent.","cle":"recit.planetes","groupe":"Présentation (visite et vidéo)","libelle":"Planètes et satellites"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.fiche', 'texte', null, 18, '{"v":"Chaque planète distingue trois niveaux : le fait établi, l''interprétation et la controverse.","cle":"recit.fiche","groupe":"Présentation (visite et vidéo)","libelle":"La fiche"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.satellites', 'texte', null, 19, '{"v":"La couleur d''un satellite indique la nature de la source, et donc son degré de certitude : source primaire, méta-analyse, étude, essai, témoignage, texte de loi.","cle":"recit.satellites","groupe":"Présentation (visite et vidéo)","libelle":"Les satellites"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.instable', 'texte', null, 20, '{"v":"Un savoir n''est jamais acquis. Certaines catégories s''effondrent et donnent naissance à d''autres.","cle":"recit.instable","groupe":"Présentation (visite et vidéo)","libelle":"Étoile instable"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.heritiers', 'texte', null, 21, '{"v":"L''hystérie a quitté les classifications ; sa matière se répartit aujourd''hui entre {heritiers}.","cle":"recit.heritiers","groupe":"Présentation (visite et vidéo)","libelle":"Supernova"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.trou', 'texte', null, 22, '{"v":"Une même notion apparaît dans plusieurs galaxies. Un trou de ver relie ces points de vue et invite à les comparer.","cle":"recit.trou","groupe":"Présentation (visite et vidéo)","libelle":"Trou de ver"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.escales', 'texte', null, 23, '{"v":"Chaque galaxie répond à sa manière. Voici leurs hypothèses.","cle":"recit.escales","groupe":"Présentation (visite et vidéo)","libelle":"Les escales"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.constellation', 'texte', null, 24, '{"v":"Chaque notion consultée s''inscrit dans votre constellation : la trace de votre parcours.","cle":"recit.constellation","groupe":"Présentation (visite et vidéo)","libelle":"Constellation"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.frontiere', 'texte', null, 25, '{"v":"Au bord du cosmos, {zones} régions restent à cartographier.","cle":"recit.frontiere","groupe":"Présentation (visite et vidéo)","libelle":"Frontière"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.recherche', 'texte', null, 26, '{"v":"La loupe permet de trouver une notion, un auteur ou une source.","cle":"recit.recherche","groupe":"Présentation (visite et vidéo)","libelle":"Recherche"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.creation', 'texte', null, 27, '{"v":"Si une notion manque, chacun peut la proposer, source à l''appui : une galaxie, une étoile, une planète ou un satellite.","cle":"recit.creation","groupe":"Présentation (visite et vidéo)","libelle":"Création"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.regles_titre', 'texte', null, 28, '{"v":"Règles de la communauté","cle":"recit.regles_titre","groupe":"Présentation (visite et vidéo)","libelle":"Règles : titre"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.regle1', 'texte', null, 29, '{"v":"**Joignez une source en lien à chaque proposition** : adresse web, DOI ou ISBN. Sans lien, elle n''est pas reçue.","cle":"recit.regle1","groupe":"Présentation (visite et vidéo)","libelle":"Règle 1"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.regle2', 'texte', null, 30, '{"v":"**Déclarez honnêtement la nature de la source** : sa couleur en dépend.","cle":"recit.regle2","groupe":"Présentation (visite et vidéo)","libelle":"Règle 2"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.regle3', 'texte', null, 31, '{"v":"**Distinguez** le fait établi, l''interprétation et la controverse.","cle":"recit.regle3","groupe":"Présentation (visite et vidéo)","libelle":"Règle 3"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.regle4', 'texte', null, 32, '{"v":"**Décrivez des notions, jamais des personnes** : aucune donnée personnelle, aucun conseil médical.","cle":"recit.regle4","groupe":"Présentation (visite et vidéo)","libelle":"Règle 4"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.regles_pied', 'texte', null, 33, '{"v":"Un administrateur vérifie chaque proposition avant sa publication, et chaque version reste consultable. La fiabilité de l''atlas dépend de chacun.","cle":"recit.regles_pied","groupe":"Présentation (visite et vidéo)","libelle":"Règles : conclusion"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.gratuite', 'texte', null, 34, '{"v":"Galapsy est gratuite, sans publicité ni revente de données : un savoir partagé doit rester accessible à tous.","cle":"recit.gratuite","groupe":"Présentation (visite et vidéo)","libelle":"Gratuité"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.audio', 'texte', null, 35, '{"v":"Un mode audio, entièrement lu à voix haute, est proposé aux personnes aveugles ou malvoyantes.","cle":"recit.audio","groupe":"Présentation (visite et vidéo)","libelle":"Mode audio"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.expansion', 'texte', null, 36, '{"v":"La connaissance, comme l''univers, est en expansion.","cle":"recit.expansion","groupe":"Présentation (visite et vidéo)","libelle":"Fin"}'::jsonb, 'publie', now(), now()),
  ('texte.recit.fin', 'texte', null, 37, '{"v":"À vous d''explorer : cherchez une notion, franchissez les trous de ver, tracez votre constellation.","cle":"recit.fin","groupe":"Présentation (visite et vidéo)","libelle":"Carte finale"}'::jsonb, 'publie', now(), now()),
  ('texte.apropos.intro', 'texte', null, 38, '{"v":"Galapsy est un atlas des savoirs sur la souffrance psychique. Chaque galaxie est une façon de l''aborder : par l''histoire, le vécu, le cerveau, la société, la culture… Chaque notion distingue le fait établi, l''interprétation et la controverse, et renvoie à ses sources.","cle":"apropos.intro","groupe":"À propos","libelle":"Présentation"}'::jsonb, 'publie', now(), now()),
  ('texte.apropos.gratuite_titre', 'texte', null, 39, '{"v":"une application entièrement gratuite","cle":"apropos.gratuite_titre","groupe":"À propos","libelle":"Titre de la gratuité"}'::jsonb, 'publie', now(), now()),
  ('texte.apropos.gratuite', 'texte', null, 40, '{"v":"Galapsy est gratuite : sans abonnement, sans publicité et sans revente de données. Elle le restera, pour trois raisons.","cle":"apropos.gratuite","groupe":"À propos","libelle":"Gratuité"}'::jsonb, 'publie', now(), now()),
  ('texte.apropos.raison1', 'texte', null, 41, '{"v":"**C''est un savoir partagé.** Les contributeurs donnent leur temps et leurs sources ; ce qu''ils construisent ensemble ne doit pas leur être revendu.","cle":"apropos.raison1","groupe":"À propos","libelle":"Raison 1"}'::jsonb, 'publie', now(), now()),
  ('texte.apropos.raison2', 'texte', null, 42, '{"v":"**Tout le monde doit pouvoir y accéder.** Patients, proches, étudiants et soignants, quels que soient leurs moyens, consultent le même atlas.","cle":"apropos.raison2","groupe":"À propos","libelle":"Raison 2"}'::jsonb, 'publie', now(), now()),
  ('texte.apropos.raison3', 'texte', null, 43, '{"v":"**La gratuité garantit l''indépendance.** Aucune école de pensée ne finance l''atlas ; aucune ne peut donc l''orienter.","cle":"apropos.raison3","groupe":"À propos","libelle":"Raison 3"}'::jsonb, 'publie', now(), now()),
  ('texte.apropos.aide', 'texte', null, 44, '{"v":"Une planète n''est pas un diagnostic : cet atlas décrit des façons de penser les troubles, pas des personnes. Si vous traversez une période difficile, le 3114 (numéro national de prévention du suicide) répond jour et nuit.","cle":"apropos.aide","groupe":"À propos","libelle":"Mention de prévention"}'::jsonb, 'publie', now(), now()),
  ('texte.fiche.planete', 'texte', null, 45, '{"v":"Une planète n''est pas un diagnostic. Cet atlas décrit des manières de penser les troubles, pas des personnes.","cle":"fiche.planete","groupe":"Fiches","libelle":"Bas de fiche d''une planète"}'::jsonb, 'publie', now(), now()),
  ('texte.fiche.etoile', 'texte', null, 46, '{"v":"Un savoir n''est jamais acquis. Certaines étoiles de cet atlas sont marquées instables : elles peuvent imploser et projeter de la matière ailleurs.","cle":"fiche.etoile","groupe":"Fiches","libelle":"Bas de fiche d''une étoile"}'::jsonb, 'publie', now(), now()),
  ('texte.fiche.zone', 'texte', null, 47, '{"v":"L''atlas n''est jamais clos. Une zone se cartographie quand quelqu''un accepte d''en sourcer le contenu, aux mêmes conditions que partout ailleurs : fait établi, interprétation, controverse, et des sources en lien dont la nature est déclarée. Ces {zones} zones ne sont pas les dernières : elles sont seulement celles qu''on a déjà repérées.","cle":"fiche.zone","groupe":"Fiches","libelle":"Bas de fiche d''une zone non cartographiée"}'::jsonb, 'publie', now(), now()),
  ('texte.fiche.trou', 'texte', null, 48, '{"v":"Vous arrivez sur le même objet, vu par une autre approche. Les deux lectures ne se situent pas au même niveau : c''est en les comparant qu''on comprend mieux.","cle":"fiche.trou","groupe":"Fiches","libelle":"Bandeau après un trou de ver"}'::jsonb, 'publie', now(), now())
on conflict (id) do update set ordre = excluded.ordre, donnees = excluded.donnees, maj_le = now()
  where galapsy.objets.cree_par is null and not exists (select 1 from galapsy.revisions r where r.objet = galapsy.objets.id and r.justification is distinct from 'Corpus fondateur');
-- la version d'origine de chaque texte, dans l'historique
update galapsy.revisions r set donnees = o.donnees
  from galapsy.objets o
 where r.objet = o.id and o.type = 'texte' and r.justification = 'Corpus fondateur'
   and not exists (select 1 from galapsy.revisions x where x.objet = o.id and x.justification is distinct from 'Corpus fondateur');
insert into galapsy.revisions(objet, action, donnees, justification, auteur, statut, cree_le, modere_le)
select id, 'creation', donnees, 'Corpus fondateur', null, 'acceptee', cree_le, cree_le
  from galapsy.objets o where type = 'texte' and not exists (select 1 from galapsy.revisions r where r.objet = o.id);

-- ============================================================
-- 5. Compte fondateur : l'adresse qui se connecte et signe la charte
--    reçoit le rôle d'administrateur ; il ne peut pas être rétrogradé.
-- ============================================================
insert into galapsy.config(cle, valeur) values ('email_admin', 'william.morvant24@gmail.com')
on conflict (cle) do update set valeur = excluded.valeur;
