/* ============================================================
   GALAPSY' — l'atlas, en plus
   Recherche par mot, suggestions de placement, fond sonore,
   visite guidée d'ouverture, « À propos », sources cliquables.
   Se charge juste après le moteur ; fonctionne sans compte
   et hors ligne.
   ============================================================ */
(function () {
"use strict";

const CLE_SON = "galapsy.son", CLE_INTRO = "galapsy.intro.v1";
const lire = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
const ecrire = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { } };
const $ = s => document.querySelector(s);
const attendre = ms => new Promise(r => setTimeout(r, ms));

/* ---------- nombres en toutes lettres (galaxies et zones sont féminines) ---------- */
const NB = ["aucune", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "douze",
  "treize", "quatorze", "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf", "vingt"];
const enLettres = n => (window.LNB || NB)[n] || String(n);
const majuscule = s => s.charAt(0).toUpperCase() + s.slice(1);
function majNombres() {
  document.querySelectorAll("[data-nb]").forEach(e => {
    const v = e.dataset.nb, n = /^gal/i.test(v) ? GAL.length : FRONT.length;
    e.textContent = v[0] === v[0].toUpperCase() ? majuscule(enLettres(n)) : enLettres(n);
  });
}

/* ============================================================
   TEXTES DU SITE (modifiables par les administrateurs)
   *italique*, **gras**, [mot en couleur], {galaxies} {Galaxies} {zones} {Zones}
   ============================================================ */
const DEFAUTS = /*TEXTES*/{"porte.question": "D'où vient la *souffrance psychique* ?", "porte.texte": "Toute la matière du savoir psy tient d'abord dans cette seule question, comprimée. Aucune réponse ne la soutient seule : elle s'effondre, et l'effondrement projette {galaxies} manières de répondre. C'est la première dispersion — tout le reste en descend.", "porte.bouton": "Big Bang (Effondrement psychique)", "porte.sous": "les {galaxies} approches apparaîtront une à une", "porte.gratuite": "application entièrement gratuite, sans publicité", "releve.titre": "{Galaxies} manières de répondre", "releve.sous": "issues de l'effondrement · chacune est une galaxie", "releve.pied1": "Ces {galaxies} galaxies sont autant de façons d'aborder la souffrance psychique. Un même objet clinique — la mélancolie, la schizophrénie, le trauma — apparaît dans plusieurs d'entre elles, sous des angles différents. Les [trous de ver] relient ces points de vue : c'est en passant de l'un à l'autre qu'on le comprend vraiment.", "releve.pied2": "{Galaxies} n'est pas un total. Au bord du cosmos dérivent {zones} [zones non cartographiées] — et elles ne sont que celles qu'on a déjà repérées.", "recit.prelude": "première sortie · secteur inexploré", "recit.porte": "Touchez « Big Bang » pour commencer.", "recit.dispersion": "Aucune réponse ne suffit à elle seule. La question se divise en {galaxies} façons d'aborder la souffrance psychique.", "recit.releve": "Le relevé présente chaque approche et son hypothèse centrale.", "recit.galaxies": "Chaque galaxie est une approche, avec sa propre question, ses méthodes et ses concepts. Aucune ne détient seule la vérité : chacune éclaire une part du réel.", "recit.zoom": "Écartez deux doigts pour vous approcher, glissez pour parcourir le cosmos. Touchez une galaxie pour y entrer.", "recit.etoiles": "Dans chaque galaxie brillent des étoiles : les écoles et les courants de pensée, situés dans le temps.", "recit.planetes": "Autour de chaque étoile gravitent des planètes : les notions cliniques. Leurs satellites sont les sources qui les documentent.", "recit.fiche": "Chaque planète distingue trois niveaux : le fait établi, l'interprétation et la controverse.", "recit.satellites": "La couleur d'un satellite indique la nature de la source, et donc son degré de certitude : source primaire, méta-analyse, étude, essai, témoignage, texte de loi.", "recit.instable": "Un savoir n'est jamais acquis. Certaines catégories s'effondrent et donnent naissance à d'autres.", "recit.heritiers": "L'hystérie a quitté les classifications ; sa matière se répartit aujourd'hui entre {heritiers}.", "recit.trou": "Une même notion apparaît dans plusieurs galaxies. Un trou de ver relie ces points de vue et invite à les comparer.", "recit.escales": "Chaque galaxie répond à sa manière. Voici leurs hypothèses.", "recit.constellation": "Chaque notion consultée s'inscrit dans votre constellation : la trace de votre parcours.", "recit.frontiere": "Au bord du cosmos, {zones} régions restent à cartographier.", "recit.recherche": "La loupe permet de trouver une notion, un auteur ou une source.", "recit.creation": "Si une notion manque, chacun peut la proposer, source à l'appui : une galaxie, une étoile, une planète ou un satellite.", "recit.regles_titre": "Règles de la communauté", "recit.regle1": "**Joignez une source en lien à chaque proposition** : adresse web, DOI ou ISBN. Sans lien, elle n'est pas reçue.", "recit.regle2": "**Déclarez honnêtement la nature de la source** : sa couleur en dépend.", "recit.regle3": "**Distinguez** le fait établi, l'interprétation et la controverse.", "recit.regle4": "**Décrivez des notions, jamais des personnes** : aucune donnée personnelle, aucun conseil médical.", "recit.regles_pied": "Un administrateur vérifie chaque proposition avant sa publication, et chaque version reste consultable. La fiabilité de l'atlas dépend de chacun.", "recit.gratuite": "Galapsy est gratuite, sans publicité ni revente de données : un savoir partagé doit rester accessible à tous.", "recit.audio": "Un mode audio, entièrement lu à voix haute, est proposé aux personnes aveugles ou malvoyantes.", "recit.expansion": "La connaissance, comme l'univers, est en expansion.", "recit.fin": "À vous d'explorer : cherchez une notion, franchissez les trous de ver, tracez votre constellation.", "apropos.intro": "Galapsy est un atlas des savoirs sur la souffrance psychique. Chaque galaxie est une façon de l'aborder : par l'histoire, le vécu, le cerveau, la société, la culture… Chaque notion distingue le fait établi, l'interprétation et la controverse, et renvoie à ses sources.", "apropos.gratuite_titre": "une application entièrement gratuite", "apropos.gratuite": "Galapsy est gratuite : sans abonnement, sans publicité et sans revente de données. Elle le restera, pour trois raisons.", "apropos.raison1": "**C'est un savoir partagé.** Les contributeurs donnent leur temps et leurs sources ; ce qu'ils construisent ensemble ne doit pas leur être revendu.", "apropos.raison2": "**Tout le monde doit pouvoir y accéder.** Patients, proches, étudiants et soignants, quels que soient leurs moyens, consultent le même atlas.", "apropos.raison3": "**La gratuité garantit l'indépendance.** Aucune école de pensée ne finance l'atlas ; aucune ne peut donc l'orienter.", "apropos.aide": "Une planète n'est pas un diagnostic : cet atlas décrit des façons de penser les troubles, pas des personnes. Si vous traversez une période difficile, le 3114 (numéro national de prévention du suicide) répond jour et nuit.", "fiche.planete": "Une planète n'est pas un diagnostic. Cet atlas décrit des manières de penser les troubles, pas des personnes.", "fiche.etoile": "Un savoir n'est jamais acquis. Certaines étoiles de cet atlas sont marquées instables : elles peuvent imploser et projeter de la matière ailleurs.", "fiche.zone": "L'atlas n'est jamais clos. Une zone se cartographie quand quelqu'un accepte d'en sourcer le contenu, aux mêmes conditions que partout ailleurs : fait établi, interprétation, controverse, et des sources en lien dont la nature est déclarée. Ces {zones} zones ne sont pas les dernières : elles sont seulement celles qu'on a déjà repérées.", "fiche.trou": "Vous arrivez sur le même objet, vu par une autre approche. Les deux lectures ne se situent pas au même niveau : c'est en les comparant qu'on comprend mieux."}/*FIN*/;
function T(cle) {
  const v = (window.GALAPSY_TEXTES || {})[cle];
  const fr = v != null && String(v).trim() !== "" ? String(v) : (DEFAUTS[cle] || "");
  return window.GALAPSY_LANGUE ? GALAPSY_LANGUE.texte(fr) : fr;
}
function remplir(v) {
  const g = enLettres(GAL.length), z = enLettres(FRONT.length);
  return String(v).replace(/\{Galaxies\}/g, majuscule(g)).replace(/\{galaxies\}/g, g)
    .replace(/\{Zones\}/g, majuscule(z)).replace(/\{zones\}/g, z);
}
function formater(v) {
  return esc(remplir(v)).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\*(.+?)\*/g, "<i>$1</i>")
    .replace(/\[(.+?)\]/g, '<span class="t-cle">$1</span>').replace(/\n/g, "<br>");
}
const brut = v => remplir(v).replace(/\*\*(.+?)\*\*/g, "$1").replace(/\*(.+?)\*/g, "$1").replace(/\[(.+?)\]/g, "$1");
window.TXT = cle => formater(T(cle));
window.TXTBRUT = cle => brut(T(cle));
function appliquerTextes() {
  document.querySelectorAll("[data-texte]").forEach(e => { e.innerHTML = formater(T(e.dataset.texte)); });
}

/* ============================================================
   RECHERCHE
   ============================================================ */
const norm = s => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
const VIDES = new Set("le la les l de des du d un une et en au aux a à par pour sur dans ou ce qui que quoi est son sa ses leur".split(" "));
const SYNONYMES = {
  adhd: ["attention", "hyperactivity", "neurodiversity"], ocd: ["obsessive", "compulsive"],
  autism: ["autistic", "spectrum", "neurodiversity"], bipolar: ["mania", "manic", "mood"],
  schizophrenia: ["psychosis", "dementia", "praecox"], psychosis: ["schizophrenia", "delusion", "psychotic"], voices: ["hallucinations", "hearing"],
  eating: ["anorexia", "bulimia"], hysteria: ["conversion", "functional"],
  tsa: ["autisme", "spectre"], autisme: ["tsa", "neurodiversite"], asperger: ["autisme", "tsa"],
  tdah: ["attention", "hyperactivite", "neurodiversite"], dys: ["dyslexie", "neurodiversite"], dyslexie: ["dys", "neurodiversite"],
  toc: ["obsessionnel", "compulsif"], tspt: ["trauma", "stress"], ptsd: ["trauma", "tspt"], psychotrauma: ["trauma"],
  bipolaire: ["maniaco", "humeur", "bipolarite"], bipolarite: ["bipolaire", "maniaco"],
  depression: ["melancolie", "humeur", "depressif", "melancholia", "mood", "depressive"], melancolie: ["depression"],
  schizophrenie: ["psychose", "demence", "precoce"], psychose: ["schizophrenie", "delire", "psychotique"],
  addiction: ["addictions", "dependance", "toxicomanie", "dependence", "substance"], dependance: ["addiction"], toxicomanie: ["addiction"],
  alcool: ["addiction"], drogue: ["addiction"], cannabis: ["addiction"],
  anorexie: ["alimentaire"], boulimie: ["alimentaire"], tca: ["alimentaire", "anorexie"],
  burnout: ["epuisement", "travail"], burn: ["burnout", "epuisement"], suicide: ["suicidaire", "suicidal"], hysterie: ["conversion", "fonctionnel"],
  alzheimer: ["demence", "age"], demence: ["alzheimer"], vieillissement: ["age"],
  enfant: ["enfance"], ado: ["adolescence"], adolescent: ["adolescence"],
  internement: ["contrainte", "placement"], hospitalisation: ["contrainte", "consentement"],
  serotonine: ["monoamines"], dopamine: ["dopaminergique"], tcc: ["cognitive", "comportementale"],
  psychanalyse: ["inconscient", "freud"], phenomenologie: ["vecu"], stigmate: ["stigmatisation"]
};
/* mots-clés de chaque galaxie et de chaque zone non cartographiée, pour orienter les suggestions */
const MOTS = {
  hist: "histoire asile alieniste aliene nosographie categorie epoque internement salpetriere charcot kraepelin xixe",
  pheno: "vecu experience conscience corps temps monde ipseite phenomenologie husserl minkowski binswanger existence hallucination hallucinations delire depersonnalisation",
  epist: "diagnostic classification dsm cim validite categorie normal pathologique definition trouble critere preuve surdiagnostic medicalisation",
  psy: "inconscient refoulement freud lacan psychanalyse conflit transfert structure nevrose psychose pulsion angoisse perversion deuil melancolie",
  neuro: "cerveau neurone dopamine serotonine genetique imagerie molecule medicament psychotrope circuit biologie inflammation sommeil epilepsie hallucinations",
  cog: "cognition pensee schema croyance apprentissage tcc comportement conditionnement attention biais memoire emotion anxiete phobie panique obsession anorexie boulimie alimentaire",
  soc: "societe precarite pauvrete travail discrimination inegalite migration social politique pouvoir determinants burnout epuisement chomage isolement solitude",
  anthro: "culture transculturel rituel ethnopsychiatrie croyance possession pays anthropologie migration transe exil",
  dev: "enfance developpement trauma attachement adolescence trajectoire precoce maltraitance resilience psychotrauma traumatisme abus violence harcelement",
  jur: "loi droit contrainte hospitalisation consentement responsabilite penal tutelle justice expertise isolement contention",
  exp: "patient usager pair temoignage experience retablissement voix entendeurs savoirs association pairaidance",
  repr: "art recit cinema litterature image representation stigmatisation medias folie roman stereotype",
  f1: "addiction addictions dependance alcool drogue toxicomanie cannabis opioide tabac jeu sevrage reduction risques usage",
  f2: "enfant enfance adolescent adolescence pedopsychiatrie ecole scolaire protection mineur",
  f3: "autisme tsa tdah dys dyslexie neurodiversite neuroatypique asperger hyperactivite",
  f4: "demence alzheimer vieillissement age agee ehpad fin vie isolement",
  f5: "pharma industrie financement essais cliniques acces soins cout economie laboratoire",
  f6: "spiritualite religion rituel sens chamanisme meditation foi croyance soin"
};

/* synonymes d'un mot : exacts, ou par préfixe (« psychotraumatisme » → « psychotrauma ») */
function synonymes(t) {
  if (SYNONYMES[t]) return SYNONYMES[t];
  const k = Object.keys(SYNONYMES).find(k => k.length >= 5 && t.startsWith(k));
  return k ? [k].concat(SYNONYMES[k]) : [];
}
function jetons(q) {
  let base = norm(q).split(/[^a-z0-9]+/).filter(t => t && !VIDES.has(t));
  const compact = norm(q).replace(/[^a-z0-9]/g, "");          // « burn-out » → « burnout »
  if (base.length > 1 && SYNONYMES[compact]) base = [compact];
  const out = new Set(base);
  base.forEach(t => synonymes(t).forEach(s => out.add(s)));
  return { base, tous: [...out] };
}
const racine = t => t.length > 5 ? t.slice(0, t.length - 2) : t;   // « addictions » ≈ « addiction »
function contient(texte, t) {
  if (t.length <= 3) return new RegExp("(^|[^a-z0-9])" + t + "([^a-z0-9]|$)").test(texte);
  return texte.includes(racine(t));
}

/* tout l'atlas à plat, avec un texte normalisé par élément */
function index() {
  const items = [];
  GAL.forEach(g => {
    items.push({ type: "galaxie", g, nom: g.n, sous: g.s, texte: norm([g.n, g.s, g.r, g.d, g.th, MOTS[g.id] || ""].join(" ")), nomN: norm(g.n) });
    const sys = [];
    g.sy.forEach(s => { sys.push(s); if (s.nova && !s._done) s.nova.gen.forEach(x => sys.push(x)); });
    sys.forEach(s => {
      items.push({ type: "systeme", g, s, nom: s.n, sous: g.n, texte: norm([s.n, s.s, s.r].join(" ")), nomN: norm(s.n) });
      s.pl.forEach(p => {
        items.push({ type: "planete", g, s, p, nom: p.n, sous: g.n + " › " + s.n,
          texte: norm([p.n, p.r, p.f, p.i, p.c].join(" ")), nomN: norm(p.n) });
        (p.so || []).forEach(m => items.push({ type: "lune", g, s, p, m, nom: m.t, sous: m.a + " · " + p.n,
          texte: norm([m.t, m.a].join(" ")), nomN: norm(m.t + " " + m.a) }));   // un auteur se cherche comme un titre
      });
    });
  });
  FRONT.forEach(f => items.push({ type: "zone", f, nom: f.n, sous: "zone non cartographiée",
    texte: norm([f.n, f.d, MOTS[f.id] || ""].join(" ")), nomN: norm(f.n) }));
  return items;
}

function chercher(q) {
  const { base, tous } = jetons(q);
  if (!base.length) return [];
  const poidsType = { planete: 4, galaxie: 3, systeme: 3, zone: 2, lune: 1 };
  return index().map(it => {
    let score = 0, trouves = 0;
    base.forEach(t => {
      const syn = [t].concat(synonymes(t));
      let meilleur = 0;
      syn.forEach((x, i) => {
        const coef = i ? .7 : 1;
        if (contient(it.nomN, x)) meilleur = Math.max(meilleur, 10 * coef);
        else if (contient(it.texte, x)) meilleur = Math.max(meilleur, 3 * coef);
      });
      if (meilleur) trouves++;
      score += meilleur;
    });
    if (trouves < base.length) return null;          // tous les mots doivent trouver un écho
    if (it.nomN === norm(q).trim()) score += 20;
    return { it, score: score + poidsType[it.type] };
  }).filter(Boolean).sort((a, b) => b.score - a.score).map(x => x.it);
}

/* Où placer une notion nouvelle ? Planètes proches, systèmes, galaxies, zones.
   Les mots trop généraux (« trouble », « syndrome »…) ne comptent pas : ils sont partout. */
const GENERIQUES = new Set("trouble troubles syndrome syndromes maladie maladies pathologie souffrance psychique psychiatrique mental mentale notion".split(" "));
function suggerer(q, description) {
  const base = jetons(q + " " + (description || "")).base.filter(t => !GENERIQUES.has(t) && t.length > 1);
  if (!base.length) return { existantes: [], systemes: [], galaxies: [], zones: [] };
  const variantes = base.map(t => [t].concat(synonymes(t)));
  // un mot de la requête est-il présent (lui ou un synonyme) ?
  const echo = (texte, poids) => variantes.reduce((sc, vs) => sc + (vs.some((x, i) => contient(texte, x)) ? poids : 0), 0);
  const tousDans = texte => variantes.every(vs => vs.some(x => contient(texte, x)));
  const items = index();
  const planetes = items.filter(x => x.type === "planete");
  const existantes = planetes.filter(x => tousDans(x.nomN)).slice(0, 3).map(x => ({ g: x.g, s: x.s, p: x.p }));
  const systemes = items.filter(x => x.type === "systeme").map(x => {
    const scP = planetes.filter(p => p.s === x.s).map(p => ({ p, sc: echo(p.nomN, 6) + echo(p.texte, 1) }))
      .filter(y => y.sc > 0).sort((u, v) => v.sc - u.sc);
    const sc = echo(x.nomN, 8) + echo(x.texte, 2) + scP.slice(0, 2).reduce((t, y) => t + y.sc, 0)
      + echo(norm(MOTS[x.g.id] || ""), 1);
    return { g: x.g, s: x.s, score: sc, proches: scP.slice(0, 3).map(y => y.p.p.n) };
  }).filter(x => x.score >= 3).sort((u, v) => v.score - u.score).slice(0, 3);
  const galaxies = GAL.map(g => ({ g, score: echo(norm(MOTS[g.id] || ""), 4) + echo(norm([g.n, g.s, g.d, g.th, g.r].join(" ")), 2)
      + Math.max(0, ...systemes.filter(x => x.g === g).map(x => x.score)) * .3 }))
    .filter(x => x.score > 0).sort((u, v) => v.score - u.score).slice(0, 3);
  const zones = FRONT.map(f => ({ f, score: echo(norm(f.n), 10) + echo(norm(MOTS[f.id] || ""), 4) + echo(norm(f.d), 1) }))
    .filter(x => x.score >= 4).sort((u, v) => v.score - u.score).slice(0, 1);
  return { existantes, systemes, galaxies, zones, zoneForte: zones.length > 0 && zones[0].score >= 10 };
}

/* aller à un élément trouvé */
function aller(it) {
  const fermer = () => { closePanel(); disp.hidden = true; over.hidden = true; fermerFeuille(); };
  fermer();
  if (it.type === "zone") {
    if (state.level !== "cosmos") go("cosmos", null, null, W / 2, H / 2, -1);
    setTimeout(() => openFront(it.f.id), REDUCED ? 0 : 520);
    return;
  }
  if (it.type === "galaxie") {
    if (state.level !== "cosmos") { state.level = "cosmos"; state.gal = null; state.sys = null; }
    const i = GAL.indexOf(it.g), p = cosmosPos(i);
    go("galaxy", it.g.id, null, p.x, p.y, 1);
    return;
  }
  if (it.g.sy.indexOf(it.s) < 0) {
    const mere = it.g.sy.find(s => s.nova && s.nova.gen.includes(it.s));
    if (mere && !mere._done) { mere._done = true; mere.nova.gen.forEach(x => { x._born = true; it.g.sy.push(x); }); }
  }
  go("system", it.g.id, it.s.id, W / 2, H / 2, 1);
  setTimeout(() => it.type === "systeme" ? openStar(it.g.id, it.s.id) : openPlanet(it.g.id, it.s.id, it.p.id), REDUCED ? 0 : 520);
}

/* ---------- feuille de recherche ---------- */
let feuille = null;
function fermerFeuille() { if (feuille) feuille.hidden = true; }
function ouvrirFeuille(titre, html, surtitre) {
  if (!feuille) {
    feuille = document.createElement("div");
    feuille.className = "over a-feuille"; feuille.hidden = true;
    feuille.setAttribute("role", "dialog"); feuille.setAttribute("aria-modal", "true");
    feuille.innerHTML = `<div class="over-head"><div><p class="c-eyebrow" id="aSur"></p><h3 id="aTitre"></h3></div>
      <button class="btn" type="button" id="aFermer">Fermer</button></div><div class="c-corps" id="aCorps"></div>`;
    document.body.appendChild(feuille);
    feuille.querySelector("#aFermer").onclick = fermerFeuille;
    addEventListener("keydown", e => { if (e.key === "Escape" && !feuille.hidden) { e.stopImmediatePropagation(); fermerFeuille(); } }, true);
  }
  feuille.querySelector("#aTitre").textContent = titre;
  feuille.querySelector("#aSur").textContent = surtitre || "";
  const c = feuille.querySelector("#aCorps");
  c.innerHTML = html; c.scrollTop = 0;
  feuille.hidden = false;
  return c;
}

const TYPES = { galaxie: "galaxie", systeme: "étoile", planete: "planète", lune: "satellite · source", zone: "zone" };
function teinte(it) { return it.g ? `hsl(${it.g.hue},60%,72%)` : "rgba(190,182,224,.9)"; }

/* Les quatre objets que l'on peut créer, définis selon le modèle Galapsy′ */
const CREATIONS = [
  { type: "galaxie", nom: "Galaxie", def: "Une manière d'aborder la souffrance psychique : un regard propre, avec sa question, ses méthodes et ses concepts." },
  { type: "etoile", nom: "Étoile", def: "Une école, un courant ou un foyer de pensée au sein d'une galaxie, situé dans le temps et rattaché à des auteurs." },
  { type: "planete", nom: "Planète", def: "Une notion clinique ou un concept, décrit en trois niveaux : le fait établi, l'interprétation et la controverse. Elle gravite autour d'une étoile." },
  { type: "satellite", nom: "Satellite", def: "Une source vérifiable qui documente une planète : ouvrage, article, étude, texte de loi ou témoignage publié. Sa couleur indique sa nature et son degré de certitude." }
];
const ICONES_CREATION = {
  galaxie: `<svg viewBox="0 0 40 40" aria-hidden="true"><ellipse cx="20" cy="20" rx="15" ry="6.5" fill="none" stroke="currentColor" stroke-width="1.3" transform="rotate(-24 20 20)"/><circle cx="20" cy="20" r="3.4" fill="currentColor"/><circle cx="9" cy="14" r="1" fill="currentColor"/><circle cx="31" cy="27" r="1" fill="currentColor"/></svg>`,
  etoile: `<svg viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="5" fill="currentColor"/><circle cx="20" cy="20" r="10" fill="none" stroke="currentColor" stroke-width="1" opacity=".45"/><path d="M20 4v6M20 30v6M4 20h6M30 20h6" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>`,
  planete: `<svg viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="7.5" fill="currentColor"/><ellipse cx="20" cy="20" rx="15" ry="4.5" fill="none" stroke="currentColor" stroke-width="1.3" transform="rotate(-18 20 20)"/></svg>`,
  satellite: `<svg viewBox="0 0 40 40" aria-hidden="true"><circle cx="17" cy="21" r="7" fill="currentColor" opacity=".55"/><circle cx="17" cy="21" r="12" fill="none" stroke="currentColor" stroke-width="1" stroke-dasharray="2 3"/><circle cx="29" cy="12" r="3" fill="currentColor"/></svg>`
};
function creationHTML(ouvert) {
  return `<div class="a-creation${ouvert ? " ouvert" : ""}">
    <button class="a-creation-tete" type="button" id="aCreationBtn" aria-expanded="${ouvert ? "true" : "false"}">
      <span class="a-plus" aria-hidden="true">＋</span><span><b>Création</b><small>proposer une galaxie, une étoile, une planète ou un satellite</small></span></button>
    <div class="a-creation-corps" id="aCreationCorps" ${ouvert ? "" : "hidden"}>
      <div class="a-types">${CREATIONS.map(c => `<button type="button" class="a-type-creation" data-creer="${c.type}">
        <span class="a-ico">${ICONES_CREATION[c.type]}</span><span><b>${c.nom}</b><small>${esc(c.def)}</small></span></button>`).join("")}</div>
      <p class="a-regle">Toute proposition comporte une source en lien : adresse web, DOI ou ISBN. Un administrateur la vérifie avant de la publier.</p>
    </div>
  </div>`;
}
function brancherCreation(c) {
  const btn = c.querySelector("#aCreationBtn"), corps = c.querySelector("#aCreationCorps");
  btn.onclick = () => {
    const ouvrir = corps.hidden;
    corps.hidden = !ouvrir; btn.setAttribute("aria-expanded", String(ouvrir));
    btn.parentElement.classList.toggle("ouvert", ouvrir);
  };
  c.querySelectorAll("[data-creer]").forEach(b => b.onclick = () => {
    const P = window.GALAPSY_PLATEFORME;
    if (P && P.actif) { fermerFeuille(); P.creerType(b.dataset.creer); }
    else toastAtlas("La création sera disponible une fois l'atlas partagé mis en ligne.");
  });
}
function toastAtlas(msg) {
  const t = document.createElement("div");
  t.className = "a-toast"; t.setAttribute("role", "status"); t.textContent = msg;
  document.body.appendChild(t); setTimeout(() => t.remove(), 4200);
}

function ouvrirRecherche(q0, creationOuverte) {
  const c = ouvrirFeuille("Chercher dans l'atlas", `
    <input class="c-recherche a-champ" type="search" id="aQ" placeholder="Une notion, un auteur, un mot… (par ex. trauma, TSA, Foucault)" autocomplete="off" enterkeyhint="search">
    ${creationHTML(!!creationOuverte)}
    <div id="aRes" class="a-res" aria-live="polite"></div>`, "recherche");
  brancherCreation(c);
  const champ = c.querySelector("#aQ"), res = c.querySelector("#aRes");
  const rendre = () => {
    const q = champ.value.trim();
    if (q.length < 2) { res.innerHTML = `<p class="c-vide">Tapez au moins deux lettres. La recherche fonctionne aussi sans connexion.</p>`; return; }
    const r = chercher(q).slice(0, 40);
    const plateforme = window.GALAPSY_PLATEFORME && window.GALAPSY_PLATEFORME.actif;
    let html = r.length ? `<ul class="a-liste">${r.map((it, i) => `<li><button type="button" data-i="${i}">
        <span class="a-type" style="color:${teinte(it)}">${esc(TYPES[it.type])}</span>
        <b>${esc(it.nom)}</b><small>${esc(it.sous || "")}</small></button></li>`).join("")}</ul>`
      : `<p class="c-vide">${Lf("« {q} » n'apparaît pas encore dans l'atlas.", { q: esc(q) })}</p>`;
    if (q.length >= 3) html += plateforme
      ? `<div class="a-creer"><p>${r.some(x => x.type === "planete" && x.nomN === norm(q)) ? "Cette notion existe déjà : vous pouvez lui ajouter une source depuis sa fiche."
          : Lf("La notion « <b>{q}</b> » n'existe pas encore ? Proposez-la, sources à l'appui : Galapsy vous aide à choisir où la placer.", { q: esc(q) })}</p>
          <button class="c-go" type="button" id="aCreer">${Lf("Proposer « {q} »", { q: esc(q.length > 28 ? q.slice(0, 28) + "…" : q) })}</button></div>`
      : "";
    res.innerHTML = html;
    res.querySelectorAll("[data-i]").forEach(b => b.onclick = () => aller(r[+b.dataset.i]));
    const cr = res.querySelector("#aCreer");
    if (cr) cr.onclick = () => { fermerFeuille(); window.GALAPSY_PLATEFORME.creer(q); };
  };
  champ.oninput = rendre;
  champ.value = q0 || "";
  rendre();
  if (!creationOuverte) setTimeout(() => champ.focus(), 50);
  return c;
}

/* ============================================================
   SOURCES CLIQUABLES (lunes)
   ============================================================ */
function lienSource(so) {
  const r = String(so.ref || "").trim();
  if (/^https?:\/\/\S+$/i.test(r)) return { href: r, verifie: true };
  const doi = r.match(/(?:doi:?\s*)?(10\.\d{4,9}\/\S+)/i);
  if (doi) return { href: "https://doi.org/" + doi[1], verifie: true };
  const isbn = r.replace(/[^0-9Xx]/g, "");
  if (/isbn/i.test(r) && (isbn.length === 10 || isbn.length === 13)) return { href: "https://www.google.com/search?tbm=bks&q=isbn:" + isbn, verifie: true };
  const q = encodeURIComponent(`"${so.t}" ${so.a || ""}`.trim());
  return { href: so.k === "droit" ? "https://www.google.com/search?q=" + q : "https://scholar.google.com/scholar?q=" + q, verifie: false };
}
function brancherLunes() {
  moonHTML = function (so) {
    const k = K[so.k] || K.essai, l = lienSource(so);
    return `<li class="moon">
      <span class="orb" style="border-color:${k.c};background:${k.c}22"></span>
      <span><a class="t a-src" href="${esc(l.href)}" target="_blank" rel="noopener noreferrer">${esc(so.t)}</a><span class="a">${esc(so.a)}</span>
      <span class="k" style="color:${k.c};border-color:${k.c}55;background:${k.c}12">${esc(k.l)}</span>
      <span class="a-meta">${L(l.verifie ? "consulter la source ↗" : "rechercher la source ↗")}${so._par ? Lf(" · ajouté par {p}", { p: esc(so._par) }) : ""}</span></span>
    </li>`;
  };
}

/* ============================================================
   FOND SONORE (généré, aucun fichier) — très discret
   ============================================================ */
const son = {
  actif: lire(CLE_SON) !== "off",
  ctx: null, maitre: null, pret: false,
  demarrer() {
    if (!this.actif) return majBoutonsSon();
    try {
      if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        const c = this.ctx = new AC();
        const comp = c.createDynamicsCompressor(); comp.connect(c.destination);
        const m = this.maitre = c.createGain(); m.gain.value = 0; m.connect(comp);
        // nappe : quinte grave, légèrement désaccordée, qui respire
        const filtre = c.createBiquadFilter(); filtre.type = "lowpass"; filtre.frequency.value = 700; filtre.Q.value = .4; filtre.connect(m);
        [[55, "sine", .5], [82.41, "sine", .32], [110, "triangle", .12], [164.81, "sine", .06]].forEach(([f, t, g], i) => {
          const o = c.createOscillator(), gg = c.createGain();
          o.type = t; o.frequency.value = f; o.detune.value = (i % 2 ? 1 : -1) * 4;
          gg.gain.value = g; o.connect(gg); gg.connect(filtre); o.start();
          const lfo = c.createOscillator(), lg = c.createGain();
          lfo.frequency.value = .021 + i * .013; lg.gain.value = g * .45;
          lfo.connect(lg); lg.connect(gg.gain); lfo.start();
        });
        // souffle cosmique : bruit brun filtré
        const n = c.sampleRate * 3, buf = c.createBuffer(1, n, c.sampleRate), d = buf.getChannelData(0);
        let last = 0;
        for (let i = 0; i < n; i++) { last = (last + .02 * (Math.random() * 2 - 1)) / 1.02; d[i] = last * 3.2; }
        const src = c.createBufferSource(); src.buffer = buf; src.loop = true;
        const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 380; bp.Q.value = .7;
        const sg = c.createGain(); sg.gain.value = .22;
        src.connect(bp); bp.connect(sg); sg.connect(m); src.start();
        const lfo = c.createOscillator(), lg = c.createGain();
        lfo.frequency.value = .035; lg.gain.value = 170; lfo.connect(lg); lg.connect(bp.frequency); lfo.start();
        this.bruit = buf;
      }
      if (this.ctx.state === "suspended") this.ctx.resume();
      const t = this.ctx.currentTime;
      this.maitre.gain.cancelScheduledValues(t);
      this.maitre.gain.setTargetAtTime(.075, t, 1.8);
      this.pret = true;
    } catch (e) { }
    majBoutonsSon();
  },
  couper() {
    if (this.ctx && this.maitre) {
      const t = this.ctx.currentTime;
      this.maitre.gain.cancelScheduledValues(t);
      this.maitre.gain.setTargetAtTime(0, t, .25);
    }
  },
  basculer() {
    this.actif = !this.actif;
    ecrire(CLE_SON, this.actif ? "on" : "off");
    this.actif ? this.demarrer() : this.couper();
    majBoutonsSon();
  },
  /* effets : Big Bang, passage d'un trou de ver */
  effet(type) {
    if (!this.actif || !this.ctx || !this.pret) return;
    const c = this.ctx, t = c.currentTime, out = c.createGain();
    out.connect(this.maitre);
    if (type === "bigbang") {
      const o = c.createOscillator(); o.type = "sine";
      o.frequency.setValueAtTime(72, t); o.frequency.exponentialRampToValueAtTime(26, t + 1.6);
      const g = c.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(3.2, t + .04); g.gain.exponentialRampToValueAtTime(.001, t + 1.8);
      o.connect(g); g.connect(out); o.start(t); o.stop(t + 2);
    }
    const s = c.createBufferSource(); s.buffer = this.bruit;
    const f = c.createBiquadFilter(); f.type = "bandpass"; f.Q.value = 1.2;
    const g = c.createGain();
    if (type === "trou") {
      f.frequency.setValueAtTime(220, t); f.frequency.exponentialRampToValueAtTime(2600, t + .75); f.frequency.exponentialRampToValueAtTime(140, t + 1.55);
      g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(2.6, t + .7); g.gain.linearRampToValueAtTime(1.6, t + .85); g.gain.exponentialRampToValueAtTime(.001, t + 1.7);
    } else {
      f.frequency.setValueAtTime(1600, t); f.frequency.exponentialRampToValueAtTime(160, t + 1.4);
      g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(2.2, t + .03); g.gain.exponentialRampToValueAtTime(.001, t + 1.5);
    }
    s.connect(f); f.connect(g); g.connect(out); s.start(t); s.stop(t + 1.9);
  }
};
const ICONE_SON = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9.5h3.2L12 5.5v13l-4.8-4H4z" fill="currentColor"/><path class="ondes" d="M15.5 9a4 4 0 0 1 0 6M17.8 6.6a7.3 7.3 0 0 1 0 10.8" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path class="barre" d="M15.5 9.5l5 5m0-5l-5 5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>`;
function majBoutonsSon() {
  document.querySelectorAll(".a-son").forEach(b => {
    b.classList.toggle("muet", !son.actif);
    b.setAttribute("aria-pressed", String(!son.actif));
    b.setAttribute("aria-label", son.actif ? "Couper le son" : "Activer le son");
    b.title = son.actif ? "Couper le son" : "Activer le son";
  });
}
window.GALAPSY_SON = { trou: () => son.effet("trou"), bigbang: () => son.effet("bigbang") };

/* ============================================================
   À PROPOS — gratuité, crédit, lecture des couleurs
   ============================================================ */
const STRATES = [["#7fd4a8", "fait établi", "Ce qui est documenté et ne fait pas débat : une date, une publication, un résultat confirmé."],
  ["#9fb4f0", "interprétation", "La lecture qu'en propose un auteur ou une école de pensée."],
  ["#e8956e", "controverse", "Ce qui fait débat : qui conteste, et sur quel point."]];
const NATURES = {
  primaire: "Le texte d'origine : traité, article fondateur, manuel, classification officielle.",
  synthese: "Un ouvrage ou un article de référence qui fait le point sur un sujet.",
  revue: "Une analyse qui rassemble de nombreuses études : le niveau de preuve le plus élevé.",
  donnees: "Une recherche fondée sur des données : essai clinique, cohorte, enquête.",
  essai: "Une réflexion argumentée : philosophie, histoire, sociologie, psychanalyse.",
  temoignage: "Le savoir des personnes concernées, lorsqu'il est publié : récit, association, recherche participative.",
  droit: "Loi, décret, décision de justice, recommandation officielle."
};
function legendeHTML() {
  return `<h4>les trois strates d'une planète</h4><div class="c-legende">${STRATES.map(([c, l, t]) =>
      `<div style="--c:${c}"><span class="c-pastille"></span><span><b>${l}</b>${esc(t)}</span></div>`).join("")}</div>
    <h4>la couleur des satellites : le degré de certitude de chaque source</h4><div class="c-legende">${Object.keys(NATURES).map(k =>
      `<div style="--c:${K[k].c}"><span class="c-pastille"></span><span><b>${esc(K[k].l)}</b>${esc(NATURES[k])}</span></div>`).join("")}</div>
    <h4>et aussi</h4><div class="c-legende">
      <div style="--c:#63d6e2"><span class="c-pastille"></span><span><b>trou de ver</b>Relie une notion à la même notion, vue par une autre galaxie.</span></div>
      <div style="--c:#ff7089"><span class="c-pastille"></span><span><b>étoile instable</b>Une catégorie qui s'est effondrée et a donné naissance à d'autres.</span></div></div>`;
}
function ouvrirAPropos() {
  const c = ouvrirFeuille("À propos", `
    <div class="a-marque"><h2 class="wordmark">galapsy<span class="prime">′</span></h2><p>atlas cosmique des savoirs psy</p></div>
    <p>${TXT("apropos.intro")}</p>
    <h4>${esc(TXTBRUT("apropos.gratuite_titre"))}</h4>
    <p>${TXT("apropos.gratuite")}</p>
    <ul class="a-raisons"><li>${TXT("apropos.raison1")}</li><li>${TXT("apropos.raison2")}</li><li>${TXT("apropos.raison3")}</li></ul>
    ${legendeHTML()}
    <p class="c-aide">${TXT("apropos.aide")}</p>
    <div class="c-boutons"><button class="c-go" type="button" id="aRevoir">Revoir la visite guidée</button></div>
    <p class="a-credit">une création d'<b>impulsion46</b></p>`, "galapsy");
  c.querySelector("#aRevoir").onclick = () => { fermerFeuille(); visite.lancer(true); };
}

/* ============================================================
   VISITE GUIDÉE D'OUVERTURE
   ============================================================ */
/* la visite guidée vit dans recit.js (même récit que la vidéo de présentation) */
const visite = { get en_cours() { return !!(window.GALAPSY_RECIT && GALAPSY_RECIT.en_cours); },
  lancer: r => window.GALAPSY_RECIT && GALAPSY_RECIT.lancer(r), terminer: () => window.GALAPSY_RECIT && GALAPSY_RECIT.terminer() };

/* ============================================================
   ZOOM : écarter deux doigts (ou la molette) pour agrandir,
   glisser pour se déplacer ; un toucher bref ouvre l'astre.
   ============================================================ */
const ICONE_RECENTRER = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="12" cy="12" r="2.2" fill="currentColor"/></svg>`;
function majRecentrer() {
  const b = document.getElementById("btnRecentrer");
  if (b) b.hidden = VZ.z <= 1.01;
}
function recentrer() { VZ.z = 1; VZ.x = 0; VZ.y = 0; majRecentrer(); }
function deplacer(x, y) { VZ.x = x; VZ.y = y; borner(); }
function borner() {
  if (VZ.z <= 1.001) { recentrer(); return; }
  const mx = (VZ.z - 1) * W / 2 + 60, my = (VZ.z - 1) * H / 2 + 60;
  VZ.x = Math.max(-mx, Math.min(mx, VZ.x)); VZ.y = Math.max(-my, Math.min(my, VZ.y));
  majRecentrer();
}
function zoomer(z, cx, cy) {
  z = Math.max(1, Math.min(5, z));
  const wx = (cx - W / 2 - VZ.x) / VZ.z, wy = (cy - H / 2 - VZ.y) / VZ.z;
  VZ.z = z; VZ.x = cx - W / 2 - wx * z; VZ.y = cy - H / 2 - wy * z;
  borner();
}
function brancherZoom() {
  const cv = document.getElementById("sky");
  cv.style.touchAction = "none";
  const pts = new Map();
  let dep = null, pince = null, bouge = false;
  cv.addEventListener("pointerdown", e => {
    try { cv.setPointerCapture(e.pointerId); } catch (_) { }
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pts.size === 1) { dep = { x: e.clientX, y: e.clientY, t: performance.now(), vx: VZ.x, vy: VZ.y }; bouge = false; }
    else if (pts.size === 2) {
      const [a, b] = [...pts.values()], cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2;
      pince = { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, z: VZ.z, wx: (cx - W / 2 - VZ.x) / VZ.z, wy: (cy - H / 2 - VZ.y) / VZ.z };
      bouge = true;
    }
  });
  cv.addEventListener("pointermove", e => {
    if (!pts.has(e.pointerId)) return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pince && pts.size >= 2) {
      const [a, b] = [...pts.values()];
      const z = Math.max(1, Math.min(5, pince.z * Math.hypot(a.x - b.x, a.y - b.y) / pince.d));
      VZ.z = z; VZ.x = (a.x + b.x) / 2 - W / 2 - pince.wx * z; VZ.y = (a.y + b.y) / 2 - H / 2 - pince.wy * z;
      borner();
    } else if (dep && pts.size === 1) {
      const dx = e.clientX - dep.x, dy = e.clientY - dep.y;
      if (Math.hypot(dx, dy) > 9) bouge = true;
      if (bouge && VZ.z > 1) { VZ.x = dep.vx + dx; VZ.y = dep.vy + dy; borner(); }
    }
  });
  const fin = e => {
    const n = pts.size;
    pts.delete(e.pointerId);
    if (e.type === "pointerup" && n === 1 && !bouge && dep && performance.now() - dep.t < 600) surTap(e);
    if (pts.size < 2) pince = null;
    if (pts.size === 0) dep = null;
    else if (pts.size === 1) { const r = [...pts.values()][0]; dep = { x: r.x, y: r.y, t: 0, vx: VZ.x, vy: VZ.y }; }
  };
  cv.addEventListener("pointerup", fin);
  cv.addEventListener("pointercancel", fin);
  cv.addEventListener("wheel", e => { e.preventDefault(); zoomer(VZ.z * Math.exp(-e.deltaY * 0.0016), e.clientX, e.clientY); }, { passive: false });
  cv.addEventListener("dblclick", e => zoomer(VZ.z > 1.5 ? 1 : 2.2, e.clientX, e.clientY));
  // on change de vue : le zoom repart de zéro
  let cle = "";
  const veille = () => {
    const k = state.level + "|" + state.gal + "|" + state.sys;
    if (k !== cle) {
      cle = k;
      const R = window.GALAPSY_RECIT;     // pendant la présentation, c'est elle qui tient la caméra
      if (R && R.en_cours && R.cadrerNiveau) R.cadrerNiveau(); else recentrer();
    }
    conseilZoom();
    requestAnimationFrame(veille);
  };
  requestAnimationFrame(veille);
}
/* une seule fois, sur écran tactile : comment zoomer */
let conseilDonne = lire("galapsy.conseil.zoom") === "vu";
function conseilZoom() {
  if (conseilDonne || state.level !== "cosmos" || document.getElementById("gate") || !disp.hidden || state.emerge || bigbang.active) return;
  if (visite.en_cours || document.body.classList.contains("en-audio")) return;
  if (!matchMedia("(pointer: coarse)").matches) { conseilDonne = true; return; }
  conseilDonne = true; ecrire("galapsy.conseil.zoom", "vu");
  const t = document.createElement("div");
  t.className = "a-toast"; t.setAttribute("role", "status");
  t.textContent = "Écartez deux doigts pour agrandir le cosmos, glissez pour vous déplacer.";
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 5200);
}

/* ============================================================
   EN-TÊTE : marque, recherche, son
   ============================================================ */
const ICONE_CASQUE = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 14v-2a7.5 7.5 0 0 1 15 0v2" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="3.5" y="13.5" width="4" height="6.5" rx="1.4" fill="currentColor"/><rect x="16.5" y="13.5" width="4" height="6.5" rx="1.4" fill="currentColor"/></svg>`;
const ICONE_LOUPE = `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="5.8" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M15 15l5 5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>`;
function brancherEntete() {
  const tr = document.querySelector(".topright");
  const rang = document.createElement("span");
  rang.className = "ico-rang";
  rang.innerHTML = `<button class="btn btn-ico" type="button" id="btnCherche" aria-label="Chercher une notion" title="Chercher">${ICONE_LOUPE}</button>
    <button class="btn btn-ico a-son" type="button" id="btnSon">${ICONE_SON}</button>
    <button class="btn btn-ico" type="button" id="btnAudio" aria-label="Mode audio, pour les personnes non-voyantes" title="Mode audio">${ICONE_CASQUE}</button>
    <button class="btn btn-ico" type="button" id="btnRecentrer" aria-label="Recentrer la vue" title="Recentrer" hidden>${ICONE_RECENTRER}</button>
    ${window.LANGUE === "en"
      ? `<button class="btn btn-ico a-langue" type="button" id="btnLangue" lang="fr" aria-label="Lire Galapsy en français" title="Français">FR</button>`
      : `<button class="btn btn-ico a-langue" type="button" id="btnLangue" lang="en" aria-label="Read Galapsy in English" title="English">EN</button>`}`;
  tr.insertBefore(rang, tr.firstChild);
  rang.querySelector("#btnCherche").onclick = () => ouvrirRecherche();
  rang.querySelector("#btnSon").onclick = () => son.basculer();
  rang.querySelector("#btnRecentrer").onclick = recentrer;
  const marque = document.getElementById("brand");
  if (marque) {
    marque.onclick = ouvrirAPropos;
    marque.onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); ouvrirAPropos(); } };
  }
  const pq = document.getElementById("aproposLien");
  if (pq) pq.onclick = ouvrirAPropos;
  document.getElementById("ignite").addEventListener("click", () => { son.demarrer(); setTimeout(() => son.effet("bigbang"), 60); });
  // la supernova a son propre souffle
  document.addEventListener("click", e => { if (e.target.closest && e.target.closest("#novaBtn")) son.effet("bigbang"); }, true);
  // le son démarre au premier geste de l'utilisateur (règle des navigateurs)
  const premier = () => {
    if (son.actif && !son.pret) son.demarrer();
    ["pointerup", "click", "keydown"].forEach(t => removeEventListener(t, premier, true));
  };
  ["pointerup", "click", "keydown"].forEach(t => addEventListener(t, premier, true));
  document.addEventListener("visibilitychange", () => {
    if (!son.ctx) return;
    if (document.visibilityState === "hidden") son.ctx.suspend(); else if (son.actif) son.ctx.resume();
  });
  addEventListener("keydown", e => {
    if (e.key === "/" && !/input|textarea/i.test(document.activeElement.tagName)) { e.preventDefault(); ouvrirRecherche(); }
  });
  majBoutonsSon();
}

/* ============================================================
   DÉMARRAGE
   ============================================================ */
appliquerTextes();
brancherLunes();
brancherEntete();
brancherZoom();
majNombres();


window.GALAPSY_ATLAS = { ICONE_SON, deplacer, CREATIONS, fermerFeuille, ouvrirFeuille, T, appliquerTextes, DEFAUTS, zoomer, recentrer, chercher, suggerer, aller, ouvrirRecherche, ouvrirAPropos, legendeHTML, majNombres, norm, visite, son };
})();
