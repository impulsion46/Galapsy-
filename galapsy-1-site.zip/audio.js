/* ============================================================
   GALAPSY' — mode audio (personnes aveugles ou malvoyantes)
   Mode à activer : il n'est jamais proposé par défaut.
   Tout est lu à voix haute par une voix de synthèse neuronale
   enregistrée à l'avance (dossier voix/). Une contribution plus
   récente que l'enregistrement est lue par la voix du téléphone.
   On se déplace avec de grands boutons, le clavier ou la voix.
   ============================================================ */
(function () {
"use strict";

const CLE = "galapsy.audio", CLE_VOIX = "galapsy.audio.voix", CLE_VITESSE = "galapsy.audio.vitesse";
const lire = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
const ecrire = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { } };
const A = () => window.GALAPSY_ATLAS;
const norm = s => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[’']/g, " ").replace(/\s+/g, " ").trim();
const NBF = ["zéro", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf", "vingt"];
const nombre = (n, f) => (n === 1 ? (f ? "une" : "un") : (NBF[n] || String(n)));
const FEM = /^(galaxie|étoile|planète|source|zone)/;
const pluriel = (n, mot) => `${nombre(n, FEM.test(mot))} ${mot}${n > 1 ? "s" : ""}`;
const Maj = s => s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
const B = k => (window.TXTBRUT ? TXTBRUT(k) : "");

let actif = false, el = null, pile = [], voixActive = lire(CLE_VOIX) !== "off", vitesse = +(lire(CLE_VITESSE) || 1);
let gestes = 0, sonAvant = null, dernier = [];

/* ============================================================
   PRONONCIATION : ce que la voix doit dire (le texte affiché ne change pas)
   ============================================================ */
const ORD = { 1: "premier", 2: "deuxième", 3: "troisième", 4: "quatrième", 5: "cinquième", 6: "sixième", 7: "septième", 8: "huitième", 9: "neuvième", 10: "dixième",
  11: "onzième", 12: "douzième", 13: "treizième", 14: "quatorzième", 15: "quinzième", 16: "seizième", 17: "dix-septième", 18: "dix-huitième", 19: "dix-neuvième", 20: "vingtième", 21: "vingt et unième" };
const ROM = { I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6, VII: 7, VIII: 8, IX: 9, X: 10, XI: 11, XII: 12, XIII: 13, XIV: 14, XV: 15, XVI: 16, XVII: 17, XVIII: 18, XIX: 19, XX: 20, XXI: 21 };
const MOTS_MAJ = new Set(["UNESCO", "INSERM", "SIDA", "ONU", "OCDE"]);
function pourVoix(t, langue) {
  t = String(t || "");
  if (langue !== "fr") return t.replace(/\s+/g, " ").trim();
  t = t.replace(/ᵉ/g, "e").replace(/[⤳]/g, "")
    .replace(/(\d{3,4})\s*[–-]\s*(\d{3,4})/g, "$1 à $2")
    .replace(/(\d{4})\s*→\s*aujourd'hui/g, "de $1 à aujourd'hui").replace(/(\d{4})\s*→\s*(?=[.,;]|$)/g, "depuis $1")
    .replace(/\s*→\s*/g, ", puis ").replace(/([A-Za-zÀ-ÿ])–([A-Za-zÀ-ÿ])/g, "$1-$2").replace(/\bd'IL-6\b/g, "de l'IL-6").replace(/\s*[·›]\s*/g, ", ").replace(/\s—\s/g, ", ").replace(/—/g, ", ")
    .replace(/≈\s*/g, "environ ").replace(/\s&\s/g, " et ").replace(/(\d)\s?%/g, "$1 pour cent")
    .replace(/\bet al\./g, "et collaborateurs").replace(/\béd\./g, "édition").replace(/\bn°\s?/g, "numéro ")
    .replace(/\b(DSM|CIM)[-\s]?(I{1,3}|IV|V)\b/g, (m, a, r) => a + " " + ROM[r])
    .replace(/\b([IVX]{1,5})e\b/g, (m, r) => ROM[r] ? ORD[ROM[r]] : m)
    .replace(/\b1(er|re)\b/g, "premier").replace(/\b(\d{1,2})(e|ème)\b/g, (m, n) => ORD[+n] || m)
    .replace(/(ième|premier) s\./g, "$1 siècle")
    .replace(/\bHiTOP\b/g, "Hi top").replace(/\bRDoC\b/g, "R doc")
    .replace(/\b([A-Z]{2,6})(?=\b)/g, m => MOTS_MAJ.has(m) ? m.toLowerCase() : m.split("").join(" "))
    .replace(/\b([A-Z])-(\d+)\b/g, "$1 $2").replace(/([A-Z])-(\d)/g, "$1 $2");
  return t.replace(/\s+/g, " ").replace(/\s+([,.])/g, "$1").trim();
}
/* titres d'ouvrages en anglais ou en allemand : lus dans leur langue */
function langueTitre(t) {
  const s = " " + String(t).toLowerCase() + " ";
  if (/[äöüß]/.test(s) || / (der|die|das|und|eines|einer|oder|für|über|zur|ein) /.test(s) || /lehrbuch|gruppe|nervenkrank/.test(s)) return "de";
  const en = (s.match(/ (the|of|and|in|a|an|for|to|with|on|from|its|their) /g) || []).length;
  if (en >= 1 && !/[éèêàçùûôîœ]/.test(s) && !/ (de|du|des|la|le|les|et|une|un|sur|dans) /.test(s)) return "en";
  return "fr";
}

/* ============================================================
   VOIX : clips enregistrés (voix A), sinon voix du téléphone
   ============================================================ */
function cle(seg) {   // empreinte FNV-1a du texte et de sa langue
  const s = seg.l + "|" + seg.t;
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(36) + s.length.toString(36);
}
const S = (t, l) => ({ t: String(t || "").trim().replace(/([^.])\.\.$/, "$1."), l: l || "fr" });
const segs = (...xs) => xs.flat().filter(x => x && (typeof x === "string" ? x.trim() : x.t)).map(x => typeof x === "string" ? S(x) : x);

let index = null, chargement = null;
function chargerIndex() {
  if (index) return Promise.resolve(index);
  if (!chargement) chargement = fetch("voix/index.json").then(r => r.ok ? r.json() : []).catch(() => [])
    .then(l => (index = new Set(l)));
  return chargement;
}
const lecteur = new Audio();
lecteur.preload = "auto";
try { lecteur.preservesPitch = true; } catch (e) { }
const synth = window.speechSynthesis || null;
let voixTel = {};
function choisirVoixTel() {
  if (!synth) return;
  const toutes = synth.getVoices();
  const note = v => (/natural|neural|online|premium|enhanced|amélioré/i.test(v.name) ? 5 : 0) + (/google/i.test(v.name) ? 3 : 0)
    + (/amélie|thomas|audrey|aurélie|marie|denise|henri|julie|paul/i.test(v.name) ? 2 : 0) + (v.localService ? .5 : 0);
  ["fr", "en", "de"].forEach(l => {
    const vs = toutes.filter(v => v.lang && v.lang.toLowerCase().startsWith(l));
    vs.sort((a, b) => note(b) - note(a) || (/fr-fr|en-gb|de-de/i.test(b.lang) ? 1 : 0) - (/fr-fr|en-gb|de-de/i.test(a.lang) ? 1 : 0));
    voixTel[l] = vs[0] || null;
  });
}
if (synth) { choisirVoixTel(); try { synth.addEventListener("voiceschanged", choisirVoixTel); } catch (e) { synth.onvoiceschanged = choisirVoixTel; } }

let tour = 0, enCours = null, reprise = null;
function taire() {
  tour++;
  enCours = null;
  try { lecteur.pause(); } catch (e) { }
  if (synth) synth.cancel();
}
/* un toucher : pause, ou reprise là où l'on s'était arrêté */
function basculerLecture() {
  if (enCours) { reprise = enCours.liste.slice(enCours.i); taire(); bip(false); return; }
  const r = reprise && reprise.length ? reprise : (dernier.length ? dernier : (courant() || {}).resume || []);
  reprise = null;
  dire(r);
}
function jouerClip(k, t) {
  return new Promise(res => {
    let fini = false;
    const fin = ok => { if (fini) return; fini = true; lecteur.onended = lecteur.onerror = null; res(ok); };
    lecteur.onended = () => fin(true);
    lecteur.onerror = () => fin(false);
    lecteur.src = "voix/" + k + ".m4a";
    lecteur.playbackRate = vitesse;
    const p = lecteur.play();
    if (p && p.catch) p.catch(() => fin(false));
    setTimeout(() => fin(true), 60000);
    if (t !== tour) fin(false);
  });
}
function parlerTel(seg) {
  return new Promise(res => {
    if (!synth) return res(false);
    const u = new SpeechSynthesisUtterance(pourVoix(seg.t, seg.l));
    u.lang = seg.l === "en" ? "en-GB" : seg.l === "de" ? "de-DE" : "fr-FR";
    const v = voixTel[seg.l] || voixTel.fr; if (v) u.voice = v;
    u.rate = vitesse; u.onend = () => res(true); u.onerror = () => res(false);
    synth.speak(u);
  });
}
async function dire(liste, suite) {
  liste = segs(liste);
  dernier = liste;
  if (window.__espionAudio) window.__espionAudio(liste.map(x => x.t));
  const live = el && el.querySelector("#maLive");
  const texte = liste.map(s => s.t).join(" ");
  if (!voixActive) {
    if (live) { live.textContent = ""; setTimeout(() => { live.textContent = texte; }, 60); }
    if (suite) setTimeout(suite, 400);
    return;
  }
  taire();
  reprise = null;
  const t = tour;
  enCours = { liste, i: 0 };
  const idx = await chargerIndex();
  for (let i = 0; i < liste.length; i++) {
    if (t !== tour) return;
    enCours = { liste, i };
    const k = cle(liste[i]);
    if (idx.has(k)) {
      if (i + 1 < liste.length) { const k2 = cle(liste[i + 1]); if (idx.has(k2)) fetch("voix/" + k2 + ".m4a").catch(() => { }); }
      const ok = await jouerClip(k, t);
      if (!ok && t === tour) await parlerTel(liste[i]);
    } else await parlerTel(liste[i]);
    if (t === tour && i + 1 < liste.length) await new Promise(r => setTimeout(r, 140));
  }
  if (t === tour) enCours = null;
  if (t === tour && suite) suite();
}

/* petit signal sonore : « je vous écoute » */
let ctxBip = null;
function bip(haut) {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    ctxBip = ctxBip || new AC();
    const t = ctxBip.currentTime, o = ctxBip.createOscillator(), g = ctxBip.createGain();
    o.frequency.value = haut ? 880 : 520; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(.12, t + .02); g.gain.exponentialRampToValueAtTime(.001, t + .18);
    o.connect(g); g.connect(ctxBip.destination); o.start(t); o.stop(t + .2);
  } catch (e) { }
}

/* ============================================================
   CE QUE L'ON ENTEND, élément par élément
   ============================================================ */
const PH = {
  accueil: [
    "Bienvenue dans Galapsy, en mode audio.",
    "Galapsy est un atlas des savoirs sur la souffrance psychique. Tout se fait avec un doigt, n'importe où sur l'écran.",
    "Glissez vers la droite pour passer à l'élément suivant, vers la gauche pour revenir au précédent.",
    "Touchez deux fois pour ouvrir. Glissez vers le bas pour remonter.",
    "Touchez une fois pour mettre en pause, ou pour reprendre.",
    "Pour chercher une notion à la voix, gardez le doigt appuyé, puis parlez après le signal.",
    "Ces commandes existent aussi en boutons, en bas de l'écran. Glissez vers le haut pour réentendre ces explications.",
    "Pour commencer, touchez deux fois : la présentation de Galapsy démarre."
  ],
  aide: [
    "Les gestes, n'importe où sur l'écran.",
    "Glisser vers la droite : élément suivant. Vers la gauche : élément précédent.",
    "Toucher deux fois : ouvrir. Glisser vers le bas : remonter.",
    "Toucher une fois : pause, ou reprise.",
    "Glisser vers le haut : réentendre cette aide.",
    "Appui long : chercher à la voix. Dites par exemple : mélancolie, ou : sources de la schizophrénie. Vous pouvez aussi dire : suivant, ouvrir, revenir, répéter, présentation, plus lentement.",
    "La recherche à la voix demande une connexion internet. Sans elle, utilisez le champ de recherche et la dictée de votre clavier.",
    "Enfin, le bouton « Quitter le mode audio », tout en bas de l'écran, ramène à l'atlas visuel."
  ],
  suite: "Glissez à droite pour continuer, touchez deux fois pour ouvrir.",
  debut: "Début de la liste.",
  fin: "Fin de la liste.",
  finRemonter: "Fin de la liste. Glissez vers le bas pour remonter.",
  retour: "Retour.",
  accueilIci: "Vous êtes à l'accueil.",
  rien: "Je n'ai rien trouvé. Essayez un autre mot.",
  resultats: "Résultats de la recherche.",
  unResultat: "Un seul résultat.",
  resultatsSuite: "Touchez deux fois pour écouter, glissez à droite pour le résultat suivant.",
  aucuneSource: "Cette planète n'a pas encore de source.",
  dabordPlanete: "Choisissez d'abord une planète : ses sources sont listées sur sa fiche.",
  ouvrirSource: "J'ouvre la source dans votre navigateur.",
  sourceIndice: "Touchez deux fois pour consulter la source en ligne.",
  sourcesIndice: "Touchez deux fois pour les écouter une par une.",
  trousIndice: "Touchez deux fois pour les écouter.",
  trouIndice: "Touchez deux fois pour franchir le trou de ver.",
  ficheIndice: "Touchez deux fois pour écouter les sources.",
  trouFranchi: "Trou de ver franchi. Le même objet, vu par une autre approche.",
  nulle: "Ce trou de ver ne mène nulle part pour l'instant.",
  instableResume: "Étoile instable. Touchez deux fois pour déclencher la supernova.",
  supernova: "Supernova.",
  zoneVide: "Aucune notion n'y a encore été ajoutée.",
  presentation: "Présentation de Galapsy.",
  presentationResume: "Présentation de Galapsy. Touchez deux fois pour l'écouter.",
  question: "Tout part d'une question : d'où vient la souffrance psychique ?",
  regles: "Les règles de la communauté.",
  presentationFin: "Glissez à droite pour découvrir la première galaxie.",
  commencer: "Galapsy, mode audio. Touchez l'écran pour commencer.",
  micRefuse: "L'accès au micro est refusé. Autorisez-le dans les réglages de votre téléphone, ou utilisez le champ de recherche.",
  silence: "Je n'ai rien entendu. Gardez le doigt appuyé, puis parlez après le signal.",
  reseau: "La recherche à la voix demande une connexion internet.",
  incompris: "Je n'ai pas compris. Gardez le doigt appuyé et réessayez.",
  pause: "Pause.",
  ecoute: "Je vous écoute.",
  pasDeMicro: "La reconnaissance vocale n'est pas disponible sur cet appareil. Utilisez le champ de recherche : la dictée de votre clavier fonctionne aussi.",
  micImpossible: "La reconnaissance vocale n'a pas pu démarrer. Utilisez le champ de recherche.",
  dites: "Dites ou tapez le nom d'une notion.",
  voixOn: "La voix de Galapsy est activée.",
  vitesses: ["Vitesse lente.", "Vitesse normale.", "Vitesse rapide.", "Vitesse très rapide."]
};
const egal = (n, mot) => `${Maj(pluriel(n, mot))}.`;
const comptes = {
  etoiles: n => `Elle compte ${pluriel(n, "étoile")}.`,
  planetes: n => `${Maj(pluriel(n, "planète"))} en orbite.`,
  sources: n => egal(n, "source"),
  trous: n => `${Maj(pluriel(n, "trou"))} de ver vers d'autres galaxies.`,
  resultats: n => `${Maj(pluriel(n, "résultat"))}.`,
  nees: n => `${Maj(pluriel(n, "étoile"))} en ${n > 1 ? "sont nées" : "est née"} :`
};

function phrasesPresentation() {
  return [PH.presentation, PH.question, B("recit.dispersion"), B("recit.galaxies"), B("recit.etoiles"), B("recit.planetes"),
    B("recit.fiche"), B("recit.satellites"), B("recit.instable"), B("recit.trou"), B("recit.frontiere"), B("recit.recherche"),
    B("recit.creation"), PH.regles, B("recit.regle1"), B("recit.regle2"), B("recit.regle3"), B("recit.regle4"), B("recit.regles_pied"),
    B("recit.gratuite"), B("recit.expansion"), PH.presentationFin];
}
const galaxieResume = g => `Galaxie ${g.n} : ${g.s}.`;
const galaxieLecture = g => [`Galaxie ${g.n}.`, g.d, `Son hypothèse centrale : ${g.th}`, comptes.etoiles(g.sy.length)];
const etoileResume = s => `Étoile ${s.n}${s.s ? ", " + s.s : ""}.`;
const etoileLecture = s => [`Étoile ${s.n}.`, s.r, comptes.planetes(s.pl.length)];
const planeteResume = p => `Planète ${p.n}.`;
const lieu = (g, s) => `Galaxie ${g.n}, étoile ${s.n}.`;
const PARTIES = { r: "Résumé.", f: "Fait établi.", i: "Interprétation.", c: "Controverse." };
const partie = (p, k) => p[k] ? `${PARTIES[k]} ${p[k]}` : "";
const ficheLecture = (g, s, p) => [`Planète ${p.n}.`, lieu(g, s), partie(p, "r"), partie(p, "f"), partie(p, "i"), partie(p, "c"),
  comptes.sources((p.so || []).length), (p.wh || []).length ? comptes.trous(p.wh.length) : "", PH.ficheIndice];
const sourceLecture = m => { const k = K[m.k] || K.essai; return [S(m.t, langueTitre(m.t)), `${m.a}.`, `Nature : ${k.l}.`]; };
const trouLecture = w => { const tg = byId(w.g); return `Vers la galaxie ${tg ? tg.n : w.g} : ${w.l}.`; };
const novaLecture = s => [PH.supernova, s.nova.w, comptes.nees(s.nova.gen.length), s.nova.gen.map(x => x.n).join(", ") + "."];
const zoneResume = f => `Zone non cartographiée : ${f.n}.`;

/* Tout ce que le mode audio peut dire, pour l'enregistrement des voix */
function tousLesSegments() {
  const L = [];
  const ajoute = (...x) => segs(...x).forEach(s => L.push(s));
  Object.values(PH).forEach(v => ajoute(v));
  ajoute(phrasesPresentation());
  for (let n = 1; n <= 40; n++) ajoute(comptes.etoiles(n), comptes.planetes(n), comptes.sources(n), comptes.trous(n), comptes.resultats(n), comptes.nees(n));
  GAL.forEach(g => {
    ajoute(galaxieResume(g), galaxieLecture(g));
    const tous = []; g.sy.forEach(s => { tous.push(s); if (s.nova) s.nova.gen.forEach(x => tous.push(x)); });
    tous.forEach(s => {
      ajoute(etoileResume(s), etoileLecture(s));
      if (s.nova) ajoute(novaLecture(s));
      s.pl.forEach(p => {
        ajoute(planeteResume(p), ficheLecture(g, s, p));
        (p.so || []).forEach(m => ajoute(sourceLecture(m)));
        (p.wh || []).forEach(w => ajoute(trouLecture(w)));
      });
    });
  });
  FRONT.forEach(f => ajoute(zoneResume(f), f.d));
  const vus = new Set(), out = [];
  L.forEach(s => { const k = cle(s); if (!vus.has(k)) { vus.add(k); out.push({ cle: k, texte: s.t, voix: s.l, prononcer: pourVoix(s.t, s.l) }); } });
  return out;
}

/* ============================================================
   NIVEAUX DE NAVIGATION
   ============================================================ */
function tousSys(g) {
  const out = [];
  g.sy.forEach(s => { if (!out.includes(s)) out.push(s); if (s.nova) s.nova.gen.forEach(x => { if (!out.includes(x)) out.push(x); }); });
  return out;
}
function niveauAccueil() {
  return { nom: "Accueil", items: [{ type: "presentation", titre: "Présentation de Galapsy", sur: "à écouter d'abord",
      texte: "Une minute pour comprendre comment l'atlas est construit.", resume: [PH.presentationResume] }]
    .concat(GAL.map((g, i) => ({ type: "galaxie", g, titre: g.n, sur: `galaxie ${i + 1} sur ${GAL.length}`, texte: g.s, resume: [galaxieResume(g)] })))
    .concat(FRONT.map(f => ({ type: "zone", f, titre: f.n, sur: "zone non cartographiée", texte: f.d, resume: [zoneResume(f)] }))) };
}
const premiereGalaxie = () => pile[0].items.findIndex(x => x.type === "galaxie");
function niveauEtoiles(g) {
  return { nom: g.n, items: g.sy.map((s, i) => ({ type: "etoile", g, s, titre: s.n, sur: `étoile ${i + 1} sur ${g.sy.length}`,
    texte: [s.s, s.r].filter(Boolean).join(" — "), resume: [etoileResume(s)] })) };
}
function niveauPlanetes(g, s) {
  const items = s.pl.map((p, i) => ({ type: "planete", g, s, p, titre: p.n, sur: `planète ${i + 1} sur ${s.pl.length}`, texte: p.r, resume: [planeteResume(p)] }));
  if (s.nova && !s._done) items.push({ type: "nova", g, s, titre: "Étoile instable", sur: "supernova", texte: s.nova.q, resume: [PH.instableResume] });
  return { nom: s.n, items };
}
function niveauFiche(g, s, p) {
  const so = p.so || [], wh = p.wh || [];
  const items = ["r", "f", "i", "c"].filter(k => p[k]).map(k => ({ type: "partie", g, s, p, cle: k, titre: PARTIES[k].replace(".", ""), sur: p.n, texte: p[k], resume: [partie(p, k)] }));
  items.push({ type: "sources", g, s, p, titre: `Sources (${so.length})`, sur: p.n, texte: so.map(m => m.t).join(" · "), resume: [comptes.sources(so.length), PH.sourcesIndice] });
  if (wh.length) items.push({ type: "trous", g, s, p, titre: `Trous de ver (${wh.length})`, sur: p.n, texte: wh.map(w => w.l).join(" · "), resume: [comptes.trous(wh.length), PH.trousIndice] });
  return { nom: p.n, items };
}
function lienSource(m) {
  const r = String(m.ref || "").trim();
  if (/^https?:\/\/\S+$/i.test(r)) return r;
  const doi = r.match(/(10\.\d{4,9}\/\S+)/); if (doi) return "https://doi.org/" + doi[1];
  return "https://scholar.google.com/scholar?q=" + encodeURIComponent(`"${m.t}" ${m.a || ""}`);
}
function niveauSources(g, s, p) {
  const so = p.so || [];
  return { nom: "Sources de " + p.n, items: so.map((m, i) => ({ type: "source", m, p, g, s, titre: m.t, sur: `source ${i + 1} sur ${so.length} · ${(K[m.k] || K.essai).l}`,
    texte: m.a, resume: sourceLecture(m).concat([PH.sourceIndice]) })) };
}
function niveauTrous(g, s, p) {
  const wh = p.wh || [];
  return { nom: "Trous de ver de " + p.n, items: wh.map((w, i) => ({ type: "trou", w, g, s, p, titre: w.l, sur: `trou de ver ${i + 1} sur ${wh.length}`,
    texte: (byId(w.g) || {}).n ? "vers la galaxie " + byId(w.g).n : "", resume: [trouLecture(w), PH.trouIndice] })) };
}

/* ============================================================
   NAVIGATION
   ============================================================ */
const courant = () => { const n = pile[pile.length - 1]; return n && n.items[n.i || 0]; };
const astuce = () => gestes < 4 ? [PH.suite] : [];
function aller(d) {
  const n = pile[pile.length - 1]; if (!n) return;
  gestes++;
  const i = (n.i || 0) + d;
  if (i < 0) { afficher(); return dire([PH.debut, ...courant().resume]); }
  if (i >= n.items.length) { afficher(); return dire([pile.length > 1 ? PH.finRemonter : PH.fin]); }
  n.i = i; afficher(); dire([...courant().resume, ...astuce()]);
}
function revenir() {
  gestes++;
  if (pile.length <= 1) { afficher(); return dire([PH.accueilIci, ...courant().resume]); }
  pile.pop(); afficher(); dire([PH.retour, ...courant().resume]);
}
function pousser(niveau, i) { niveau.i = i || 0; pile.push(niveau); afficher(); }
function noter(g, s, p) {
  if (!state.journal.some(j => j.pid === p.id && j.sid === s.id)) state.journal.push({ gid: g.id, sid: s.id, pid: p.id, n: p.n, g: g.n, hue: g.hue });
}
function ouvrir(it) {
  it = it || courant(); if (!it) return;
  gestes++;
  if (it.type === "presentation") dire(phrasesPresentation());
  else if (it.type === "galaxie") {
    const niv = niveauEtoiles(it.g); pousser(niv);
    dire([...galaxieLecture(it.g), ...(niv.items[0] ? niv.items[0].resume : []), ...astuce()]);
  } else if (it.type === "zone") dire([zoneResume(it.f), it.f.d, PH.zoneVide]);
  else if (it.type === "etoile") {
    const niv = niveauPlanetes(it.g, it.s); pousser(niv);
    dire([...etoileLecture(it.s), ...(niv.items[0] ? niv.items[0].resume : []), ...astuce()]);
  } else if (it.type === "nova") {
    const { g, s } = it;
    if (!s._done) { s._done = true; s.nova.gen.forEach(x => { x._born = true; g.sy.push(x); }); }
    if (A()) A().son.effet("bigbang");
    pile.pop();
    const etoiles = niveauEtoiles(g); etoiles.i = Math.max(0, g.sy.indexOf(s.nova.gen[0]));
    pile[pile.length - 1] = etoiles; afficher();
    dire([...novaLecture(s), ...courant().resume]);
  } else if (it.type === "planete") lireFiche(it.g, it.s, it.p);
  else if (it.type === "partie") dire(it.resume);
  else if (it.type === "sources") {
    if (!(it.p.so || []).length) return dire([PH.aucuneSource]);
    pousser(niveauSources(it.g, it.s, it.p)); dire(courant().resume);
  } else if (it.type === "trous") { pousser(niveauTrous(it.g, it.s, it.p)); dire(courant().resume); }
  else if (it.type === "source") {
    dire([PH.ouvrirSource]);
    try { window.open(lienSource(it.m), "_blank", "noopener"); } catch (e) { }
  } else if (it.type === "trou") franchir(it.w);
}
function lireFiche(g, s, p, avant) {
  noter(g, s, p);
  pile = [niveauAccueil(), niveauEtoiles(g), niveauPlanetes(g, s), niveauFiche(g, s, p)];
  pile[0].i = Math.max(0, pile[0].items.findIndex(x => x.g === g));
  pile[1].i = Math.max(0, pile[1].items.findIndex(x => x.s === s));
  pile[2].i = Math.max(0, s.pl.indexOf(p));
  pile[3].i = pile[3].items.findIndex(x => x.type === "sources");
  afficher();
  dire([...(avant || []), ...ficheLecture(g, s, p)]);
}
function franchir(w) {
  const g = byId(w.g); if (!g) return;
  const s = tousSys(g).find(x => x.id === w.s), p = s && s.pl.find(x => x.id === w.p);
  if (!s || !p) return dire([PH.nulle]);
  if (A()) A().son.effet("trou");
  lireFiche(g, s, p, [PH.trouFranchi]);
}
function partieFiche(k) {
  const n = pile[pile.length - 1];
  const j = n && n.items.findIndex(x => x.cle === k);
  if (j == null || j < 0) return dire([PH.dabordPlanete]);
  n.i = j; afficher(); dire(courant().resume);
}
function allerA(type) {
  for (let k = pile.length - 1; k >= 0; k--) {
    const it = pile[k].items.find(x => x.type === type);
    if (it) { pile.length = k + 1; pile[k].i = pile[k].items.indexOf(it); return ouvrir(it); }
  }
  const it = courant();
  if (it && it.type === "planete") { lireFiche(it.g, it.s, it.p); return allerA(type); }
  dire([PH.dabordPlanete]);
}

/* ---------- recherche, au clavier ou à la voix ---------- */
function versItem(r) {
  if (r.type === "galaxie") return { type: "galaxie", g: r.g, titre: r.g.n, sur: "galaxie", texte: r.g.s, resume: [galaxieResume(r.g)] };
  if (r.type === "systeme") return { type: "etoile", g: r.g, s: r.s, titre: r.s.n, sur: `étoile · ${r.g.n}`, texte: r.s.r, resume: [etoileResume(r.s)] };
  if (r.type === "planete") return { type: "planete", g: r.g, s: r.s, p: r.p, titre: r.p.n, sur: `planète · ${r.g.n}`, texte: r.p.r, resume: [planeteResume(r.p), lieu(r.g, r.s)] };
  if (r.type === "lune") return { type: "source", m: r.m, p: r.p, titre: r.m.t, sur: `source · ${r.p.n}`, texte: r.m.a, resume: sourceLecture(r.m).concat([planeteResume(r.p), PH.sourceIndice]) };
  return { type: "zone", f: r.f, titre: r.f.n, sur: "zone non cartographiée", texte: r.f.d, resume: [zoneResume(r.f)] };
}
function chercher(q, sourcesVoulues) {
  q = String(q || "").trim();
  if (!q) return dire([PH.dites]);
  const res = A() ? A().chercher(q) : [];
  if (!res.length) return dire([PH.rien]);
  const exact = res.find(r => ["planete", "galaxie", "systeme"].includes(r.type) && norm(r.nom) === norm(q));
  if (sourcesVoulues) {
    const pl = res.find(r => r.type === "planete");
    if (pl) {
      taire();
      pile = [niveauAccueil(), niveauEtoiles(pl.g), niveauPlanetes(pl.g, pl.s), niveauFiche(pl.g, pl.s, pl.p)];
      pousser(niveauSources(pl.g, pl.s, pl.p));
      return dire([`Sources de la planète ${pl.p.n}.`, comptes.sources((pl.p.so || []).length), ...courant().resume]);
    }
  }
  if (exact && exact.type === "planete") return lireFiche(exact.g, exact.s, exact.p);
  if (exact) { pile = [niveauAccueil()]; return ouvrir(versItem(exact)); }
  const items = res.slice(0, 20).map(versItem);
  pile = [niveauAccueil()];
  pousser({ nom: `Résultats pour « ${q} »`, items });
  dire([PH.resultats, items.length === 1 ? PH.unResultat : comptes.resultats(items.length), ...items[0].resume, PH.resultatsSuite]);
}

/* ---------- commandes vocales ---------- */
/* une phrase courte qui contient un mot de commande est une commande : « suivant s'il te plaît » */
const MOTS_COMMANDES = [
  [/\b(aide|aidez moi|commandes?)\b/, () => dire(PH.aide)],
  [/\b(suivante?|apres|continue[rz]?|la suite)\b/, () => aller(1)],
  [/\b(precedente?|avant)\b/, () => aller(-1)],
  [/\b(ouvr(e|ir)|entre[rz]?|ecoute[rz]?|lis|lire)\b/, () => ouvrir()],
  [/\b(reviens|revenir|retour|remonte[rz]?|sortir)\b/, () => revenir()],
  [/\b(repete[rz]?|repeter|encore|relis|relire)\b/, () => dire(dernier.length ? dernier : courant().resume)],
  [/\b(pause|stop|arrete|silence|chut)\b/, () => taire()]
];
const POLITESSE = /\b(s il (te|vous) plait|stp|svp|merci|galapsy|ok|d accord|alors|euh)\b/g;
function commande(brut, alternatives) {
  const t = norm(brut).replace(/[.!?,]/g, "").replace(POLITESSE, " ").replace(/\s+/g, " ").trim() || norm(brut);
  // parmi les transcriptions proposées, on préfère celle qui est une commande connue
  if (alternatives && alternatives.length > 1) {
    for (const a of alternatives) {
      const n = norm(a).replace(/[.!?,]/g, "");
      if (n.split(" ").length <= 4 && MOTS_COMMANDES.some(([re]) => re.test(n)) && !MOTS_COMMANDES.some(([re]) => re.test(t))) return commande(a);
    }
  }
  afficherEntendu(brut);
  const m = re => t.match(re);
  let r;
  if (m(/^(aide|aidez moi|que puis je dire|commandes?)$/)) return dire(PH.aide);
  if (m(/^(suivant|suivante|apres|continue|continuer|la suite)$/)) return aller(1);
  if (m(/^(precedent|precedente|avant|retour en arriere)$/)) return aller(-1);
  if (m(/^(ouvrir|ouvre|entrer|entre|oui|vas y|ecouter|lire|lis)$/)) return ouvrir();
  if (m(/^(revenir|retour|remonter|reviens|sortir|remonte)$/)) return revenir();
  if (m(/^(repeter|repete|encore|relire|relis)$/)) return dire(dernier.length ? dernier : courant().resume);
  if (m(/^(pause|stop|arrete|arrete toi|silence|tais toi|chut)$/)) return taire();
  if (m(/^(accueil|galaxies|les galaxies|debut|menu)$/)) { pile = [niveauAccueil()]; pile[0].i = premiereGalaxie(); afficher(); return dire([...courant().resume, PH.suite]); }
  if (m(/^(presentation|la presentation|ecouter la presentation)$/)) { pile = [niveauAccueil()]; afficher(); return ouvrir(); }
  if (m(/^(sources?|les sources|satellites?|les satellites|references?)$/)) return allerA("sources");
  if (m(/^(trous? de vers?|les trous de vers?|passages?)$/)) return allerA("trous");
  if (m(/^fait etabli$/)) return partieFiche("f");
  if (m(/^interpretation$/)) return partieFiche("i");
  if (m(/^(controverse|debat)$/)) return partieFiche("c");
  if (m(/^resume$/)) return partieFiche("r");
  if (m(/^(plus lentement|moins vite|lentement|ralentis)$/)) return reglerVitesse(-1);
  if (m(/^(plus vite|plus rapide|rapidement|accelere)$/)) return reglerVitesse(1);
  if (m(/^(quitter|quitte|quitter le mode audio|mode visuel|fermer)$/)) return quitter();
  if ((r = m(/^(?:les )?(?:sources?|satellites?) (?:de la |de l |du |des |de |sur la |sur le |sur l |sur )(.+)$/))) return chercher(r[1], true);
  if ((r = m(/^(?:cherche|chercher|trouve|trouver|recherche|rechercher|va a|aller a|ouvre|ouvrir|parle moi de|parle moi du|parle moi des|c est quoi|qu est ce que|qu est ce qu|qui est)\s+(?:la |le |les |l |une |un |des |du )?(.+)$/))) return chercher(r[1]);
  if ((r = m(/^(?:galaxie|planete|notion|etoile)\s+(.+)$/))) return chercher(r[1]);
  if (t.split(" ").length <= 4) { const c = MOTS_COMMANDES.find(([re]) => re.test(t)); if (c) return c[1](); }
  return chercher(brut);
}
let reco = null;
function ecouter() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { dire([PH.pasDeMicro]); const c = el.querySelector("#maQ"); if (c) c.focus(); return; }
  if (reco) { try { reco.abort(); } catch (e) { } reco = null; }
  taire();
  try {
    reco = new SR();
    reco.lang = "fr-FR"; reco.interimResults = false; reco.maxAlternatives = 3; reco.continuous = false;
    const b = el.querySelector("#maParler");
    reco.onstart = () => { b.classList.add("ecoute"); el.classList.add("ma-ecoute"); b.setAttribute("aria-pressed", "true"); bip(true); };
    reco.onend = () => { b.classList.remove("ecoute"); el.classList.remove("ma-ecoute"); b.setAttribute("aria-pressed", "false"); reco = null; };
    reco.onresult = e => { bip(false); const r = e.results[0]; commande(r[0].transcript, [...r].map(x => x.transcript)); };
    reco.onerror = e => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") dire([PH.micRefuse]);
      else if (e.error === "no-speech") dire([PH.silence]);
      else if (e.error === "network") dire([PH.reseau]);
      else if (e.error !== "aborted") dire([PH.incompris]);
    };
    setTimeout(() => { try { reco && reco.start(); } catch (e) { } }, 120);
  } catch (e) { dire([PH.micImpossible]); }
}

/* ============================================================
   INTERFACE
   ============================================================ */
const PAS = [0.8, 1, 1.25, 1.5];
function reglerVitesse(d) {
  let i = PAS.indexOf(vitesse); if (i < 0) i = 1;
  i = Math.max(0, Math.min(PAS.length - 1, i + d));
  vitesse = PAS[i]; ecrire(CLE_VITESSE, String(vitesse));
  majReglages(); dire([PH.vitesses[i]]);
}
function majReglages() {
  if (!el) return;
  const v = el.querySelector("#maVoix"), s = el.querySelector("#maVitesse");
  v.textContent = voixActive ? "Voix de Galapsy : activée" : "Voix de Galapsy : coupée";
  v.setAttribute("aria-pressed", String(voixActive));
  s.textContent = "Vitesse : " + ({ 0.8: "lente", 1: "normale", 1.25: "rapide", 1.5: "très rapide" }[vitesse] || "normale");
}
function afficherEntendu(t) {
  const e = el && el.querySelector("#maEntendu");
  if (e) { e.textContent = "Vous avez dit : « " + t + " »"; e.hidden = false; }
}
function afficher() {
  if (!el) return;
  const it = courant(), n = pile[pile.length - 1];
  el.querySelector("#maLieu").textContent = pile.map(x => x.nom).join(" › ");
  el.querySelector("#maSur").textContent = it ? it.sur : "";
  el.querySelector("#maTitre").textContent = it ? it.titre : "";
  el.querySelector("#maTexte").textContent = it ? (it.texte || "") : "";
  el.querySelector("#maPos").textContent = n ? `${(n.i || 0) + 1} / ${n.items.length}` : "";
}
function construire() {
  el = document.createElement("div");
  el.id = "modeAudio"; el.className = "ma"; el.hidden = true;
  el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", "Galapsy, mode audio");
  el.innerHTML = `
    <header class="ma-tete"><p class="ma-marque">galapsy<span>′</span> · mode audio</p><p class="ma-lieu" id="maLieu"></p></header>
    <section class="ma-carte" id="maZone" aria-label="Élément en cours. Glissez à droite ou à gauche pour changer d'élément, touchez deux fois pour ouvrir.">
      <p class="ma-sur"><span id="maSur"></span> <span id="maPos" class="ma-pos"></span></p>
      <h2 id="maTitre" tabindex="-1"></h2>
      <p id="maTexte" class="ma-texte"></p>
      <p id="maEntendu" class="ma-entendu" hidden></p>
      <p class="ma-gestes" aria-hidden="true"><span>← précédent</span><span>2 touchers : ouvrir</span><span>suivant →</span>
        <span>↓ remonter</span><span>1 toucher : pause</span><span>appui long : parler</span></p>
    </section>
    <div class="ma-live" id="maLive" aria-live="polite" aria-atomic="true"></div>
    <nav class="ma-commandes" aria-label="Commandes">
      <button type="button" data-c="prec" class="ma-grand">◀<br>Précédent</button>
      <button type="button" data-c="ouv" class="ma-grand ma-prim">Ouvrir</button>
      <button type="button" data-c="suiv" class="ma-grand">▶<br>Suivant</button>
      <button type="button" data-c="rev">Revenir</button>
      <button type="button" data-c="rep">Répéter</button>
      <button type="button" data-c="pause" id="maLecture">Pause · reprise</button>
      <button type="button" data-c="aide">Aide</button>
      <button type="button" class="ma-parler" id="maParler" aria-pressed="false"><span aria-hidden="true">●</span> Parler</button>
    </nav>
    <form class="ma-cherche" id="maForm" role="search">
      <label for="maQ">Chercher une notion ou une source</label>
      <div><input id="maQ" type="search" autocomplete="off" placeholder="par ex. mélancolie"><button type="submit">Chercher</button></div>
    </form>
    <div class="ma-reglages">
      <button type="button" id="maVoix" aria-pressed="true"></button>
      <button type="button" id="maVitesse"></button>
      <button type="button" id="maQuitter">Quitter le mode audio</button>
    </div>
    <div class="ma-depart" id="maDepart" hidden>
      <button type="button" id="maCommencer">Commencer l'écoute</button>
      <p>Galapsy, mode audio. Touchez n'importe où pour commencer.</p>
    </div>`;
  document.body.appendChild(el);
  el.querySelector("#maParler").onclick = ecouter;
  el.querySelectorAll("[data-c]").forEach(b => b.onclick = () => {
    const c = b.dataset.c;
    if (c === "prec") aller(-1); else if (c === "suiv") aller(1); else if (c === "rev") revenir();
    else if (c === "ouv") ouvrir(); else if (c === "rep") dire(dernier.length ? dernier : (courant() || {}).resume || []);
    else if (c === "pause") basculerLecture(); else if (c === "src") allerA("sources"); else if (c === "aide") dire(PH.aide);
  });
  brancherGestes(el.querySelector("#maZone"));
  el.querySelector("#maForm").onsubmit = e => { e.preventDefault(); const q = el.querySelector("#maQ").value; el.querySelector("#maQ").blur(); chercher(q); };
  el.querySelector("#maVoix").onclick = () => {
    voixActive = !voixActive; ecrire(CLE_VOIX, voixActive ? "on" : "off"); majReglages();
    if (!voixActive) { taire(); const live = el.querySelector("#maLive"); live.textContent = "La voix de Galapsy est coupée : votre lecteur d'écran prend le relais."; }
    else dire([PH.voixOn]);
  };
  el.querySelector("#maVitesse").onclick = () => { const i = PAS.indexOf(vitesse); vitesse = PAS[(i + 1) % PAS.length]; ecrire(CLE_VITESSE, String(vitesse)); majReglages(); dire([PH.vitesses[PAS.indexOf(vitesse)]]); };
  el.querySelector("#maQuitter").onclick = quitter;
  el.querySelector("#maDepart").addEventListener("click", () => { el.querySelector("#maDepart").hidden = true; accueillir(); });
  el.addEventListener("keydown", e => {
    if (/input|textarea/i.test(e.target.tagName)) return;
    const k = e.key;
    if (k === "ArrowRight" || k === "ArrowDown") { e.preventDefault(); aller(1); }
    else if (k === "ArrowLeft" || k === "ArrowUp") { e.preventDefault(); aller(-1); }
    else if (k === "Enter" && e.target === el.querySelector("#maTitre")) { e.preventDefault(); ouvrir(); }
    else if (k === "Escape" || k === "Backspace") { e.preventDefault(); e.stopPropagation(); revenir(); }
    else if (k === " " && e.target.tagName !== "BUTTON") { e.preventDefault(); taire(); }
  });
  majReglages();
}
/* les gestes, sur la grande surface : comme un lecteur de livres audio */
function brancherGestes(z) {
  let d = null, dernierToucher = 0, minuterieSimple = null, minuterieLongue = null, long = false;
  const vibrer = ms => { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) { } };
  z.addEventListener("pointerdown", e => {
    if (e.button > 0) return;
    d = { x: e.clientX, y: e.clientY, t: performance.now() }; long = false;
    clearTimeout(minuterieLongue);
    minuterieLongue = setTimeout(() => { if (d) { long = true; vibrer(40); ecouter(); } }, 650);
    try { z.setPointerCapture(e.pointerId); } catch (_) { }
  });
  z.addEventListener("pointermove", e => {
    if (d && Math.hypot(e.clientX - d.x, e.clientY - d.y) > 14) clearTimeout(minuterieLongue);
  });
  const fin = e => {
    clearTimeout(minuterieLongue);
    if (!d) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y, duree = performance.now() - d.t;
    d = null;
    if (long) return;
    if (Math.abs(dx) > 48 && Math.abs(dx) > Math.abs(dy) * 1.2) { clearTimeout(minuterieSimple); vibrer(12); aller(dx > 0 ? 1 : -1); return; }
    if (Math.abs(dy) > 48 && Math.abs(dy) > Math.abs(dx) * 1.2) { clearTimeout(minuterieSimple); vibrer(12); if (dy > 0) revenir(); else dire(PH.aide); return; }
    if (Math.hypot(dx, dy) > 14 || duree > 600) return;
    const maintenant = performance.now();
    if (maintenant - dernierToucher < 320) {          // deux touchers : ouvrir
      clearTimeout(minuterieSimple); dernierToucher = 0; vibrer(20); ouvrir(); return;
    }
    dernierToucher = maintenant;
    minuterieSimple = setTimeout(() => { dernierToucher = 0; basculerLecture(); }, 330);
  };
  z.addEventListener("pointerup", fin);
  z.addEventListener("pointercancel", () => { clearTimeout(minuterieLongue); d = null; });
  z.addEventListener("contextmenu", e => e.preventDefault());
}
function deverrouiller() {
  // iOS : le lecteur audio doit être lancé une première fois pendant un geste
  try { lecteur.src = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA="; const p = lecteur.play(); if (p && p.catch) p.catch(() => { }); } catch (e) { }
}
function accueillir() {
  deverrouiller();
  pile = [niveauAccueil()];
  afficher();
  el.querySelector("#maTitre").focus({ preventScroll: true });
  dire(PH.accueil);
}
function entrer(depuisDemarrage) {
  if (!el) construire();
  actif = true; ecrire(CLE, "on");
  chargerIndex();
  const v = A() && A().visite; if (v && v.en_cours) v.terminer();
  const porte = document.getElementById("gate"); if (porte) porte.remove();
  const e = document.getElementById("entreeAudio"); if (e) e.hidden = true;
  if (A() && A().son.actif) { sonAvant = true; A().son.couper(); }
  document.body.classList.add("en-audio");
  el.hidden = false;
  if (depuisDemarrage) {
    el.querySelector("#maDepart").hidden = false;
    el.querySelector("#maCommencer").focus({ preventScroll: true });
  } else accueillir();
}
function quitter() {
  taire();
  if (reco) { try { reco.abort(); } catch (e) { } }
  actif = false; ecrire(CLE, "off");
  document.body.classList.remove("en-audio");
  if (el) el.hidden = true;
  if (sonAvant && A()) A().son.demarrer();
  const it = courant();
  if (it && A()) {
    if (it.p && it.g && it.s) A().aller({ type: "planete", g: it.g, s: it.s, p: it.p });
    else if (it.type === "etoile") A().aller({ type: "systeme", g: it.g, s: it.s });
    else if (it.type === "galaxie") A().aller({ type: "galaxie", g: it.g });
  }
  pile = [];
}
function brancherEntree() {
  const b = document.getElementById("entreeAudio");
  if (b) {
    b.onclick = () => entrer(false);
    if (document.getElementById("gate")) { b.hidden = false; setTimeout(() => { try { b.focus({ preventScroll: true }); } catch (e) { } }, 80); }
    document.getElementById("ignite").addEventListener("click", () => { b.hidden = true; });
  }
  const h = document.getElementById("btnAudio");
  if (h) h.onclick = () => entrer(false);
  if (lire(CLE) === "on") entrer(true);
}
brancherEntree();
window.GALAPSY_AUDIO = { entrer, quitter, actif: () => actif, commande, chercher, tousLesSegments, pourVoix, cle, langueTitre,
  etat: () => ({ parle: !!enCours, reprise: !!(reprise && reprise.length), titre: (courant() || {}).titre }) };
})();
