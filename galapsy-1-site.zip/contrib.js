/* ============================================================
   GALAPSY' — plateforme contributive
   Comptes (code reçu par e-mail), charte, contributions sourcées,
   historique, signalements, modération.

   Se charge AVANT le moteur de l'atlas : il remplace le corpus
   embarqué par la dernière copie de la base partagée, puis se
   branche sur les fiches une fois l'atlas prêt.
   Sans configuration (config.js vide), il ne fait rien : l'atlas
   fonctionne exactement comme avant.
   ============================================================ */
(function () {
"use strict";

const CFG = window.GALAPSY_CONFIG || {};
const ACTIF = !!(CFG.supabaseUrl && CFG.supabaseKey);
const API = String(CFG.supabaseUrl || "").replace(/\/+$/, "");
const CLE_CACHE = "galapsy.corpus.v1";
const CLE_SESSION = "galapsy.session.v1";
const CHARTE_VERSION = 1;

const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g,
  c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const lire = k => { try { return JSON.parse(localStorage.getItem(k) || "null"); } catch (e) { return null; } };
const ecrire = (k, v) => { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };

/* ============================================================
   CORPUS : lignes de la base -> structure de l'atlas
   ============================================================ */
function assembler(objets) {
  const parId = new Map(), enfants = new Map();
  objets.forEach(o => {
    parId.set(o.id, o);
    if (o.parent) { if (!enfants.has(o.parent)) enfants.set(o.parent, []); enfants.get(o.parent).push(o); }
  });
  const tri = (a, b) => (a.ordre - b.ordre) || (a.id < b.id ? -1 : 1);
  const de = (id, type) => (enfants.get(id) || []).filter(o => o.type === type).sort(tri);
  const galaxieDe = id => { let o = parId.get(id); while (o && o.type !== "galaxie") o = parId.get(o.parent); return o; };
  const planete = p => ({
    id: p.id, n: p.d.n, r: p.d.r || "", f: p.d.f || "", i: p.d.i || "", c: p.d.c || "", _par: p.par || null,
    so: de(p.id, "lune").map(m => ({ id: m.id, t: m.d.t, a: m.d.a, k: m.d.k, ref: m.d.ref || "", _par: m.par || null })),
    wh: de(p.id, "trou").map(t => {
      const c = parId.get(t.d.cible), s = c && parId.get(c.parent), g = c && galaxieDe(c.id);
      return c && s && g ? { id: t.id, g: g.id, s: s.id, p: c.id, l: t.d.l, _par: t.par || null } : null;
    }).filter(Boolean)
  });
  const systeme = s => ({ id: s.id, n: s.d.n, s: s.d.s || "", r: s.d.r || "", _par: s.par || null, pl: de(s.id, "planete").map(planete) });
  const gal = objets.filter(o => o.type === "galaxie").sort(tri).map(g => {
    const tous = de(g.id, "systeme");
    const sy = tous.filter(s => !s.d.ne_de).map(s => {
      const S = systeme(s);
      if (s.d.nova) S.nova = { q: s.d.nova.q, w: s.d.nova.w, gen: tous.filter(x => x.d.ne_de === s.id).map(systeme) };
      return S;
    });
    return { id: g.id, n: g.d.n, s: g.d.s || "", hue: +g.d.hue || 0, r: g.d.r || "", d: g.d.d || "", th: g.d.th || "", sy };
  });
  const front = objets.filter(o => o.type === "zone").sort(tri).map(z => ({ id: z.id, n: z.d.n, d: z.d.d || "" }));
  return { gal, front };
}

let corpusDistant = false;   // l'atlas affiché vient-il de la base (identifiants complets) ?
let textesObjets = [];        // textes du site, tels qu'en base (pour les administrateurs)
function lireTextes(objets) {
  textesObjets = objets.filter(o => o.type === "texte").sort((a, b) => a.ordre - b.ordre);
  window.GALAPSY_TEXTES = Object.fromEntries(textesObjets.map(o => [o.d.cle, o.d.v]));
}
let empreinte = null;

/* Appelé par le moteur juste avant ses précalculs */
window.GALAPSY_DEMARRAGE = function (GAL, FRONT) {
  if (!ACTIF) return;
  const c = lire(CLE_CACHE);
  if (!c || !Array.isArray(c.objets)) return;
  try {
    const a = assembler(c.objets);
    if (a.gal.length < 12) return;          // copie incomplète : on garde le corpus embarqué
    GAL.length = 0; a.gal.forEach(g => GAL.push(g));
    if (a.front.length) { FRONT.length = 0; a.front.forEach(f => FRONT.push(f)); }
    corpusDistant = true; empreinte = c.empreinte || null;
    lireTextes(c.objets);
  } catch (e) { console.warn("Galapsy : copie locale illisible", e); }
};

if (!ACTIF) return;

/* ============================================================
   API : fonctions de la base et comptes
   ============================================================ */
function traduire(m) {
  m = String(m || "");
  if (/failed to fetch|networkerror|load failed/i.test(m)) return "Connexion impossible. Vérifiez votre accès à internet.";
  if (/rate limit|too many|security purposes|seconds/i.test(m)) return "Trop de demandes rapprochées : patientez une minute avant de redemander un code.";
  if (/token has expired|otp.*(expired|invalid)|invalid.*(otp|token)|expired/i.test(m)) return "Code invalide ou expiré. Vérifiez-le ou redemandez-en un.";
  if (/signups not allowed/i.test(m)) return "Les inscriptions sont fermées pour le moment.";
  if (/not authori[sz]ed/i.test(m)) return "Les inscriptions ne sont pas encore ouvertes au public : l'envoi des codes par e-mail est en cours de configuration.";
  if (/email.*invalid|invalid.*email|unable to validate email/i.test(m)) return "Adresse e-mail invalide.";
  if (/permission denied/i.test(m)) return "Connectez-vous pour contribuer.";
  if (/jwt/i.test(m)) return "Votre session a expiré : reconnectez-vous.";
  return m;
}

async function requete(chemin, corps, jetonAcces) {
  if (!navigator.onLine) throw new Error("Pas de connexion internet : la contribution demande d'être en ligne.");
  const h = { "Content-Type": "application/json", apikey: CFG.supabaseKey };
  if (jetonAcces) h.Authorization = "Bearer " + jetonAcces;
  let r;
  try { r = await fetch(API + chemin, { method: "POST", headers: h, body: JSON.stringify(corps || {}) }); }
  catch (e) { throw new Error(traduire(e.message)); }
  const t = await r.text();
  let j = null; try { j = t ? JSON.parse(t) : null; } catch (e) { }
  if (!r.ok) {
    const err = new Error(traduire(j && (j.message || j.msg || j.error_description || j.error) || ("Erreur " + r.status)));
    err.statut = r.status;
    throw err;
  }
  return j;
}

let session = lire(CLE_SESSION);
let renouvellement = null;
const normaliser = s => ({
  access_token: s.access_token, refresh_token: s.refresh_token,
  expires_at: s.expires_at || Math.floor(Date.now() / 1000) + (s.expires_in || 3600),
  user: s.user ? { id: s.user.id, email: s.user.email } : (session && session.user) || null
});
function oublierSession() { session = null; compte = null; ecrire(CLE_SESSION, null); majFab(); }

async function jeton() {
  if (!session) return null;
  if (Date.now() / 1000 < session.expires_at - 60) return session.access_token;
  if (!renouvellement) {
    renouvellement = requete("/auth/v1/token?grant_type=refresh_token", { refresh_token: session.refresh_token })
      .then(s => { session = normaliser(s); ecrire(CLE_SESSION, session); return session.access_token; })
      .catch(e => { if (e.statut) oublierSession(); return null; })
      .finally(() => { renouvellement = null; });
  }
  return renouvellement;
}

async function rpc(fn, args) {
  const t = await jeton();
  try { return await requete("/rest/v1/rpc/" + fn, args || {}, t); }
  catch (e) {
    if (e.statut === 401 && t) { oublierSession(); throw new Error("Votre session a expiré : reconnectez-vous."); }
    throw e;
  }
}

/* ============================================================
   ÉTAT DU COMPTE
   ============================================================ */
let compte = null;   // { email, charte_actuelle, profil:{pseudo, role…}, a_relire }
const role = () => compte && compte.profil ? compte.profil.role : null;
const estModo = () => ["moderateur", "admin"].includes(role());

async function chargerCompte() {
  if (!session) { compte = null; majFab(); return null; }
  try { compte = await rpc("galapsy_profil"); }
  catch (e) { if (!session) compte = null; }
  majFab();
  return compte;
}

/* ============================================================
   SYNCHRONISATION DE L'ATLAS
   ============================================================ */
let dernierChargement = 0;
let limites = { resume: 50, niveau: 45 };      // longueur des fiches, réglable par les administrateurs
async function synchroniser() {
  if (!navigator.onLine) return;
  dernierChargement = Date.now();
  let c;
  try { c = await rpc("galapsy_corpus"); } catch (e) { return; }
  if (!c || !Array.isArray(c.objets)) return;
  if (c.limites && c.limites.resume) limites = c.limites;
  const emp = c.objets.length + "·" + (c.maj || "") + "·" + JSON.stringify(c.objets).length;
  if (corpusDistant && emp === empreinte) return;
  const a = assembler(c.objets);
  if (a.gal.length < 12) return;
  ecrire(CLE_CACHE, { objets: c.objets, empreinte: emp, le: new Date().toISOString() });
  empreinte = emp;
  lireTextes(c.objets);
  fusionner(a);
  corpusDistant = true;
  if (window.GALAPSY_ATLAS) GALAPSY_ATLAS.appliquerTextes();
}

/* Fusion en place : la navigation en cours, les supernovas déclenchées
   et la constellation du lecteur sont préservées. */
function fusionner(a) {
  a.gal.forEach(g2 => {
    const g = GAL.find(x => x.id === g2.id);
    if (!g) return;
    Object.assign(g, { n: g2.n, s: g2.s, hue: g2.hue, r: g2.r, d: g2.d, th: g2.th });
    const anciens = new Map();
    g.sy.forEach(s => { anciens.set(s.id, s); if (s.nova) s.nova.gen.forEach(x => anciens.set(x.id, x)); });
    const maj = s2 => {
      const s = anciens.get(s2.id);
      if (!s) return s2;
      Object.assign(s, { n: s2.n, s: s2.s, r: s2.r, pl: s2.pl, _par: s2._par });
      if (s2.nova) { s.nova = s.nova || {}; s.nova.q = s2.nova.q; s.nova.w = s2.nova.w; s.nova.gen = s2.nova.gen.map(maj); }
      else delete s.nova;
      return s;
    };
    const sy = g2.sy.map(maj), nes = [];
    sy.forEach(s => { if (s._done && s.nova) s.nova.gen.forEach(x => { x._born = true; nes.push(x); }); });
    g.sy.length = 0;
    sy.concat(nes).forEach(s => g.sy.push(s));
  });
  a.gal.forEach(g2 => { if (!GAL.find(x => x.id === g2.id)) { prepGal(g2); GAL.push(g2); } });
  const zones = a.front.map(f2 => {
    const f = FRONT.find(x => x.id === f2.id);
    if (f) { f.n = f2.n; f.d = f2.d; return f; }
    prepFront(f2); return f2;
  });
  FRONT.length = 0; zones.forEach(f => FRONT.push(f));
  if (window.GALAPSY_LANGUE) GALAPSY_LANGUE.corpus(GAL, FRONT, K);   // version anglaise : on retraduit ce qui n'a pas changé
  if (window.GALAPSY_ATLAS) GALAPSY_ATLAS.majNombres();
  if (state.level !== "cosmos" && !byId(state.gal)) { state.level = "cosmos"; state.gal = null; state.sys = null; }
  if (state.level === "system" && !sysById(state.gal, state.sys)) { state.level = "galaxy"; state.sys = null; }
  rafraichirFiche();
  refreshHUD();
}

/* ============================================================
   REPÈRES DANS L'ATLAS
   ============================================================ */
function tousSystemes(g) {
  const out = [];
  g.sy.forEach(s => { if (!out.includes(s)) out.push(s); if (s.nova) s.nova.gen.forEach(x => { if (!out.includes(x)) out.push(x); }); });
  return out;
}
function trouver(id) {
  for (const g of GAL) {
    if (g.id === id) return { type: "galaxie", g, o: g };
    for (const s of tousSystemes(g)) {
      if (s.id === id) return { type: "systeme", g, s, o: s };
      for (const p of s.pl) {
        if (p.id === id) return { type: "planete", g, s, p, o: p };
        for (const m of p.so || []) if (m.id === id) return { type: "lune", g, s, p, o: m };
        for (const w of p.wh || []) if (w.id === id) return { type: "trou", g, s, p, o: w };
      }
    }
  }
  const f = FRONT.find(x => x.id === id);
  return f ? { type: "zone", o: f } : null;
}
function allerA(id) {
  const t = trouver(id);
  if (!t) { toast("Cet élément n'est pas (ou plus) publié dans l'atlas."); return; }
  fermerAtelier(); closePanel();
  document.getElementById("disp").hidden = true; document.getElementById("over").hidden = true;
  if (t.type === "zone") { if (state.level !== "cosmos") go("cosmos", null, null, W / 2, H / 2, -1); setTimeout(() => openFront(id), 500); return; }
  if (t.type === "galaxie") { go("galaxy", t.g.id, null, W / 2, H / 2, 1); return; }
  if (t.s._born === undefined && t.g.sy.indexOf(t.s) < 0) {
    // système né d'une supernova pas encore déclenchée : on le révèle
    const mere = t.g.sy.find(s => s.nova && s.nova.gen.includes(t.s));
    if (mere && !mere._done) { mere._done = true; mere.nova.gen.forEach(x => { x._born = true; t.g.sy.push(x); }); }
  }
  go("system", t.g.id, t.s.id, W / 2, H / 2, 1);
  if (t.type === "systeme") setTimeout(() => openStar(t.g.id, t.s.id), 520);
  else setTimeout(() => openPlanet(t.g.id, t.s.id, t.p.id), 520);
}

/* ============================================================
   INTERFACE : bouton, atelier, messages
   ============================================================ */
let fab, atelier, corps, titreAtelier, surtitre;

function construire() {
  document.body.classList.add("c-actif");
  fab = document.createElement("button");
  fab.className = "c-fab"; fab.id = "cFab"; fab.type = "button";
  fab.onclick = () => vueMenu();
  document.body.appendChild(fab);

  atelier = document.createElement("div");
  atelier.className = "over c-atelier"; atelier.id = "cAtelier"; atelier.hidden = true;
  atelier.setAttribute("role", "dialog"); atelier.setAttribute("aria-modal", "true");
  atelier.innerHTML = `<div class="over-head"><div><p class="c-eyebrow" id="cSurtitre"></p><h3 id="cTitre"></h3></div>
    <button class="btn" id="cFermer" type="button">Fermer</button></div><div class="c-corps" id="cCorps"></div>`;
  document.body.appendChild(atelier);
  corps = atelier.querySelector("#cCorps");
  titreAtelier = atelier.querySelector("#cTitre");
  surtitre = atelier.querySelector("#cSurtitre");
  atelier.querySelector("#cFermer").onclick = fermerAtelier;
  addEventListener("keydown", e => {
    if (e.key === "Escape" && !atelier.hidden) { e.stopImmediatePropagation(); fermerAtelier(); }
  }, true);
  majFab();
}

function majFab() {
  if (!fab) return;
  const p = compte && compte.profil;
  const n = compte && compte.a_relire;
  fab.innerHTML = `<span>${p ? "◉ " + esc(p.pseudo) : "Contribuer"}</span>${n ? `<b title="à relire">${n}</b>` : ""}`;
  fab.setAttribute("aria-label", p ? "Mon espace contributeur" : "Contribuer à l'atlas");
}

function ouvrir(titre, html, eyebrow) {
  titreAtelier.textContent = titre;
  surtitre.textContent = eyebrow || "atelier de l'atlas";
  corps.innerHTML = html;
  corps.scrollTop = 0;
  atelier.hidden = false;
  if (!corps._mots) { suivreMots(corps); corps._mots = true; }
  return corps;
}
function fermerAtelier() { if (atelier) atelier.hidden = true; }

let minuteurToast = null;
function toast(msg) {
  let t = document.querySelector(".c-toast");
  if (!t) { t = document.createElement("div"); t.className = "c-toast"; t.setAttribute("role", "status"); document.body.appendChild(t); }
  t.textContent = msg; t.hidden = false;
  clearTimeout(minuteurToast); minuteurToast = setTimeout(() => { t.hidden = true; }, 4200);
}

const attente = (titre) => ouvrir(titre, `<p class="c-vide">Chargement…</p>`);
const erreurHTML = m => `<div class="c-erreur" role="alert">${esc(m)}</div>`;
const dateFr = d => { try { return new Date(d).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }); } catch (e) { return ""; } };

/* ============================================================
   VOCABULAIRE
   ============================================================ */
const TYPES = { texte: "texte du site", galaxie: "galaxie", systeme: "étoile", planete: "planète", lune: "satellite", trou: "trou de ver", zone: "zone" };
const ACTIONS = { creation: "création", correction: "correction", restauration: "restauration", retrait: "retrait", republication: "remise en ligne" };
const LIBELLES = { n: "Nom", s: "Repère", r: "Résumé", f: "Fait établi", i: "Interprétation", c: "Controverse",
  d: "Définition", th: "Thèse", v: "Texte", t: "Titre", a: "Auteur·e·s et année", ref: "Référence", k: "Nature de la source", l: "Ce qui relie", cible: "Planète cible" };
const CHAMPS = { texte: ["v"], galaxie: ["n", "s", "r", "d", "th"], zone: ["n", "d"], systeme: ["n", "s", "r"],
  planete: ["n", "r", "f", "i", "c"], lune: ["t", "a", "ref", "k"], trou: ["l"] };
const NATURES = {
  primaire: "Le texte d'origine : traité, article fondateur, manuel, classification officielle.",
  synthese: "Un ouvrage ou un article de référence qui fait le point sur un sujet.",
  revue: "Une analyse qui rassemble de nombreuses études : le niveau de preuve le plus élevé.",
  donnees: "Une recherche fondée sur des données : essai clinique, cohorte, enquête.",
  essai: "Une réflexion argumentée : philosophie, histoire, sociologie, psychanalyse.",
  temoignage: "Le savoir des personnes concernées, lorsqu'il est publié : récit, association, recherche participative.",
  droit: "Loi, décret, décision de justice, recommandation officielle."
};
const STRATES = {
  f: "Ce qui est documenté et ne fait pas débat : une date, une publication, un résultat confirmé.",
  i: "La lecture qu'en propose un auteur ou une école de pensée. Indiquez qui interprète.",
  c: "Ce qui fait débat : qui conteste, et sur quel point. Si aucun débat n'est connu, indiquez ce qui reste incertain."
};

/* Une source « en lien » : adresse web, DOI ou ISBN — la même règle que la base */
function lienValide(v) {
  const r = String(v || "").trim();
  if (/^https?:\/\/[^\s/$.?#][^\s]*\.[^\s]{2,}/i.test(r) && !/\s/.test(r)) return r;
  const doi = r.match(/(10\.\d{4,9}\/\S+)/);
  if (doi) return "https://doi.org/" + doi[1];
  if (/isbn/i.test(r) || /^[0-9][0-9 -]{8,}[0-9Xx]$/.test(r)) {
    const i = r.replace(/[^0-9Xx]/g, "").toUpperCase();
    if (i.length === 10 || i.length === 13) return "ISBN " + i;
  }
  return null;
}
function lienRef(ref) {
  const l = lienValide(ref);
  if (!l) return esc(ref || "");
  const href = l.startsWith("ISBN ") ? "https://www.google.com/search?tbm=bks&q=isbn:" + l.slice(5) : l;
  const texte = l.startsWith("ISBN ") ? l : l.startsWith("https://doi.org/") ? "DOI " + l.slice(16) : "consulter la source";
  return `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">${esc(texte)} ↗</a>`;
}
const AIDE_LIEN = "Une adresse web (https://…), un DOI (10.…) ou un ISBN. Sans lien vérifiable, la proposition ne peut pas être envoyée.";
const champSource = (nom, libelle, valeur) => champ(nom, libelle, { max: 500, valeur, lien: true, placeholder: "https://…  ·  10.…  ·  ISBN …", aide: AIDE_LIEN });

/* ============================================================
   FORMULAIRES
   ============================================================ */
function champ(nom, libelle, o = {}) {
  const { min = 0, max = 200, valeur = "", aide = "", requis = true, lignes = 0, placeholder = "", classe = "", type = "text", mots = 0, lien = false } = o;
  const attrs = `name="${nom}" ${requis ? "required" : ""} maxlength="${max}" data-min="${min}" ${mots ? `data-mots="${mots}"` : ""} ${lien ? `data-lien="1" inputmode="url"` : ""} data-libelle="${esc(libelle)}" placeholder="${esc(placeholder)}"`;
  const saisie = lignes
    ? `<textarea ${attrs} rows="${lignes}">${esc(valeur)}</textarea>`
    : `<input type="${type}" ${attrs} value="${esc(valeur)}" autocomplete="off">`;
  const compte = mots ? `<i class="c-compte" data-pour="${nom}">${compterMots(valeur)} / ${mots} mots</i>` : (requis ? "" : "<i>facultatif</i>");
  return `<label class="c-champ ${classe}"><span>${esc(libelle)} ${compte}</span>${saisie}${aide ? `<small>${aide}</small>` : ""}</label>`;
}
const compterMots = t => String(t || "").trim().split(/\s+/).filter(Boolean).length;
function suivreMots(racine) {
  racine.addEventListener("input", e => {
    const el = e.target, max = +el.dataset.mots;
    if (!max) return;
    const c = racine.querySelector(`.c-compte[data-pour="${el.name}"]`);
    if (!c) return;
    const n = compterMots(el.value);
    c.textContent = `${n} / ${max} mots`;
    c.classList.toggle("trop", n > max);
  });
}
function choixNature(valeur) {
  return `<div class="c-champ"><span>Nature de la source</span><div class="c-statuts" role="radiogroup">` +
    Object.keys(NATURES).map(k => `<label class="c-statut" style="--c:${K[k].c}">
      <input type="radio" name="k" value="${k}" ${valeur === k ? "checked" : ""}><span class="c-pastille"></span>
      <span><b>${esc(K[k].l)}</b><small>${esc(NATURES[k])}</small></span></label>`).join("") +
    `</div><small>Dans l'atlas, la couleur du satellite indiquera au lecteur le degré de certitude de la source.</small></div>`;
}
function champsLune(prefixe, v = {}) {
  return champ(prefixe + "t", "Titre", { min: 3, max: 300, mots: 25, valeur: v.t, placeholder: "Traité médico-philosophique sur l'aliénation mentale" }) +
    champ(prefixe + "a", "Auteur·e·s et année", { min: 3, max: 200, mots: 12, valeur: v.a, placeholder: "Philippe Pinel, 1801" }) +
    champSource(prefixe + "ref", "Lien de la source", v.ref);
}

/* lit et contrôle un formulaire ; renvoie null et affiche l'erreur si besoin */
function lireForm(form) {
  const v = {};
  let pb = null;
  form.querySelectorAll("input[name],textarea[name],select[name]").forEach(e => {
    if (e.type === "radio") { if (e.checked) v[e.name] = e.value; return; }
    if (e.type === "checkbox") { v[e.name] = e.checked; return; }
    const val = e.value.replace(/\s+/g, " ").trim();
    v[e.name] = val;
    const min = +e.dataset.min || 0;
    if (!pb && e.required && !val) pb = `Le champ « ${e.dataset.libelle} » est obligatoire.`;
    else if (!pb && val && val.length < min) pb = `Le champ « ${e.dataset.libelle} » est trop court (${min} caractères minimum).`;
    else if (!pb && +e.dataset.mots && compterMots(val) > +e.dataset.mots) pb = `Le champ « ${e.dataset.libelle} » compte ${compterMots(val)} mots ; la limite est de ${e.dataset.mots} mots, pour garder des fiches courtes.`;
    else if (!pb && e.dataset.lien && val && !lienValide(val)) pb = `« ${e.dataset.libelle} » doit être un lien vérifiable : une adresse web (https://…), un DOI (10.…) ou un ISBN.`;
  });
  if (pb) { montrerErreur(form, pb); return null; }
  return v;
}
function montrerErreur(form, m) {
  let z = form.querySelector(".c-zone-erreur");
  if (!z) { z = document.createElement("div"); z.className = "c-zone-erreur"; form.querySelector(".c-boutons").before(z); }
  z.innerHTML = m ? erreurHTML(m) : "";
  if (m) z.scrollIntoView({ block: "nearest", behavior: "smooth" });
}
async function envoyer(form, action) {
  const b = form.querySelector(".c-go");
  const txt = b.textContent;
  b.disabled = true; b.textContent = "Envoi…";
  montrerErreur(form, "");
  try { await action(); }
  catch (e) { montrerErreur(form, e.message || String(e)); }
  finally { if (b.isConnected) { b.disabled = false; b.textContent = txt; } }
}

function merci(res) {
  const publie = res && res.statut === "publie";
  ouvrir("Merci", `<div class="c-ok"><b>${publie ? "publié" : "proposition envoyée"}</b>
    <p>${publie ? "Votre contribution est en ligne."
                : "Un administrateur va vérifier la source avant de publier votre proposition. D'ici là, vous pouvez la modifier ou la retirer depuis « Mes contributions »."}</p></div>
    <div class="c-boutons"><button class="c-go" type="button" id="cRetour">Revenir à l'atlas</button>
    <button class="c-lien" type="button" id="cMes">Mes contributions</button></div>`, "contribution");
  corps.querySelector("#cRetour").onclick = fermerAtelier;
  corps.querySelector("#cMes").onclick = vueMesContributions;
  chargerCompte();
  if (publie) synchroniser().then(rafraichirFiche);
}

/* ============================================================
   CONNEXION ET CHARTE
   ============================================================ */
function exigerCompte(suite) {
  if (!navigator.onLine) return ouvrir("Hors ligne", `<p class="c-note">La lecture fonctionne hors ligne, mais contribuer demande une connexion internet.</p>`);
  if (!corpusDistant) {
    ouvrir("Un instant", `<p class="c-note">L'atlas partagé se synchronise. Réessayez dans quelques secondes.</p>`);
    synchroniser();
    return;
  }
  if (!session) return vueConnexion(suite);
  attente("Un instant");
  chargerCompte().then(c => {
    if (!session || !c) return vueConnexion(suite);
    if (!c.profil || c.profil.charte_version < c.charte_actuelle) return vueCharte(suite);
    if (c.profil.suspendu) return ouvrir("Compte suspendu", `<p>Votre compte contributeur est suspendu. Vous pouvez toujours lire l'atlas.</p>`);
    suite();
  });
}

function vueConnexion(suite) {
  ouvrir("Se connecter", `
    <p>Pas de mot de passe : vous recevez un code à usage unique par e-mail. Votre adresse ne sera jamais affichée ; vos contributions sont signées d'un pseudonyme.</p>
    <form class="c-form" id="cF1" novalidate>
      ${champ("email", "Adresse e-mail", { type: "email", max: 200, placeholder: "vous@exemple.fr" })}
      <div class="c-boutons"><button class="c-go" type="submit">Recevoir un code</button></div>
    </form>`, "compte contributeur");
  const f = corps.querySelector("#cF1");
  f.querySelector("input").focus();
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email)) return montrerErreur(f, "Adresse e-mail invalide.");
    envoyer(f, async () => {
      await requete("/auth/v1/otp", { email: v.email, create_user: true });
      vueCode(v.email, suite);
    });
  };
}

function vueCode(email, suite) {
  ouvrir("Entrer le code", `
    <p>Un code vient d'être envoyé à <b>${esc(email)}</b>. Il est valable une heure. Pensez à regarder dans les indésirables.</p>
    <form class="c-form" id="cF2" novalidate>
      ${champ("code", "Code reçu", { min: 6, max: 10, classe: "c-code", placeholder: "••••••", type: "text" })}
      <div class="c-boutons"><button class="c-go" type="submit">Valider</button>
      <button class="c-lien" type="button" id="cAutre">Changer d'adresse</button></div>
    </form>`, "compte contributeur");
  const f = corps.querySelector("#cF2");
  const inp = f.querySelector("input");
  inp.setAttribute("inputmode", "numeric"); inp.setAttribute("autocomplete", "one-time-code");
  inp.focus();
  f.querySelector("#cAutre").onclick = () => vueConnexion(suite);
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    const code = v.code.replace(/\D/g, "");
    if (code.length < 6) return montrerErreur(f, "Le code compte au moins six chiffres.");
    envoyer(f, async () => {
      const s = await requete("/auth/v1/verify", { type: "email", email, token: code });
      session = normaliser(s); ecrire(CLE_SESSION, session);
      const c = await chargerCompte();
      if (!c || !c.profil || c.profil.charte_version < c.charte_actuelle) vueCharte(suite);
      else { toast("Bienvenue, " + c.profil.pseudo); suite ? suite() : vueMenu(); }
    });
  };
}

const CHARTE = `<ol class="c-charte">
  <li><span><b>Chaque proposition comporte une source en lien.</b> Création ou modification : sans adresse web, DOI ou ISBN vérifiable, elle n'est pas reçue. Une planète comporte au moins un satellite, c'est-à-dire une source.</span></li>
  <li><span><b>La nature de chaque source est indiquée honnêtement</b> : source primaire, synthèse, méta-analyse, étude empirique, essai, savoir expérientiel ou texte juridique. Sa couleur indique au lecteur son degré de certitude.</span></li>
  <li><span><b>Le fait établi, l'interprétation et la controverse restent distincts.</b> Un fait établi est documenté et ne fait pas débat ; une interprétation a un auteur ; une controverse présente un désaccord réel.</span></li>
  <li><span><b>Chaque galaxie a sa légitimité.</b> On ne corrige pas une approche au nom d'une autre : on les relie par des trous de ver.</span></li>
  <li><span><b>On décrit des façons de penser les troubles, pas des personnes.</b> Aucune information ne doit permettre d'identifier un patient, un proche ou un tiers.</span></li>
  <li><span><b>Votre propre histoire n'est pas une source.</b> Les savoirs expérientiels sont bienvenus lorsqu'ils sont publiés : récit, association, recherche participative. Ne donnez ici aucune information sur votre santé.</span></li>
  <li><span><b>Ni conseil médical, ni promotion.</b> Pas de recommandation de traitement, pas de lien commercial ou publicitaire.</span></li>
  <li><span><b>Vos contributions sont publiées sous votre pseudonyme</b> et peuvent être corrigées par d'autres contributeurs ; l'historique conserve chaque version. Vous acceptez qu'elles soient diffusées, modifiées et réutilisées dans l'atlas.</span></li>
  <li><span><b>Un administrateur vérifie chaque proposition avant sa publication</b>, à partir de la source que vous indiquez. Tant qu'elle n'a pas été examinée, vous pouvez la modifier ou la retirer.</span></li>
  <li><span><b>Les modérateurs traitent les signalements</b> et peuvent retirer en urgence un contenu publié. Les administrateurs peuvent refuser une proposition, restaurer une version antérieure ou suspendre un compte. Chaque décision est motivée.</span></li>
</ol>`;

function vueCharte(suite) {
  const dejaInscrit = compte && compte.profil;
  ouvrir("Charte des contributeurs", `
    <p>Galapsy s'enrichit grâce à ses lecteurs, à une condition : que chaque ajout puisse être vérifié. Avant de contribuer, vous vous engagez à respecter les règles suivantes.</p>
    ${CHARTE}
    <form class="c-form" id="cF3" novalidate>
      ${dejaInscrit ? `<p class="c-note">La charte a évolué depuis votre inscription : merci de la relire et de la signer à nouveau.</p>`
        : champ("pseudo", "Pseudonyme public", { min: 3, max: 40, placeholder: "Votre nom de plume",
            aide: "Il signera vos contributions. Il ne pourra pas être changé." })}
      <label class="c-cocher"><input type="checkbox" name="engagement"><span>Je m'engage à respecter la charte et à sourcer chacune de mes contributions.</span></label>
      <div class="c-boutons"><button class="c-go" type="submit">Signer la charte</button></div>
    </form>
    <p class="c-aide">Si vous traversez vous-même une période difficile, vous n'êtes pas seul·e : en France, le 3114 répond jour et nuit.</p>`, `version ${CHARTE_VERSION}`);
  const f = corps.querySelector("#cF3");
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    if (!v.engagement) return montrerErreur(f, "Cochez l'engagement pour signer la charte.");
    envoyer(f, async () => {
      compte = await rpc("galapsy_signer_charte", { p_pseudo: v.pseudo || (compte.profil && compte.profil.pseudo), p_version: CHARTE_VERSION });
      majFab();
      toast("Charte signée. Bienvenue, " + compte.profil.pseudo + " !");
      suite ? suite() : vueMenu();
    });
  };
}

/* ============================================================
   MENU
   ============================================================ */
function vueMenu() {
  const p = compte && compte.profil;
  const ctx = [];
  if (state.level === "galaxy" || state.level === "system") {
    const g = byId(state.gal);
    ctx.push(["sys", `Ajouter une étoile à la galaxie ${g.n}`, "une école ou un foyer d'idées, situé dans le temps"]);
    ctx.push(["corrgal", `Modifier la galaxie ${g.n}`, "sa définition, son axe ou son hypothèse, source à l'appui"]);
  }
  if (state.level === "system") {
    const s = sysById(state.gal, state.sys);
    ctx.unshift(["pla", `Ajouter une planète à l'étoile ${s.n}`, "une notion, avec son fait établi, son interprétation, sa controverse et ses sources"]);
  }
  const btn = ([a, t, s, e]) => `<button type="button" data-a="${a}"><span>${esc(t)}${s ? `<small>${esc(s)}</small>` : ""}</span>${e ? `<em>${e}</em>` : "<em>→</em>"}</button>`;
  const lignes = [];
  if (ctx.length) lignes.push(`<h4>ici</h4><div class="c-menu">${ctx.map(btn).join("")}</div>`);
  lignes.push(`<h4>une notion manque ?</h4><div class="c-menu">${btn(["chercher", "Chercher, puis créer une notion", "l'atlas suggère où la placer, sources à l'appui"])}</div>`);
  if (!ctx.length) lignes.push(`<p>Pour ajouter un satellite ou corriger un texte, ouvrez une planète : les actions de contribution apparaissent dans chaque fiche.</p>`);
  const compteBtns = [];
  if (!session || !compte) compteBtns.push(["cnx", "Se connecter ou créer un compte", "un code par e-mail, sans mot de passe"]);
  else if (!p) compteBtns.push(["charte", "Signer la charte", "pour commencer à contribuer"]);
  else {
    compteBtns.push(["mes", "Mes contributions", `${p.acceptees} acceptée${p.acceptees > 1 ? "s" : ""} · ${p.en_attente} en attente`]);
    if (estModo()) compteBtns.push(["modo", role() === "admin" ? "Vérifier et publier" : "Modération", role() === "admin" ? "propositions à vérifier, signalements" : "signalements, propositions en cours", compte.a_relire ? String(compte.a_relire) : ""]);
    if (estModo()) compteBtns.push(["membres", "Membres et rôles", p.proprietaire ? "nommer les administrateurs et les modérateurs" : role() === "admin" ? "nommer les modérateurs" : ""]);
    if (role() === "admin") compteBtns.push(["textes", "Textes et réglages du site", "écran d'ouverture, présentation, longueur des fiches…"]);
  }
  compteBtns.push(["lirecharte", "Lire la charte", ""]);
  compteBtns.push(["couleurs", "Comprendre les couleurs", "le degré de certitude des sources"]);
  if (session) compteBtns.push(["deco", "Se déconnecter", compte && compte.email ? compte.email : ""]);
  lignes.push(`<h4>${p ? esc(p.pseudo) + " · " + esc({ contributeur: "contributeur", confirme: "contributeur confirmé", moderateur: "modérateur", admin: "administrateur" }[p.role]) : "compte"}</h4><div class="c-menu">${compteBtns.map(btn).join("")}</div>`);
  if (p && p.role !== "admin") lignes.push(`<p class="c-aide">Chaque proposition comporte une source en lien et est vérifiée par un administrateur avant sa publication.</p>`);
  ouvrir("Contribuer à l'atlas", lignes.join(""), "atelier de l'atlas");
  corps.querySelectorAll("[data-a]").forEach(b => b.onclick = () => {
    const a = b.dataset.a, g = state.gal, s = state.sys;
    if (a === "chercher") { fermerAtelier(); window.GALAPSY_ATLAS && GALAPSY_ATLAS.ouvrirRecherche(); }
    else if (a === "sys") exigerCompte(() => formSysteme(g));
    else if (a === "pla") exigerCompte(() => formPlanete(g, s));
    else if (a === "corrgal") exigerCompte(() => formCorrection(g));
    else if (a === "cnx") vueConnexion(null);
    else if (a === "charte") vueCharte(null);
    else if (a === "mes") vueMesContributions();
    else if (a === "modo") vueModeration("a_relire");
    else if (a === "membres") vueMembres();
    else if (a === "textes") vueTextes();
    else if (a === "lirecharte") ouvrir("Charte des contributeurs", CHARTE + `<p class="c-aide">En France, le 3114 répond jour et nuit à toute personne en souffrance.</p>`, `version ${CHARTE_VERSION}`);
    else if (a === "couleurs") vueCouleurs();
    else if (a === "deco") {
      const t = session && session.access_token;
      requete("/auth/v1/logout", {}, t).catch(() => { });
      oublierSession(); toast("Vous êtes déconnecté·e."); vueMenu();
    }
  });
  if (session && !compte) chargerCompte().then(() => { if (!atelier.hidden && titreAtelier.textContent === "Contribuer à l'atlas") vueMenu(); });
}

function vueCouleurs() {
  if (window.GALAPSY_ATLAS) return ouvrir("Lire les couleurs", `<p>Chaque planète distingue trois niveaux : le fait établi, l'interprétation et la controverse. Chaque satellite, c'est-à-dire chaque source, a une couleur qui indique sa nature, et donc son degré de certitude.</p>${GALAPSY_ATLAS.legendeHTML()}`, "code couleur");
  ouvrir("Lire les couleurs", `
    <p>Chaque planète sépare trois strates, et chaque lune — chaque source — porte une couleur selon sa nature. Ensemble, elles disent quel degré de certitude accorder à ce qu'on lit.</p>
    <h4>les trois strates d'une planète</h4>
    <div class="c-legende">
      <div style="--c:#7fd4a8"><span class="c-pastille"></span><span><b>fait établi</b>${esc(STRATES.f)}</span></div>
      <div style="--c:#9fb4f0"><span class="c-pastille"></span><span><b>interprétation</b>${esc(STRATES.i)}</span></div>
      <div style="--c:#e8956e"><span class="c-pastille"></span><span><b>controverse</b>${esc(STRATES.c)}</span></div>
    </div>
    <h4>la nature des satellites</h4>
    <div class="c-legende">${Object.keys(NATURES).map(k => `<div style="--c:${K[k].c}"><span class="c-pastille"></span><span><b>${esc(K[k].l)}</b>${esc(NATURES[k])}</span></div>`).join("")}</div>
    <h4>et aussi</h4>
    <div class="c-legende">
      <div style="--c:#63d6e2"><span class="c-pastille"></span><span><b>trou de ver</b>La même notion vue par une autre galaxie.</span></div>
      <div style="--c:#ff7089"><span class="c-pastille"></span><span><b>étoile instable</b>Une catégorie qui a implosé et projeté sa matière ailleurs.</span></div>
    </div>`, "code couleur");
}

/* ============================================================
   CONTRIBUER
   ============================================================ */
function formLune(gid, sid, pid) {
  const p = trouver(pid).o;
  ouvrir("Ajouter un satellite", `
    <p>Un satellite est une source vérifiable qui documente la planète <b>${esc(p.n)}</b>.</p>
    <form class="c-form" id="cFL" novalidate>
      ${champsLune("")}
      ${choixNature()}
      ${champ("msg", "Message aux administrateurs", { requis: false, max: 1000, lignes: 2 })}
      <div class="c-boutons"><button class="c-go" type="submit">Proposer la source</button></div>
    </form>`, "nouveau satellite");
  const f = corps.querySelector("#cFL");
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    if (!v.k) return montrerErreur(f, "Choisissez la nature de la source.");
    envoyer(f, async () => {
      const r = await rpc("galapsy_proposer", { p_type: "lune", p_parent: pid, p_donnees: { t: v.t, a: v.a, ref: v.ref, k: v.k }, p_message: v.msg || null });
      merci(r);
    });
  };
}

function formPlanete(gid, sid, pre) {
  const g = byId(gid), s = trouver(sid).o;      // aussi les systèmes nés d'une supernova
  let nb = 0;
  const blocLune = () => {
    nb++;
    return `<div class="c-lune-bloc" data-lune="${nb}"><header><span>satellite ${nb}</span>${nb > 1 ? `<button class="c-lien" type="button" data-retirer>retirer</button>` : ""}</header>
      ${champsLune("l" + nb + "_")}${choixNature().replace(/name="k"/g, `name="l${nb}_k"`)}</div>`;
  };
  ouvrir("Ajouter une planète", `
    <p>Une planète est une notion clinique. Elle tournera autour de l'étoile <b>${esc(s.n)}</b>, dans la galaxie ${esc(g.n)}. Chaque planète distingue le fait établi, l'interprétation et la controverse.</p>
    <form class="c-form" id="cFP" novalidate>
      ${champsNotion({ n: (pre && pre.n) || "" })}
      <h4>satellites — au moins une source en lien</h4>
      <div class="c-lunes" id="cLunes">${blocLune()}</div>
      <button class="c-mini" type="button" id="cPlusLune">＋ un autre satellite</button>
      ${champ("msg", "Message aux administrateurs", { requis: false, max: 1000, lignes: 2 })}
      <div class="c-boutons"><button class="c-go" type="submit">Proposer la planète</button></div>
    </form>`, "nouvelle planète");
  const f = corps.querySelector("#cFP"), zone = f.querySelector("#cLunes");
  f.querySelector("#cPlusLune").onclick = () => {
    if (zone.children.length >= 12) return toast("Douze satellites au plus à la création.");
    zone.insertAdjacentHTML("beforeend", blocLune());
    zone.lastElementChild.querySelector("input").focus();
  };
  zone.onclick = e => { if (e.target.matches("[data-retirer]")) e.target.closest(".c-lune-bloc").remove(); };
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    const lunes = [...zone.querySelectorAll(".c-lune-bloc")].map(b => {
      const i = b.dataset.lune;
      return { t: v[`l${i}_t`], a: v[`l${i}_a`], ref: v[`l${i}_ref`], k: v[`l${i}_k`] };
    });
    const sansNature = lunes.findIndex(l => !l.k);
    if (sansNature >= 0) return montrerErreur(f, `Choisissez la nature de la source pour le satellite ${sansNature + 1}.`);
    envoyer(f, async () => {
      const r = await rpc("galapsy_proposer", { p_type: "planete", p_parent: sid,
        p_donnees: { n: v.n, r: v.r, f: v.f, i: v.i, c: v.c, lunes }, p_message: v.msg || null });
      merci(r);
    });
  };
}

function formSysteme(gid, pre) {
  const g = byId(gid);
  ouvrir("Ajouter une étoile", `
    <p>Une étoile est une école ou un foyer d'idées de la galaxie <b>${esc(g.n)}</b>, situé dans le temps. Vous pourrez ensuite y ajouter des planètes.</p>
    <form class="c-form" id="cFS" novalidate>
      ${champ("n", "Nom", { min: 2, max: 80, mots: 6, placeholder: "L'antipsychiatrie", valeur: (pre && pre.n) || "" })}
      ${champ("s", "Repère", { min: 2, max: 60, mots: 6, requis: false, placeholder: "1960 – 1980  ·  ou un auteur, une date" })}
      ${champ("r", "Présentation", { min: 20, max: 700, mots: 25, lignes: 3, aide: "Une ou deux phrases : ce que cette école apporte à la galaxie." })}
      ${champSource("src", "Source de référence sur cette école", "")}
      ${champ("msg", "Message aux administrateurs", { requis: false, max: 1000, lignes: 2 })}
      <div class="c-boutons"><button class="c-go" type="submit">Proposer l'étoile</button></div>
    </form>`, "nouvelle étoile");
  const f = corps.querySelector("#cFS");
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    envoyer(f, async () => {
      const r = await rpc("galapsy_proposer", { p_type: "systeme", p_parent: gid, p_donnees: { n: v.n, s: v.s, r: v.r }, p_message: v.msg || null, p_source: v.src });
      merci(r);
    });
  };
}

function formTrou(gid, sid, pid) {
  const p = trouver(pid).o;
  const cibles = [];
  GAL.forEach(g => {
    if (g.id === gid) return;
    g.sy.filter(s => !s._born).forEach(s => s.pl.forEach(x => cibles.push({ id: x.id, n: x.n, ou: g.n + " › " + s.n, hue: g.hue })));
  });
  const liste = q => cibles.filter(c => !q || (c.n + " " + c.ou).toLowerCase().includes(q.toLowerCase())).slice(0, 80)
    .map(c => `<label class="c-cible"><input type="radio" name="cible" value="${esc(c.id)}"><span><b>${esc(c.n)}</b><small style="color:hsl(${c.hue},50%,70%)">${esc(c.ou)}</small></span></label>`).join("")
    || `<p class="c-vide" style="padding:12px">Aucune planète ne correspond.</p>`;
  ouvrir("Ouvrir un trou de ver", `
    <p>Un trou de ver relie <b>${esc(p.n)}</b> à la même notion, vue par une autre galaxie.</p>
    <form class="c-form" id="cFT" novalidate>
      <div class="c-champ"><span>Planète d'arrivée</span><input class="c-recherche" type="search" placeholder="Chercher une notion…" id="cCherche" autocomplete="off">
      <div class="c-cibles" id="cCibles">${liste("")}</div></div>
      ${champ("l", "Ce qui relie les deux notions", { min: 10, max: 160, mots: 10, placeholder: "La même entité vue comme circuit" })}
      ${champSource("src", "Source qui établit ce lien", "")}
      <div class="c-boutons"><button class="c-go" type="submit">Proposer le passage</button></div>
    </form>`, "nouveau trou de ver");
  const f = corps.querySelector("#cFT");
  f.querySelector("#cCherche").oninput = e => { f.querySelector("#cCibles").innerHTML = liste(e.target.value); };
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    if (!v.cible) return montrerErreur(f, "Choisissez la planète d'arrivée.");
    envoyer(f, async () => {
      const r = await rpc("galapsy_proposer", { p_type: "trou", p_parent: pid, p_donnees: { cible: v.cible, l: v.l }, p_source: v.src });
      merci(r);
    });
  };
}

function champsNotion(o) {
  return champ("n", "Nom de la notion", { min: 2, max: 80, mots: 6, valeur: o.n || "" }) +
    champ("r", "Résumé", { min: 20, max: 1200, mots: limites.resume, lignes: 3, valeur: o.r || "", aide: "Deux phrases : de quoi s'agit-il, et pourquoi cette notion compte dans cette approche." }) +
    champ("f", "Fait établi", { min: 20, max: 1100, mots: limites.niveau, lignes: 3, classe: "c-fait", valeur: o.f || "", aide: esc(STRATES.f) }) +
    champ("i", "Interprétation", { min: 20, max: 1100, mots: limites.niveau, lignes: 3, classe: "c-interp", valeur: o.i || "", aide: esc(STRATES.i) }) +
    champ("c", "Controverse", { min: 20, max: 1100, mots: limites.niveau, lignes: 3, classe: "c-contro", valeur: o.c || "", aide: esc(STRATES.c) });
}
/* les champs d'un élément, selon son type (création, modification, reprise d'une proposition) */
function champsPour(type, o) {
  o = o || {};
  return {
    galaxie: () => champsGalaxie(o),
    zone: () => champ("n", "Nom", { min: 2, max: 60, mots: 4, valeur: o.n }) + champ("d", "Ce que cette région contiendrait", { min: 20, max: 900, mots: 30, lignes: 4, valeur: o.d }),
    systeme: () => champ("n", "Nom", { min: 2, max: 80, mots: 6, valeur: o.n }) + champ("s", "Repère", { min: 2, max: 60, mots: 6, requis: false, valeur: o.s }) +
      champ("r", "Présentation", { min: 20, max: 700, mots: 25, lignes: 3, valeur: o.r }),
    planete: () => champsNotion(o),
    lune: () => champsLune("", o) + choixNature(o.k),
    trou: () => champ("l", "Ce qui relie les deux notions", { min: 10, max: 160, mots: 10, valeur: o.l })
  }[type]();
}

function champsGalaxie(o) {
  o = o || {};
  return champ("n", "Nom de la galaxie", { min: 2, max: 60, mots: 4, valeur: o.n, placeholder: "Addictions" }) +
    champ("s", "Axe", { min: 2, max: 80, mots: 6, valeur: o.s, placeholder: "Usages, dépendance, sevrage" }) +
    champ("d", "Définition", { min: 20, max: 900, mots: 30, lignes: 3, valeur: o.d, aide: "Ce qu'étudie cette approche, en une phrase." }) +
    champ("r", "Présentation", { min: 20, max: 900, mots: 30, lignes: 3, valeur: o.r, aide: "Ce que cette approche apporte de particulier." }) +
    champ("th", "Hypothèse centrale", { min: 10, max: 400, mots: 40, lignes: 2, valeur: o.th, placeholder: "Une addiction naît de la rencontre entre un produit, une personne et un moment." });
}

function formGalaxie(pre) {
  pre = pre || {};
  const zone = pre.depuis_zone ? FRONT.find(f => f.id === pre.depuis_zone) : null;
  ouvrir(zone ? "Cartographier une zone" : "Proposer une galaxie", `
    <p>${zone ? `La zone <b>${esc(zone.n)}</b> deviendrait une galaxie à part entière, aux côtés des ${esc(String(GAL.length))} galaxies existantes.`
      : "Une galaxie est une façon d'aborder la souffrance psychique, avec ses propres écoles et ses propres notions."}
    Réservez cette proposition à une approche qui ne trouve sa place dans aucune galaxie existante. Un administrateur la vérifiera avant sa publication.</p>
    <form class="c-form" id="cFG" novalidate>
      ${champsGalaxie({ n: pre.n || (zone && zone.n) || "" })}
      ${champSource("src", "Source de référence qui fonde cette approche", "")}
      ${champ("msg", "Autres références", { requis: false, max: 1000, lignes: 3,
        aide: "Un ou deux ouvrages, revues ou institutions de plus, qui montrent que cette approche est reconnue." })}
      <div class="c-boutons"><button class="c-go" type="submit">Proposer la galaxie</button></div>
    </form>`, zone ? "frontière" : "nouvelle galaxie");
  const f = corps.querySelector("#cFG");
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    envoyer(f, async () => {
      const d = { n: v.n, s: v.s, d: v.d, r: v.r, th: v.th };
      if (zone) d.depuis_zone = zone.id;
      const r = await rpc("galapsy_proposer", { p_type: "galaxie", p_parent: null, p_donnees: d, p_message: v.msg || null, p_source: v.src });
      merci(r);
    });
  };
}

/* Une notion manque : où la placer ? L'atlas suggère, le contributeur choisit. */
function assistantCreation(terme) {
  const A = window.GALAPSY_ATLAS;
  const sg = A.suggerer(terme);
  const bouton = (a, titre, sous, extra) => `<button type="button" data-a="${a}" ${extra || ""}><span>${titre}${sous ? `<small>${sous}</small>` : ""}</span><em>→</em></button>`;
  const blocs = [];
  if (sg.existantes.length) blocs.push(`<h4>existe peut-être déjà</h4><div class="c-menu">${sg.existantes.map((x, i) =>
    bouton("existe", esc(x.p.n), esc(x.g.n + " › " + x.s.n) + " : l'ouvrir, ou lui ajouter une source", `data-i="${i}"`)).join("")}</div>`);
  if (sg.systemes.length) blocs.push(`<h4>créer la planète « ${esc(terme)} » ici</h4><div class="c-menu">${sg.systemes.map((x, i) =>
    bouton("planete", `${esc(x.s.n)} <span style="color:hsl(${x.g.hue},60%,72%)">· ${esc(x.g.n)}</span>`,
      x.proches.length ? "voisine de : " + esc(x.proches.slice(0, 3).join(", ")) : esc(x.s.s || ""), `data-i="${i}"`)).join("")}</div>`);
  const galaxies = sg.galaxies.length ? sg.galaxies.slice(0, 2) : GAL.map(g => ({ g }));
  sg.galaxies = galaxies;
  blocs.push(`<h4>${sg.galaxies.length && sg.systemes.length ? "ou créer une nouvelle étoile dans une galaxie" : "ou créer une étoile dans la galaxie la plus proche"}</h4><div class="c-menu">${galaxies.map((x, i) =>
    bouton("systeme", `<span style="color:hsl(${x.g.hue},60%,74%)">${esc(x.g.n)}</span>`, i < 2 && galaxies.length <= 3 ? "une école ou un foyer d'idées, où placer ensuite la notion" : esc(x.g.s), `data-i="${i}"`)).join("")}</div>`);
  const zone = sg.zones[0];
  const blocZone = `<h4>${sg.zoneForte ? "conseillé : une zone encore inexplorée" : "si c'est une approche à part entière"}</h4><div class="c-menu">${zone
    ? bouton("zone", `Cartographier la zone « ${esc(zone.f.n)} »`, sg.zoneForte
        ? "en faire une nouvelle galaxie, après vérification par un administrateur"
        : "en faire une nouvelle galaxie, après vérification par un administrateur")
    : ""}${bouton("galaxie", "Proposer une nouvelle galaxie", "seulement si aucune galaxie ne convient")}</div>`;
  if (sg.zoneForte) blocs.unshift(blocZone); else blocs.push(blocZone);
  if (!sg.existantes.length && !sg.systemes.length && !zone)
    blocs.unshift(`<p class="c-note">Aucun emplacement évident : choisissez la galaxie la plus proche de votre approche, ou proposez-en une nouvelle.</p>`);
  ouvrir(`Placer « ${terme} »`, `<p>Voici les emplacements les plus proches, d'après les galaxies, étoiles et planètes qui abordent déjà ce sujet. À vous de choisir ; un modérateur pourra ajuster.</p>${blocs.join("")}`, "nouvelle notion");
  corps.querySelectorAll("[data-a]").forEach(b => b.onclick = () => {
    const a = b.dataset.a, i = +b.dataset.i;
    if (a === "existe") { const x = sg.existantes[i]; fermerAtelier(); A.aller({ type: "planete", g: x.g, s: x.s, p: x.p }); }
    else if (a === "planete") { const x = sg.systemes[i]; exigerCompte(() => formPlanete(x.g.id, x.s.id, { n: terme })); }
    else if (a === "systeme") { const x = sg.galaxies[i]; exigerCompte(() => formSysteme(x.g.id)); }
    else if (a === "zone") exigerCompte(() => formGalaxie({ depuis_zone: zone.f.id }));
    else exigerCompte(() => formGalaxie({ n: terme }));
  });
}

/* Création depuis la loupe : choisir où, puis remplir le formulaire */
function choixListe(titre, intro, items, suite, surtitre) {
  // items : [{ id, titre, sous, teinte, donnees }]
  const rendre = q => items.filter(x => !q || norm((x.titre + " " + x.sous)).includes(norm(q))).slice(0, 120)
    .map(x => `<label class="c-cible"><input type="radio" name="choix" value="${esc(x.id)}"><span><b>${esc(x.titre)}</b><small style="color:${x.teinte}">${esc(x.sous)}</small></span></label>`).join("")
    || `<p class="c-vide" style="padding:12px">Aucun résultat.</p>`;
  ouvrir(titre, `<p>${intro}</p>
    <form class="c-form" id="cFX2" novalidate>
      <div class="c-champ"><input class="c-recherche" type="search" id="cFiltre" placeholder="Filtrer…" autocomplete="off">
      <div class="c-cibles" id="cListe">${rendre("")}</div></div>
      <div class="c-boutons"><button class="c-go" type="submit">Continuer</button></div>
    </form>`, surtitre);
  const f = corps.querySelector("#cFX2");
  f.querySelector("#cFiltre").oninput = e => { f.querySelector("#cListe").innerHTML = rendre(e.target.value); };
  f.onsubmit = e => {
    e.preventDefault();
    const v = (f.querySelector("input[name=choix]:checked") || {}).value;
    if (!v) return montrerErreur(f, "Faites un choix dans la liste.");
    suite(items.find(x => x.id === v).donnees);
  };
}
const norm = t => String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
function creerType(type) {
  exigerCompte(() => {
    if (type === "galaxie") return formGalaxie();
    if (type === "etoile") return choixListe("Nouvelle étoile",
      "Une étoile est une école, un courant ou un foyer de pensée. Dans quelle galaxie, c'est-à-dire dans quelle approche, s'inscrit-elle ?",
      GAL.map(g => ({ id: g.id, titre: g.n, sous: g.s, teinte: `hsl(${g.hue},60%,72%)`, donnees: g })),
      g => formSysteme(g.id), "création · étoile");
    if (type === "planete") {
      const items = [];
      GAL.forEach(g => tousSystemes(g).forEach(s => items.push({ id: s.id, titre: s.n, sous: g.n + (s.s ? " · " + s.s : ""), teinte: `hsl(${g.hue},60%,72%)`, donnees: { g, s } })));
      return choixListe("Nouvelle planète",
        "Une planète est une notion clinique. Autour de quelle étoile, c'est-à-dire de quelle école de pensée, gravite-t-elle ?",
        items, x => formPlanete(x.g.id, x.s.id), "création · planète");
    }
    if (type === "satellite") {
      const items = [];
      GAL.forEach(g => tousSystemes(g).forEach(s => s.pl.forEach(p => items.push({ id: p.id, titre: p.n, sous: g.n + " › " + s.n, teinte: `hsl(${g.hue},60%,72%)`, donnees: { g, s, p } }))));
      return choixListe("Nouveau satellite",
        "Un satellite est une source vérifiable. Quelle planète, c'est-à-dire quelle notion, documente-t-il ?",
        items, x => formLune(x.g.id, x.s.id, x.p.id), "création · satellite");
    }
  });
}

/* Corriger un élément publié (galaxie, zone, système, planète, lune, trou de ver) */
function formCorrection(id) {
  const t = trouver(id);
  if (!t) return toast("Élément introuvable.");
  if (t.type === "planete" && ((t.o.so || []).length || (t.o.wh || []).length)) {
    const items = [[t.o.id, `La notion « ${t.o.n} »`, "nom, résumé, fait, interprétation, controverse"]]
      .concat((t.o.so || []).map((m, i) => [m.id, `Satellite ${i + 1} : ${m.t}`, m.a]))
      .concat((t.o.wh || []).map(w => [w.id, `Trou de ver : ${w.l}`, ""]));
    ouvrir("Que modifier ?", `<div class="c-menu">${items.map(([i, l, s]) =>
      `<button type="button" data-id="${esc(i)}"><span>${esc(l)}${s ? `<small>${esc(s)}</small>` : ""}</span><em>→</em></button>`).join("")}</div>`, "correction");
    corps.querySelectorAll("[data-id]").forEach(b => b.onclick = () => formCorrectionDe(b.dataset.id));
    return;
  }
  formCorrectionDe(id);
}
function formCorrectionDe(id) {
  const t = trouver(id);
  if (!t || !t.o.id) return toast("Cet élément n'est pas encore synchronisé : réessayez dans un instant.");
  const o = t.o, type = t.type, admin = role() === "admin";
  ouvrir("Proposer une modification", `
    <p>${esc(TYPES[type][0].toUpperCase() + TYPES[type].slice(1))} : <b>${esc(o.n || o.t || o.l)}</b>.
    ${admin ? "En tant qu'administrateur, votre modification sera publiée aussitôt." : "Un administrateur vérifiera la source avant de publier votre modification."}</p>
    <form class="c-form" id="cFC" novalidate>
      ${champsPour(type, o)}
      ${champ("just", "Ce que vous modifiez", { min: 10, max: 1000, lignes: 2, aide: "Une phrase. Elle apparaîtra dans l'historique." })}
      ${champSource("src", "Source qui justifie la modification", "")}
      <div class="c-boutons"><button class="c-go" type="submit">${admin ? "Publier la modification" : "Proposer la modification"}</button></div>
    </form>`, "modification");
  const f = corps.querySelector("#cFC");
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    const d = {};
    CHAMPS[type].forEach(k => { if (v[k] !== undefined) d[k] = v[k]; });
    if (type === "lune" && !d.k) return montrerErreur(f, "Choisissez la nature de la source.");
    envoyer(f, async () => {
      const r = await rpc("galapsy_corriger", { p_objet: o.id, p_donnees: d, p_justification: v.just, p_source: v.src });
      merci(r);
    });
  };
}

/* Reprendre sa proposition tant qu'elle n'a pas été examinée */
function formReprise(x) {
  const type = x.type, d = x.donnees || {}, correction = x.action === "correction";
  const avecSource = type !== "lune";
  ouvrir("Modifier ma proposition", `
    <p>${esc(x.chemin || "")}</p>
    <form class="c-form" id="cFR" novalidate>
      ${champsPour(type, d)}
      ${correction ? champ("msg", "Ce que vous modifiez", { min: 10, max: 1000, lignes: 2, valeur: x.justification || "" })
        : champ("msg", "Message aux administrateurs", { requis: false, max: 1000, lignes: 2, valeur: x.justification || "" })}
      ${avecSource ? champSource("src", type === "planete" && !correction ? "Source complémentaire (facultative)" : "Source en lien", x.source || "") : ""}
      <div class="c-boutons"><button class="c-go" type="submit">Enregistrer</button></div>
    </form>`, "ma proposition");
  const f = corps.querySelector("#cFR");
  if (type === "planete" && !correction) { const s = f.querySelector('[name="src"]'); if (s) s.required = false; }
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    const nd = {};
    CHAMPS[type].forEach(k => { if (v[k] !== undefined) nd[k] = v[k]; });
    if (type === "lune" && !nd.k) return montrerErreur(f, "Choisissez la nature de la source.");
    if (type === "trou") nd.cible = d.cible;
    if (type === "galaxie" && d.depuis_zone) nd.depuis_zone = d.depuis_zone;
    envoyer(f, async () => {
      await rpc("galapsy_modifier_proposition", { p_revision: x.id, p_donnees: nd, p_source: v.src || null, p_message: v.msg || null });
      toast("Proposition mise à jour.");
      vueMesContributions();
    });
  };
}

function formSignalement(id) {
  const t = trouver(id);
  if (!t) return;
  ouvrir("Signaler", `
    <p>Un problème avec <b>${esc(t.o.n || t.o.t || t.o.l)}</b> ? Source introuvable ou mal qualifiée, erreur factuelle, propos stigmatisant, donnée personnelle… Les modérateurs examineront votre signalement.</p>
    <form class="c-form" id="cFX" novalidate>
      ${champ("motif", "Le problème", { min: 10, max: 1000, lignes: 4 })}
      <div class="c-boutons"><button class="c-go" type="submit">Envoyer le signalement</button></div>
    </form>`, "signalement");
  const f = corps.querySelector("#cFX");
  f.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(f); if (!v) return;
    envoyer(f, async () => {
      await rpc("galapsy_signaler", { p_objet: id, p_motif: v.motif });
      ouvrir("Merci", `<div class="c-ok"><b>signalement envoyé</b><p>L'équipe de modération va l'examiner.</p></div>`, "signalement");
    });
  };
}

/* ============================================================
   HISTORIQUE ET SUIVI
   ============================================================ */
function donneesHTML(type, d, avant) {
  const cles = (CHAMPS[type] || Object.keys(d || {})).filter(k => (d && d[k] != null) || (avant && avant[k] != null));
  const val = (k, x) => k === "k" ? (K[x] ? `<span style="color:${K[x].c}">${esc(K[x].l)}</span>` : esc(x)) : k === "ref" ? lienRef(x) : esc(x);
  return `<div class="c-donnees">${cles.map(k => {
    const a = avant ? avant[k] : undefined, n = d ? d[k] : undefined;
    if (avant && a === n) return "";
    return `<div><span>${esc(LIBELLES[k] || k)}</span>${avant ? `${a != null ? `<del>${val(k, a)}</del>` : ""}<ins>${val(k, n)}</ins>` : val(k, n)}</div>`;
  }).join("")}</div>`;
}
const badge = (statut, auto) => statut === "en_attente" ? `<span class="c-badge c-attente">en attente</span>`
  : statut === "acceptee" ? `<span class="c-badge c-acceptee">${auto ? "publiée" : "acceptée"}</span>`
  : statut === "refusee" ? `<span class="c-badge c-refusee">refusée</span>` : `<span class="c-badge c-neutre">${esc(statut)}</span>`;

async function vueHistorique(id) {
  const t = trouver(id), tx = textesObjets.find(o => o.id === id);
  const nom = t ? (t.o.n || t.o.t || t.o.l) : tx ? "Texte du site : " + tx.d.libelle : id;
  attente("Historique");
  let h;
  try { h = await rpc("galapsy_historique", { p_objet: id }); }
  catch (e) { return ouvrir("Historique", erreurHTML(e.message)); }
  const type = t ? t.type : tx ? "texte" : null;
  const enLigne = h.find(x => x.statut === "acceptee" && x.action !== "retrait");
  ouvrir("Historique", `<p>${esc(nom)} — ${h.length} version${h.length > 1 ? "s" : ""}. Chaque modification reste consultable.</p>
    <div class="c-liste">${h.map((x, i) => `<article class="c-carte">
      <div class="c-carte-tete"><b>${esc(ACTIONS[x.action] || x.action)}</b>${badge(x.statut, x.auto)}</div>
      <p class="c-qui">${esc(x.auteur)} · ${esc(dateFr(x.date))}${x.moderateur && x.moderateur !== x.auteur ? ` · relu par ${esc(x.moderateur)}` : ""}</p>
      ${x.justification && x.justification !== "Corpus fondateur" ? `<p class="c-just">${esc(x.justification)}</p>` : ""}
      ${x.source ? `<p class="c-qui">source : ${lienRef(x.source)}</p>` : ""}
      ${x.motif ? `<p class="c-just">Motif : ${esc(x.motif)}</p>` : ""}
      <details class="c-details"><summary>contenu de cette version</summary>${donneesHTML(type, x.donnees)}</details>
      ${role() === "admin" && x.statut === "acceptee" && x !== enLigne && ["creation", "correction", "restauration"].includes(x.action)
        ? `<div class="c-boutons"><button class="c-mini" type="button" data-restaurer="${esc(x.id)}">Restaurer cette version</button></div>` : ""}
    </article>`).join("")}</div>`, "historique");
  corps.querySelectorAll("[data-restaurer]").forEach(b => b.onclick = async () => {
    if (!confirm("Remettre cette version en ligne ? La version actuelle restera dans l'historique.")) return;
    try { await rpc("galapsy_restaurer", { p_revision: b.dataset.restaurer }); toast("Version restaurée."); await synchroniser(); vueHistorique(id); }
    catch (e) { toast(e.message); }
  });
}

async function vueMesContributions() {
  attente("Mes contributions");
  let l;
  try { l = await rpc("galapsy_mes_contributions"); }
  catch (e) { return ouvrir("Mes contributions", erreurHTML(e.message)); }
  ouvrir("Mes contributions", l.length ? `<div class="c-liste">${l.map(x => `<article class="c-carte">
      <div class="c-carte-tete"><b>${esc(ACTIONS[x.action] || x.action)} · ${esc(TYPES[x.type] || x.type)}</b>${badge(x.statut, x.auto)}</div>
      <p class="c-chemin">${esc(x.chemin)}</p>
      <p class="c-qui">${esc(dateFr(x.date))}</p>
      ${x.source ? `<p class="c-qui">source : ${lienRef(x.source)}</p>` : ""}
      ${x.motif ? `<p class="c-just">${x.statut === "refusee" ? "Motif du refus" : "Note"} : ${esc(x.motif)}</p>` : ""}
      ${x.modifiable ? `<div class="c-boutons"><button class="c-mini" type="button" data-reprendre="${esc(x.id)}">Modifier</button>
        <button class="c-lien" type="button" data-annuler-prop="${esc(x.id)}">Retirer ma proposition</button></div>`
        : x.objet_statut === "publie" ? `<div class="c-boutons"><button class="c-mini" type="button" data-voir="${esc(x.objet)}">Voir dans l'atlas</button></div>` : ""}
    </article>`).join("")}</div>`
    : `<p class="c-vide">Aucune contribution pour l'instant. Pour commencer, ouvrez une planète et ajoutez-lui une source.</p>`, "suivi");
  corps.querySelectorAll("[data-voir]").forEach(b => b.onclick = () => allerA(b.dataset.voir));
  corps.querySelectorAll("[data-reprendre]").forEach(b => b.onclick = () => formReprise(l.find(x => x.id === b.dataset.reprendre)));
  corps.querySelectorAll("[data-annuler-prop]").forEach(b => b.onclick = async () => {
    if (!confirm("Retirer cette proposition ? Elle ne sera pas examinée.")) return;
    try { await rpc("galapsy_annuler_proposition", { p_revision: b.dataset.annulerProp }); toast("Proposition retirée."); chargerCompte(); vueMesContributions(); }
    catch (e) { toast(e.message); }
  });
}

/* ============================================================
   MODÉRATION
   ============================================================ */
let onglet = "a_relire";
async function vueModeration(o) {
  onglet = o || onglet;
  attente("Modération");
  let f;
  try { f = await rpc("galapsy_file_moderation"); }
  catch (e) { return ouvrir("Modération", erreurHTML(e.message)); }
  const tabs = [["a_relire", "À vérifier", f.a_relire.length], ["signalements", "Signalements", f.signalements.length], ["recents", "Publiés récemment", f.recents.length]];
  let html = `<div class="c-onglets">${tabs.map(([k, l, n]) => `<button type="button" data-onglet="${k}" aria-pressed="${k === onglet}">${l} · ${n}</button>`).join("")}</div>`;

  if (onglet === "a_relire") {
    html += f.a_relire.length ? `<div class="c-liste">${f.a_relire.map(x => `<article class="c-carte" data-rev="${esc(x.id)}">
      <div class="c-carte-tete"><b>${x.action === "creation" ? "nouvelle " : "correction · "}${esc(TYPES[x.type])}</b><time>${esc(dateFr(x.date))}</time></div>
      <p class="c-chemin">${esc(x.chemin || "")}${x.cible ? ` ⤳ ${esc(x.cible)}` : ""}</p>
      <p class="c-qui">par ${esc(x.auteur || "?")} · ${x.auteur_acceptees} acceptée${x.auteur_acceptees > 1 ? "s" : ""}, ${x.auteur_refusees} refusée${x.auteur_refusees > 1 ? "s" : ""}</p>
      ${donneesHTML(x.type, x.donnees, x.action === "correction" ? x.actuel : null)}
      ${x.lunes && x.lunes.length ? `<h4>ses satellites</h4>${x.lunes.map(l => donneesHTML("lune", l)).join("")}` : ""}
      ${x.justification ? `<p class="c-just">${esc(x.justification)}</p>` : ""}
      ${x.source ? `<p class="c-verifier">À vérifier : ${lienRef(x.source)}</p>` : x.lunes && x.lunes.length ? `<p class="c-verifier">À vérifier : les liens des satellites ci-dessus.</p>` : ""}
      ${!f.peut_valider ? `<p class="c-note">Seuls les administrateurs valident les propositions. Si vous repérez un problème, prévenez-les.</p>` : `
      <div class="c-decision"><textarea placeholder="Motif — obligatoire pour un refus, il sera transmis à l'auteur" maxlength="1000"></textarea>
      <div class="c-boutons"><button class="c-go" type="button" data-dec="accepter">Source vérifiée : publier</button>
      <button class="c-go c-danger" type="button" data-dec="refuser">Refuser</button></div></div>`}
    </article>`).join("")}</div>` : `<p class="c-vide">Rien à relire. L'atlas est à jour.</p>`;
  } else if (onglet === "signalements") {
    html += f.signalements.length ? `<div class="c-liste">${f.signalements.map(x => `<article class="c-carte" data-sig="${esc(x.id)}" data-objet="${esc(x.objet)}">
      <div class="c-carte-tete"><b>${esc(TYPES[x.type])}${x.objet_statut !== "publie" ? " · déjà retiré" : ""}</b><time>${esc(dateFr(x.date))}</time></div>
      <p class="c-chemin">${esc(x.chemin)}</p>
      <p class="c-just">${esc(x.motif)}</p><p class="c-qui">signalé par ${esc(x.auteur || "?")}</p>
      <details class="c-details"><summary>contenu signalé</summary>${donneesHTML(x.type, x.donnees)}</details>
      <div class="c-decision"><textarea placeholder="Note (facultative pour classer, obligatoire pour retirer)" maxlength="1000"></textarea>
      <div class="c-boutons">
        ${x.objet_statut === "publie" && !["galaxie", "zone"].includes(x.type) ? `<button class="c-go c-danger" type="button" data-sigdec="retirer">Retirer le contenu</button>` : ""}
        <button class="c-go" type="button" data-sigdec="traite">Marquer traité</button>
        <button class="c-lien" type="button" data-sigdec="rejete">Classer sans suite</button>
        <button class="c-lien" type="button" data-voir="${esc(x.objet)}">Voir</button></div></div>
    </article>`).join("")}</div>` : `<p class="c-vide">Aucun signalement en cours.</p>`;
  } else {
    html += `<p>Les publications directes des administrateurs, ces trente derniers jours. L'historique permet de revenir à une version antérieure.</p>` +
      (f.recents.length ? `<div class="c-liste">${f.recents.map(x => `<article class="c-carte" data-objet="${esc(x.objet)}">
      <div class="c-carte-tete"><b>${esc(ACTIONS[x.action])} · ${esc(TYPES[x.type])}</b><time>${esc(dateFr(x.date))}</time></div>
      <p class="c-chemin">${esc(x.chemin)}</p><p class="c-qui">par ${esc(x.auteur || "?")}${x.objet_statut !== "publie" ? " · retiré depuis" : ""}</p>
      ${x.justification ? `<p class="c-just">${esc(x.justification)}</p>` : ""}
      <details class="c-details"><summary>contenu</summary>${donneesHTML(x.type, x.donnees)}</details>
      <div class="c-boutons"><button class="c-mini" type="button" data-histo="${esc(x.objet)}">Historique</button>
      ${x.objet_statut === "publie" ? `<button class="c-mini" type="button" data-voir="${esc(x.objet)}">Voir</button>
      <button class="c-mini" type="button" data-retirer="${esc(x.objet)}">Retirer</button>` : ""}</div>
    </article>`).join("")}</div>` : `<p class="c-vide">Aucune publication directe ces 30 derniers jours.</p>`);
  }
  ouvrir(role() === "admin" ? "Vérifier et publier" : "Modération", html, role() === "admin" ? "administration" : "modération");

  corps.querySelectorAll("[data-onglet]").forEach(b => b.onclick = () => vueModeration(b.dataset.onglet));
  corps.querySelectorAll("[data-voir]").forEach(b => b.onclick = () => allerA(b.dataset.voir));
  corps.querySelectorAll("[data-histo]").forEach(b => b.onclick = () => vueHistorique(b.dataset.histo));
  corps.querySelectorAll("[data-dec]").forEach(b => b.onclick = async () => {
    const carte = b.closest("[data-rev]"), motif = carte.querySelector("textarea").value.trim();
    if (b.dataset.dec === "refuser" && motif.length < 5) { toast("Indiquez au contributeur le motif du refus."); carte.querySelector("textarea").focus(); return; }
    b.disabled = true;
    try {
      await rpc("galapsy_moderer", { p_revision: carte.dataset.rev, p_decision: b.dataset.dec, p_motif: motif || null });
      toast(b.dataset.dec === "accepter" ? "Vérifiée et publiée." : "Refusée ; le motif est transmis.");
      if (b.dataset.dec === "accepter") synchroniser();
      chargerCompte(); vueModeration();
    } catch (e) { toast(e.message); b.disabled = false; }
  });
  corps.querySelectorAll("[data-sigdec]").forEach(b => b.onclick = async () => {
    const carte = b.closest("[data-sig]"), note = carte.querySelector("textarea").value.trim();
    try {
      if (b.dataset.sigdec === "retirer") {
        if (note.length < 5) { toast("Indiquez le motif du retrait."); carte.querySelector("textarea").focus(); return; }
        await rpc("galapsy_retirer", { p_objet: carte.dataset.objet, p_motif: note });
        await rpc("galapsy_traiter_signalement", { p_id: carte.dataset.sig, p_decision: "traite", p_note: "Contenu retiré : " + note });
        synchroniser();
      } else {
        await rpc("galapsy_traiter_signalement", { p_id: carte.dataset.sig, p_decision: b.dataset.sigdec, p_note: note || null });
      }
      toast("Signalement traité."); chargerCompte(); vueModeration();
    } catch (e) { toast(e.message); }
  });
  corps.querySelectorAll("[data-retirer]").forEach(b => b.onclick = async () => {
    const motif = prompt("Motif du retrait (il restera dans l'historique) :");
    if (!motif || motif.trim().length < 5) return;
    try { await rpc("galapsy_retirer", { p_objet: b.dataset.retirer, p_motif: motif.trim() }); toast("Retiré de l'atlas."); synchroniser(); vueModeration(); }
    catch (e) { toast(e.message); }
  });
}

async function vueMembres() {
  attente("Membres");
  let l, inv = [];
  try {
    l = await rpc("galapsy_membres");
    if (role() === "admin") inv = await rpc("galapsy_invitations");
  } catch (e) { return ouvrir("Membres", erreurHTML(e.message)); }
  const admin = role() === "admin", fondateur = !!(compte && compte.profil && compte.profil.proprietaire);
  const roles = { contributeur: "contributeur", confirme: "confirmé", moderateur: "modérateur", admin: "administrateur" };
  const rolesPossibles = fondateur ? roles : { contributeur: "contributeur", confirme: "confirmé", moderateur: "modérateur" };
  ouvrir("Membres et rôles", `
    <div class="c-legende" style="margin-bottom:14px">
      <div style="--c:#9fb4f0"><span class="c-pastille"></span><span><b>modérateur</b>Traite les signalements et peut retirer en urgence un contenu publié.</span></div>
      <div style="--c:#e3bd6a"><span class="c-pastille"></span><span><b>administrateur</b>Vérifie les sources et publie les propositions, modifie les textes du site, nomme les modérateurs.</span></div>
      <div style="--c:#f8f3fd"><span class="c-pastille"></span><span><b>fondateur</b>Nomme les administrateurs.</span></div>
    </div>
    ${admin ? `<h4>nommer par adresse e-mail</h4>
    <form class="c-form" id="cFI" novalidate>
      ${champ("email", "Adresse e-mail", { type: "email", max: 200, placeholder: "prenom@exemple.fr",
        aide: "Si la personne a déjà un compte, son rôle change aussitôt. Sinon, elle le recevra en créant son compte avec cette adresse." })}
      <label class="c-champ"><span>Rôle</span><select name="role"><option value="moderateur">modérateur</option>${fondateur ? `<option value="admin">administrateur</option>` : ""}</select></label>
      <div class="c-boutons"><button class="c-go" type="submit">Nommer</button></div>
    </form>
    ${inv.length ? `<h4>en attente d'inscription</h4><div class="c-liste">${inv.map(i => `<article class="c-carte c-membre">
      <div><b style="font-weight:500">${esc(i.email)}</b><p class="c-qui" style="margin:4px 0 0">${esc(roles[i.role])} · désigné par ${esc(i.par || "?")}</p></div>
      <button class="c-mini" type="button" data-annuler="${esc(i.email)}">Annuler</button></article>`).join("")}</div>` : ""}` : `<p>Seuls les administrateurs modifient les rôles.</p>`}
    <h4>${l.length} membre${l.length > 1 ? "s" : ""}</h4>
    <div class="c-liste">${l.map(m => `<article class="c-carte c-membre" data-pseudo="${esc(m.pseudo)}">
      <div><b style="font-weight:500">${esc(m.pseudo)}</b>${m.proprietaire ? ` <span class="c-badge c-attente">fondateur</span>` : ""}${m.suspendu ? ` <span class="c-badge c-refusee">suspendu</span>` : ""}
      <p class="c-qui" style="margin:4px 0 0">${m.acceptees} acceptée${m.acceptees > 1 ? "s" : ""} · ${m.refusees} refusée${m.refusees > 1 ? "s" : ""} · depuis le ${esc(dateFr(m.cree_le))}</p></div>
      ${admin && !m.moi && !m.proprietaire && (fondateur || m.role !== "admin") ? `<div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
        <select data-role aria-label="Rôle de ${esc(m.pseudo)}">${Object.entries(rolesPossibles).map(([k, v]) => `<option value="${k}" ${k === m.role ? "selected" : ""}>${v}</option>`).join("")}</select>
        <label class="c-qui"><input type="checkbox" data-susp ${m.suspendu ? "checked" : ""}> suspendu</label></div>`
        : `<span class="c-badge c-neutre">${esc(roles[m.role])}</span>`}
    </article>`).join("")}</div>`, "communauté");
  const fi = corps.querySelector("#cFI");
  if (fi) fi.onsubmit = e => {
    e.preventDefault();
    const v = lireForm(fi); if (!v) return;
    envoyer(fi, async () => {
      const r = await rpc("galapsy_inviter", { p_email: v.email, p_role: v.role });
      toast(r.statut === "nomme" ? `${r.pseudo} est maintenant ${v.role === "admin" ? "administrateur" : "modérateur"}.` : "Désignation enregistrée : elle prendra effet à l'inscription.");
      vueMembres();
    });
  };
  corps.querySelectorAll("[data-annuler]").forEach(b => b.onclick = async () => {
    try { await rpc("galapsy_annuler_invitation", { p_email: b.dataset.annuler }); vueMembres(); } catch (e) { toast(e.message); }
  });
  corps.querySelectorAll("[data-pseudo]").forEach(c => {
    const maj = async () => {
      try {
        await rpc("galapsy_definir_role", { p_pseudo: c.dataset.pseudo, p_role: c.querySelector("[data-role]").value, p_suspendu: c.querySelector("[data-susp]").checked });
        toast("Rôle mis à jour.");
      } catch (e) { toast(e.message); vueMembres(); }
    };
    const s = c.querySelector("[data-role]"), x = c.querySelector("[data-susp]");
    if (s) s.onchange = maj; if (x) x.onchange = maj;
  });
}

/* Textes du site : écran d'ouverture, relevé, visite guidée, à propos, fiches */
function vueTextes() {
  if (!textesObjets.length) return ouvrir("Textes du site", `<p class="c-note">Les textes se chargent. Réessayez dans un instant.</p>`);
  const groupes = [];
  textesObjets.forEach(o => { let g = groupes.find(x => x.n === o.d.groupe); if (!g) groupes.push(g = { n: o.d.groupe, l: [] }); g.l.push(o); });
  ouvrir("Textes et réglages du site", `
    <h4>longueur des fiches</h4>
    <form class="c-carte c-form c-reglages" id="cFReg" novalidate>
      <label class="c-champ"><span>Résumé d'une notion, en mots</span><input type="number" name="mots_resume" min="20" max="120" value="${limites.resume}"></label>
      <label class="c-champ"><span>Fait établi, interprétation, controverse : chacun, en mots</span><input type="number" name="mots_niveau" min="20" max="100" value="${limites.niveau}"></label>
      <div class="c-boutons"><button class="c-go" type="submit">Enregistrer les réglages</button></div>
    </form>
    <h4>textes</h4>
    <p>Ces textes s'affichent dans l'application ; chaque modification est publiée aussitôt et gardée dans l'historique.</p>
    <p class="c-aide">Mise en forme : *italique*, **gras**, [mot en couleur]. Les nombres s'écrivent tout seuls : {galaxies}, {Galaxies}, {zones}, {Zones}.</p>
    ${groupes.map(g => `<h4>${esc(g.n)}</h4><div class="c-liste">${g.l.map(o => `<form class="c-carte c-form" data-texte-id="${esc(o.id)}" novalidate>
      <label class="c-champ"><span>${esc(o.d.libelle)}</span><textarea name="v" rows="${Math.min(6, Math.max(2, Math.ceil(o.d.v.length / 60)))}" maxlength="3000">${esc(o.d.v)}</textarea></label>
      <div class="c-boutons"><button class="c-go" type="submit">Enregistrer</button>
      <button class="c-lien" type="button" data-histo>Historique</button>
      ${window.GALAPSY_ATLAS && GALAPSY_ATLAS.DEFAUTS[o.d.cle] && GALAPSY_ATLAS.DEFAUTS[o.d.cle] !== o.d.v ? `<button class="c-lien" type="button" data-origine>Texte d'origine</button>` : ""}</div>
    </form>`).join("")}</div>`).join("")}`, "administration");
  const fr = corps.querySelector("#cFReg");
  fr.onsubmit = e => {
    e.preventDefault();
    const r = +fr.mots_resume.value, n = +fr.mots_niveau.value;
    envoyer(fr, async () => {
      await rpc("galapsy_regler", { p_cle: "mots_resume", p_valeur: r });
      await rpc("galapsy_regler", { p_cle: "mots_niveau", p_valeur: n });
      limites = { resume: r, niveau: n };
      toast("Réglages enregistrés.");
    });
  };
  corps.querySelectorAll("[data-texte-id]").forEach(f => {
    const id = f.dataset.texteId, o = textesObjets.find(x => x.id === id);
    f.onsubmit = e => {
      e.preventDefault();
      const v = f.querySelector("textarea").value.trim();
      if (!v) return montrerErreur(f, "Le texte ne peut pas être vide.");
      envoyer(f, async () => { await rpc("galapsy_corriger", { p_objet: id, p_donnees: { v }, p_justification: "" }); toast("Texte enregistré."); await synchroniser(); });
    };
    f.querySelector("[data-histo]").onclick = () => vueHistorique(id);
    const og = f.querySelector("[data-origine]");
    if (og) og.onclick = () => { f.querySelector("textarea").value = GALAPSY_ATLAS.DEFAUTS[o.d.cle]; };
  });
}

/* ============================================================
   FICHES : actions de contribution
   ============================================================ */
let fiche = null;
function rafraichirFiche() {
  const panel = document.getElementById("panel");
  if (!fiche || !panel.classList.contains("open")) return;
  const pb = document.getElementById("panelBody"), y = pb.scrollTop;
  try {
    if (fiche.t === "pl" && plById(fiche.gid, fiche.sid, fiche.pid)) openPlanet(fiche.gid, fiche.sid, fiche.pid);
    else if (fiche.t === "star" && sysById(fiche.gid, fiche.sid)) openStar(fiche.gid, fiche.sid);
    else if (fiche.t === "front") openFront(fiche.fid);
  } catch (e) { return; }
  pb.scrollTop = y;
}
function zoneActions(actions, signature) {
  const pb = document.getElementById("panelBody");
  const z = document.createElement("div");
  z.className = "c-zone";
  z.innerHTML = `<p class="sec-label">contribuer</p><div class="c-acts">${actions.map(([a, l, prim]) =>
    `<button type="button" data-a="${a}" class="${prim ? "c-prim" : ""}">${l}</button>`).join("")}</div>${signature ? `<p class="c-signe">${signature}</p>` : ""}`;
  const pledge = pb.querySelector(".pledge");
  pledge ? pb.insertBefore(z, pledge) : pb.appendChild(z);
  return z;
}

function brancherFiches() {
  const _openPlanet = openPlanet;
  openPlanet = function (gid, sid, pid) {
    _openPlanet(gid, sid, pid);
    fiche = { t: "pl", gid, sid, pid };
    const p = plById(gid, sid, pid);
    const z = zoneActions([["lune", "＋ Satellite · source", 1], ["trou", "⤳ Trou de ver"], ["corriger", "Modifier"], ["histo", "Historique"], ["signaler", "Signaler"]],
      p._par ? "Planète ajoutée par " + esc(p._par) : "");
    z.querySelectorAll("[data-a]").forEach(b => b.onclick = () => {
      const a = b.dataset.a;
      if (a === "histo") return vueHistorique(pid);
      exigerCompte(() => a === "lune" ? formLune(gid, sid, pid) : a === "trou" ? formTrou(gid, sid, pid)
        : a === "corriger" ? formCorrection(pid) : formSignalement(pid));
    });
  };

  const _openStar = openStar;
  openStar = function (gid, sid) {
    _openStar(gid, sid);
    fiche = { t: "star", gid, sid };
    const s = sysById(gid, sid);
    const z = zoneActions([["pla", "＋ Planète", 1], ["corriger", "Modifier"], ["histo", "Historique"], ["signaler", "Signaler"]],
      s._par ? "Étoile ajoutée par " + esc(s._par) : "");
    z.querySelectorAll("[data-a]").forEach(b => b.onclick = () => {
      const a = b.dataset.a;
      if (a === "histo") return vueHistorique(sid);
      exigerCompte(() => a === "pla" ? formPlanete(gid, sid) : a === "corriger" ? formCorrection(sid) : formSignalement(sid));
    });
  };

  const _openFront = openFront;
  openFront = function (fid) {
    _openFront(fid);
    fiche = { t: "front", fid };
    const z = zoneActions([["galaxie", "Cartographier cette zone", 1], ["corriger", "Modifier"], ["histo", "Historique"]], "");
    z.querySelectorAll("[data-a]").forEach(b => b.onclick = () =>
      b.dataset.a === "histo" ? vueHistorique(fid)
        : exigerCompte(() => b.dataset.a === "galaxie" ? formGalaxie({ depuis_zone: fid }) : formCorrection(fid)));
  };

  const _closePanel = closePanel;
  closePanel = function () { fiche = null; _closePanel(); };
}

/* ============================================================
   DÉMARRAGE
   ============================================================ */
function lienMagique() {
  // repli : si l'on a cliqué le lien de l'e-mail plutôt que saisi le code
  if (!location.hash || !/access_token=|error_description=/.test(location.hash)) return;
  const q = new URLSearchParams(location.hash.slice(1));
  history.replaceState(null, "", location.pathname + location.search);
  if (q.get("access_token")) {
    session = normaliser({ access_token: q.get("access_token"), refresh_token: q.get("refresh_token"),
      expires_in: +q.get("expires_in") || 3600, expires_at: +q.get("expires_at") || 0 });
    ecrire(CLE_SESSION, session);
    setTimeout(() => toast("Vous êtes connecté·e."), 800);
  } else if (q.get("error_description")) {
    setTimeout(() => toast(traduire(q.get("error_description"))), 800);
  }
}

function demarrer() {
  lienMagique();
  construire();
  brancherFiches();
  synchroniser();
  if (session) chargerCompte();
  addEventListener("online", () => synchroniser());
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && Date.now() - dernierChargement > 5 * 60 * 1000) {
      synchroniser(); if (session) chargerCompte();
    }
  });
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", demarrer);
else demarrer();

/* pour les tests et le débogage */
window.GALAPSY_PLATEFORME = { actif: true, creer: assistantCreation, creerType, assembler, synchroniser, allerA, trouver,
  etat: () => ({ session: !!session, compte, corpusDistant }) };
})();
