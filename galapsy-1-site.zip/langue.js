/* ============================================================
   GALAPSY′ — langue de l'interface
   Le français est la langue de l'atlas. L'anglais est proposé
   en option : textes du site, interface et corpus fondateur
   traduits. Tout contenu modifié ou ajouté depuis (par les
   contributeurs) s'affiche en français, jamais avec une
   traduction périmée. La contribution et le mode audio
   restent en français.
   Chargé en tête de page, avant le moteur.
   ============================================================ */
(function () {
"use strict";

const CLE = "galapsy.langue";
const lire = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
const ecrire = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { } };

let choix = lire(CLE);
// le mode audio n'existe qu'en français : s'il est actif, l'atlas reste en français
if (choix === "en" && lire("galapsy.audio") === "on") choix = "fr";
const LANGUE = choix === "en" ? "en" : "fr";
const EN = LANGUE === "en";
window.LANGUE = LANGUE;
document.documentElement.lang = LANGUE;
document.documentElement.classList.add("l-" + LANGUE);

// les traductions ne sont chargées qu'en anglais
if (EN) document.write('<script src="langue-en.js?v=8"><\/script>');
const donnees = () => window.GALAPSY_EN || { interface: {}, textes: {}, corpus: {} };

/* empreinte d'un texte français (la même que celle du générateur) */
function empreinte(s) {
  s = String(s);
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(36) + "." + s.length;
}

/* ---------- interface ---------- */
let D = null;
const dico = () => D || (window.GALAPSY_EN ? (D = new Map(Object.entries(GALAPSY_EN.interface))) : new Map());
const L = fr => EN ? (dico().has(fr) ? dico().get(fr) : fr) : fr;
const Lf = (fr, v) => L(fr).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m));
const pluriel = n => EN ? n !== 1 : n > 1;
const Lp = (n, un, plusieurs) => n + " " + L(pluriel(n) ? plusieurs : un);
const Lpf = (n, un, plusieurs, v) => Lf(pluriel(n) ? plusieurs : un, Object.assign({ n }, v || {}));
window.L = L; window.Lf = Lf; window.Lp = Lp; window.Lpf = Lpf;

/* nombres en toutes lettres */
window.LNB = EN ? ["no", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve",
  "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"] : null;

/* ---------- textes du site ---------- */
/* un texte modifié par un administrateur n'a pas encore de traduction : il reste en français */
function texte(fr) {
  if (!EN || fr == null) return fr;
  const t = donnees().textes[empreinte(fr)];
  return t != null ? t : fr;
}

/* ---------- corpus : traduction champ par champ, d'après le texte français exact ---------- */
function champs(o, liste) {
  const C = donnees().corpus;
  liste.forEach(c => {
    const v = o[c];
    if (typeof v !== "string" || !v) return;
    const t = C[empreinte(v)];
    if (t != null) o[c] = t;
  });
}
function corpus(GAL, FRONT, K) {
  if (!EN) return;
  const systeme = s => {
    champs(s, ["n", "s", "r"]);
    if (s.nova) { champs(s.nova, ["q", "w"]); (s.nova.gen || []).forEach(systeme); }
    (s.pl || []).forEach(p => {
      champs(p, ["n", "r", "f", "i", "c"]);
      (p.wh || []).forEach(w => champs(w, ["l"]));
    });
  };
  (GAL || []).forEach(g => { champs(g, ["n", "s", "r", "d", "th"]); (g.sy || []).forEach(systeme); });
  (FRONT || []).forEach(f => champs(f, ["n", "d"]));
  if (K) Object.keys(K).forEach(k => champs(K[k], ["l"]));
}

/* ---------- changer de langue ---------- */
function basculer(vers) {
  ecrire(CLE, vers || (EN ? "fr" : "en"));
  location.reload();
}

/* ---------- traduction des textes fixes de la page ---------- */
const MOTIFS = [
  [/^Planète ajoutée par (.+)$/, "Planet added by $1"],
  [/^Étoile ajoutée par (.+)$/, "Star added by $1"]
];
const SAUF = "#cAtelier, #modeAudio, [data-fr], script, style, textarea, code";
const ATTRS = ["aria-label", "title", "placeholder", "alt"];
function traduit(t) {
  const k = t.replace(/\s+/g, " ");
  if (dico().has(k)) return dico().get(k);
  for (const [re, r] of MOTIFS) if (re.test(k)) return k.replace(re, r);
  return null;
}
function trTexte(n) {
  const v = n.nodeValue, t = v.trim();
  if (!t || t.length > 600 || !/[A-Za-zÀ-ÿ]/.test(t)) return;
  const e = traduit(t);
  if (e == null || e === t) return;
  const a = v.indexOf(t);
  n.nodeValue = v.slice(0, a) + e + v.slice(a + t.length);
}
function trAttr(el, nom) {
  const v = el.getAttribute(nom);
  if (!v) return;
  const e = traduit(v.trim());
  if (e != null && e !== v) el.setAttribute(nom, e);
}
const exclu = el => !!(el && el.closest && el.closest(SAUF));
function trNoeud(n) {
  if (n.nodeType === 3) { if (!exclu(n.parentElement)) trTexte(n); return; }
  if (n.nodeType !== 1 || exclu(n)) return;
  ATTRS.forEach(a => trAttr(n, a));
  const w = document.createTreeWalker(n, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
    acceptNode: x => (x.nodeType === 1 && x.matches(SAUF)) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
  });
  let x;
  while ((x = w.nextNode())) {
    if (x.nodeType === 3) trTexte(x);
    else ATTRS.forEach(a => x.hasAttribute(a) && trAttr(x, a));
  }
}

/* ---------- ce qui reste en français ---------- */
function ouvrirAvisFrancais() {
  const A = window.GALAPSY_ATLAS;
  const html = `<div>
    <p>The contributors write and review Galapsy in French: every proposal is checked by a French-speaking administrator against its source before it is published.</p>
    <p>To contribute, switch the interface to French. You can come back to English at any time with the <b>EN</b> button.</p>
    <div class="c-boutons"><button class="c-go" type="button" id="lVersFr" lang="fr">Passer en français</button>
    <button class="btn" type="button" id="lRester">Stay in English</button></div></div>`;
  if (!A || !A.ouvrirFeuille) { if (confirm("Contributions are made in French. Switch to French?")) basculer("fr"); return; }
  const c = A.ouvrirFeuille("Contributing happens in French", html, "contribute");
  c.querySelector("#lVersFr").onclick = () => basculer("fr");
  c.querySelector("#lRester").onclick = () => A.fermerFeuille();
}
function interception(e) {
  const t = e.target && e.target.closest ? e.target : null;
  if (!t) return;
  if (t.closest("#langPorte, #btnLangue")) { e.preventDefault(); e.stopImmediatePropagation(); basculer(); return; }
  if (!EN) return;
  if (t.closest("#entreeAudio, #btnAudio")) {
    // le mode audio est enregistré en français : on y bascule directement
    e.preventDefault(); e.stopImmediatePropagation();
    ecrire("galapsy.audio", "on"); basculer("fr"); return;
  }
  if (t.closest("#cFab, .c-zone [data-a], #aCreer, .a-type-creation")) {
    e.preventDefault(); e.stopImmediatePropagation(); ouvrirAvisFrancais();
  }
}
addEventListener("click", interception, true);

if (EN) {
  new MutationObserver(liste => {
    for (const m of liste) {
      if (m.type === "childList") m.addedNodes.forEach(trNoeud);
      else if (m.type === "characterData") { if (!exclu(m.target.parentElement)) trTexte(m.target); }
      else if (m.type === "attributes" && !exclu(m.target)) trAttr(m.target, m.attributeName);
    }
  }).observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  // les textes du site s'affichent une fois traduits (pas d'éclair de français)
  document.addEventListener("DOMContentLoaded", () => {
    document.title = L(document.title);
    const b = document.getElementById("langPorte");
    if (b) { b.textContent = "Version française"; b.lang = "fr"; b.setAttribute("aria-label", "Lire Galapsy en français"); }
    document.documentElement.classList.add("l-pret");
  });
}

window.GALAPSY_LANGUE = { langue: LANGUE, L, Lf, Lp, Lpf, texte, corpus, basculer, empreinte, traduit };
})();
