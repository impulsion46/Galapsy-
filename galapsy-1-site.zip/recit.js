/* ============================================================
   GALAPSY' — le récit de présentation
   Une seule mise en scène sert deux usages :
   · la visite guidée qui ouvre l'application (on peut toucher
     l'écran pour avancer, ou la passer) ;
   · la vidéo de présentation, filmée image par image
     (window.GALAPSY_FILM = true).
   Les textes viennent de « Textes du site » (groupe Présentation).
   ============================================================ */
(function () {
"use strict";

const FILM = window.GALAPSY_FILM === true;
const CLE_INTRO = "galapsy.intro.v1";
const lire = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
const ecrire = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { } };
const A = () => window.GALAPSY_ATLAS;
/* l'horloge du récit : elle s'arrête quand on met la présentation en pause */
let pauseDebut = null, decalage = 0;
const temps = () => (pauseDebut != null ? pauseDebut : performance.now()) - decalage;
const attendre = ms => new Promise(r => {
  const fin = temps() + ms;
  const tic = () => { const reste = fin - temps(); if (reste <= 0) r(); else setTimeout(tic, pauseDebut != null ? 120 : Math.min(reste + 2, 250)); };
  tic();
});
/* temps de lecture d'un texte : environ 16 caractères par seconde, comme un sous-titre confortable */
const lecture = html => { const t = String(html || "").replace(/<[^>]+>/g, "").trim(); return t ? 1400 + t.length * 62 : 0; };
const evt = nom => { try { if (window.__evt) window.__evt(nom); } catch (e) { } };
const T = k => (window.TXT ? TXT(k) : "");
const NB = ["aucune", "une", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize"];
const deux = n => String(n).padStart(2, "0");
const lisse = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
const portrait = () => innerHeight > innerWidth * 1.15;

const recit = {
  en_cours: false, jeton: 0, el: null, suivant: null, novaVisite: null, _annuler: null, _legT: 0, _legMs: 0,

  construire() {
    if (this.el) return;
    const e = this.el = document.createElement("div");
    e.id = "recit"; e.className = "r" + (FILM ? " r-film" : ""); e.hidden = true;
    e.setAttribute("aria-label", "Présentation de Galapsy");
    e.innerHTML = `
      <div class="r-voile"></div>
      <div class="r-coins" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
      <p class="r-hud" id="rHud" aria-hidden="true"></p>
      <div class="r-legende" id="rLeg" aria-live="polite"><span class="r-sur" id="rSur"></span><span class="r-texte" id="rTexte"></span></div>
      <span class="r-doigt" id="rD1" aria-hidden="true"></span><span class="r-doigt" id="rD2" aria-hidden="true"></span>
      <div class="r-carte" id="rCarte" hidden></div>
      <p class="r-pause-info" aria-hidden="true">en pause · touchez l'écran pour reprendre</p>
      <div class="r-barre">
        <div class="r-points" id="rPoints"></div>
        <button class="btn btn-ico r-pause" type="button" id="rPause" aria-label="Mettre la présentation en pause" aria-pressed="false"><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path class="i-pause" d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="currentColor"/><path class="i-lecture" d="M8 5l11 7-11 7z" fill="currentColor"/></svg></button>
        <button class="btn btn-ico a-son" type="button" id="rSon"></button>
        <button class="btn" type="button" id="rPasser">Passer la présentation</button>
      </div>`;
    document.body.appendChild(e);
    e.querySelector("#rSon").innerHTML = A().ICONE_SON;
    e.querySelector("#rSon").onclick = ev => { ev.stopPropagation(); A().son.basculer(); };
    e.querySelector("#rPasser").onclick = ev => { ev.stopPropagation(); this.terminer(); };
    e.querySelector("#rPause").onclick = ev => { ev.stopPropagation(); this.basculerPause(); };
    document.addEventListener("keydown", ev => {
      if (!this.en_cours || FILM) return;
      if (ev.key === " " || ev.key === "k") { ev.preventDefault(); this.basculerPause(); }
      else if (ev.key === "ArrowRight" && this.suivant && pauseDebut == null) this.suivant();
      else if (ev.key === "Escape") this.terminer();
    });
    // toucher l'écran : passer au moment suivant
    e.addEventListener("click", ev => {
      if (ev.target.closest(".r-barre,.r-carte button")) return;
      if (pauseDebut != null) { this.basculerPause(); return; }   // en pause, toucher l'écran reprend
      if (this.suivant) this.suivant();
    });
  },

  /* ---------- pause ---------- */
  basculerPause(forcer) {
    const enPause = forcer != null ? forcer : pauseDebut == null;
    if (enPause && pauseDebut == null) pauseDebut = performance.now();
    else if (!enPause && pauseDebut != null) { decalage += performance.now() - pauseDebut; pauseDebut = null; }
    if (!this.el) return;
    this.el.classList.toggle("en-pause", pauseDebut != null);
    this.el.querySelector(".r-pause-info").style.top = (this.hautEntete() + 12) + "px";
    const b = this.el.querySelector("#rPause");
    b.setAttribute("aria-pressed", String(pauseDebut != null));
    b.setAttribute("aria-label", pauseDebut != null ? "Reprendre la présentation" : "Mettre la présentation en pause");
  },

  /* ---------- mise en scène ---------- */
  hud(txt) { this.el.querySelector("#rHud").textContent = txt || ""; },
  legende(sur, html) {
    const L = this.el.querySelector("#rLeg");
    L.classList.remove("visible");
    const j = this.jeton;
    setTimeout(() => {
      if (j !== this.jeton) return;
      this.placer();
      this.el.querySelector("#rSur").textContent = sur || "";
      this.el.querySelector("#rTexte").innerHTML = html || "";
      if (sur || html) L.classList.add("visible");
    }, 380);
    this._legT = temps(); this._legMs = html ? 380 + lecture(html) : 0;
  },
  /* la légende se place là où elle ne gêne pas : à gauche de la fiche, ou en haut sur téléphone */
  placer() {
    const L = this.el.querySelector("#rLeg");
    const panneau = document.getElementById("panel").classList.contains("open");
    const feuille = document.querySelector(".a-feuille:not([hidden]),#over:not([hidden]),#disp:not([hidden])");
    const hauteFeuille = feuille && this.posFeuille === "haut";
    L.className = "r-legende" + (L.classList.contains("visible") ? " visible" : "") +
      (panneau ? (portrait() ? " r-haut" : " r-gauche") : hauteFeuille ? " r-haut-feuille" : feuille ? " r-bas-fort" : "");
    L.style.top = panneau && portrait() ? (this.hautEntete() + 18) + "px" : "";
    this.el.classList.toggle("r-sans-hud", hauteFeuille || (portrait() && !!(panneau || feuille)));
  },
  points(n, i) {
    this.el.querySelector("#rPoints").innerHTML = Array.from({ length: n }, (_, k) => `<span class="${k < i ? "fait" : k === i ? "ici" : ""}"></span>`).join("");
  },
  pause(ms) {
    const j = this.jeton;
    const cible = Math.max(temps() + ms, this._legT + this._legMs);
    return new Promise(res => {
      const self = this; let fini = false, t = null;
      const tic = () => { if (fini) return; const reste = cible - temps(); if (reste <= 0) fin(); else t = setTimeout(tic, pauseDebut != null ? 120 : Math.min(reste + 2, 250)); };
      function fin() { if (fini) return; fini = true; clearTimeout(t); self.suivant = null; res(j === self.jeton); }
      if (!FILM) this.suivant = fin;
      tic();
    });
  },
  ok(j) { return j === this.jeton; },

  /* ---------- la caméra ----------
     Sur le cosmos, la légende occupe le bas de l'écran : la caméra cadre tout le ciel
     (galaxies, frontière et leurs noms) dans l'espace libre au-dessus d'elle. */
  cadre(serrer) {
    const L = this.el.querySelector("#rLeg"), tx = L.querySelector(".r-texte");
    const fs = parseFloat(getComputedStyle(tx).fontSize) || 26;
    const lignes = portrait() ? 4 : 3;
    const basLeg = innerHeight * .09 + lignes * fs * 1.3 + 30;
    const haut = this.hautEntete() + (portrait() ? 4 : 30), bas = innerHeight - basLeg;
    const R = S * .068, fN = Math.max(10, S * .0135), fS = Math.max(10, S * .0125), rz = S * .047;
    let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
    GAL.forEach((g, i) => {
      const p = cosmosPos(i);
      x0 = Math.min(x0, p.x - Math.max(R, 70)); x1 = Math.max(x1, p.x + Math.max(R, 70));
      y0 = Math.min(y0, p.y - R); y1 = Math.max(y1, p.y + R * .95 + fN + fS + 14);
    });
    FRONT.forEach((f, i) => {
      const p = frontPos(i);
      y0 = Math.min(y0, p.y - rz * .72 - 4); y1 = Math.max(y1, p.y + rz * .72 + 2 * fS + 10);
    });
    let z = Math.min(1, (bas - haut) / (y1 - y0), (innerWidth - 16) / (x1 - x0)) * (serrer || 1);
    const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    return { z, x: -(cx - W / 2) * z, y: (haut + bas) / 2 - H / 2 - (cy - H / 2) * z };
  },
  /* dans une galaxie ou un système : la scène remonte au-dessus de la légende */
  cadreScene(gid) {
    const L = this.el.querySelector("#rLeg"), tx = L.querySelector(".r-texte");
    const fs = parseFloat(getComputedStyle(tx).fontSize) || 26;
    const bas = innerHeight - (innerHeight * .09 + (portrait() ? 5 : 3) * fs * 1.3 + 30);
    const haut = this.hautEntete() + 6;
    const g = byId(gid || state.gal);
    let z = 1;
    if (g) {
      let rmax = 0;
      g.sy.forEach((s, i) => { rmax = Math.max(rmax, sysOrbit(g, i)); });
      const demi = rmax * aplat(.52) + 26;           // orbite la plus large, et le nom de l'étoile dessous
      z = Math.max(.7, Math.min(1, (bas - haut) / (2 * demi)));
    }
    return { z, x: 0, y: Math.min(0, (haut + bas) / 2 - H / 2) };
  },
  /* bas de l'en-tête (nom de l'atlas, boutons) */
  hautEntete() {
    let b = 0;
    for (const e of document.querySelectorAll(".brand,.topright")) { const r = e.getBoundingClientRect(); if (r.height) b = Math.max(b, r.bottom); }
    return b || 48;
  },
  cadrerNiveau() { this.vue(state.level === "cosmos" ? this.cadre() : this.cadreScene(), 0); },
  async vue(c, dur) {
    const a = { z: VZ.z, x: VZ.x, y: VZ.y };
    if (!dur) { VZ.z = c.z; VZ.x = c.x; VZ.y = c.y; return true; }
    return this.anime(dur, k => { VZ.z = a.z + (c.z - a.z) * k; VZ.x = a.x + (c.x - a.x) * k; VZ.y = a.y + (c.y - a.y) * k; });
  },
  zoomLibre(z, cx, cy) {
    const wx = (cx - W / 2 - VZ.x) / VZ.z, wy = (cy - H / 2 - VZ.y) / VZ.z;
    VZ.z = z; VZ.x = cx - W / 2 - wx * z; VZ.y = cy - H / 2 - wy * z;
  },
  /* les noms du cosmos ne se posent jamais sous la légende */
  reserves() {
    const t = performance.now();
    if (!this._ent || t - this._ent.t > 400 || t < this._ent.t) {
      this._ent = { t, r: [...document.querySelectorAll(".brand .wordmark,.brand .tag,.topright > *,.trail > *,#panel.open")]
        .map(e => e.getBoundingClientRect()).filter(r => r.width).map(r => ({ x: r.left - 6, y: r.top - 4, w: r.width + 12, h: r.height + 8 })) };
    }
    if (!this.en_cours || !this.el || this.el.hidden) return this._ent.r.slice();
    const L = this.el.querySelector("#rLeg");
    const out = this._ent.r.slice();
    const hud = this.el.querySelector("#rHud");
    for (const n of [hud, L.classList.contains("visible") && L.querySelector("#rSur"), L.classList.contains("visible") && L.querySelector("#rTexte")]) {
      if (!n || !n.textContent.trim()) continue;
      const rg = document.createRange(); rg.selectNodeContents(n);
      for (const r of rg.getClientRects()) out.push({ x: r.left - 14, y: r.top - 8, w: r.width + 28, h: r.height + 14 });
    }
    return out;
  },

  /* ---------- gestes montrés à l'écran ---------- */
  onde(x, y) {
    const o = document.createElement("span");
    o.className = "r-onde"; o.style.left = x + "px"; o.style.top = y + "px";
    this.el.appendChild(o); setTimeout(() => o.remove(), 900);
  },
  doigt(n, x, y, visible) {
    const d = this.el.querySelector(n === 1 ? "#rD1" : "#rD2");
    if (x != null) { d.style.left = x + "px"; d.style.top = y + "px"; }
    d.classList.toggle("visible", !!visible);
  },
  async anime(dur, f) {
    const t0 = temps(), j = this.jeton;
    return new Promise(res => {
      const pas = () => {
        if (j !== this.jeton) return res(false);
        const k = Math.min(1, (temps() - t0) / dur);
        f(lisse(k), k);
        if (k < 1) requestAnimationFrame(pas); else res(true);
      };
      requestAnimationFrame(pas);
    });
  },
  async toucherPoint(x, y) {
    this.doigt(1, x, y, true);
    await attendre(260);
    this.onde(x, y);
    await attendre(200);
    this.doigt(1, x, y, false);
  },
  async toucherElement(sel) {
    const el = typeof sel === "string" ? document.querySelector(sel) : sel;
    if (!el) return null;
    const r = el.getBoundingClientRect();
    await this.toucherPoint(r.left + r.width / 2, r.top + r.height / 2);
    return el;
  },
  /* toucher un astre dessiné sur le cosmos */
  async toucherAstre(type, id) {
    let h = null;
    for (let k = 0; k < 40 && !h; k++) { h = hits.find(x => x.type === type && x.id === id); if (!h) await attendre(50); }
    if (!h) return false;
    await this.toucherPoint(h.x, h.y);
    h = hits.find(x => x.type === type && x.id === id) || h;
    if (type === "gal") { closePanel(); go("galaxy", id, null, h.x, h.y, 1); }
    else if (type === "sys") { closePanel(); go("system", state.gal, id, h.x, h.y, 1); }
    else if (type === "pl") openPlanet(state.gal, state.sys, id);
    else if (type === "star") openStar(state.gal, state.sys);
    return true;
  },
  /* deux doigts qui s'écartent ou se rapprochent : le cosmos suit */
  async pincer(zFin, dur, cx, cy) {
    const z0 = VZ.z, ecart0 = zFin > z0 ? 34 : 120, ecart1 = zFin > z0 ? 120 : 34;
    this.doigt(1, cx - ecart0, cy - ecart0 * .6, true); this.doigt(2, cx + ecart0, cy + ecart0 * .6, true);
    await attendre(220);
    await this.anime(dur, k => {
      const e = ecart0 + (ecart1 - ecart0) * k;
      this.doigt(1, cx - e, cy - e * .6, true); this.doigt(2, cx + e, cy + e * .6, true);
      this.zoomLibre(z0 + (zFin - z0) * k, cx, cy);
    });
    await attendre(160);
    this.doigt(1, null, null, false); this.doigt(2, null, null, false);
  },
  async glisser(dx, dy, dur) {
    const x0 = VZ.x, y0 = VZ.y, cx = innerWidth / 2, cy = innerHeight / 2;
    this.doigt(1, cx, cy, true);
    await attendre(200);
    await this.anime(dur, k => { this.doigt(1, cx + dx * k, cy + dy * k, true); A().deplacer(x0 + dx * k, y0 + dy * k); });
    await attendre(120);
    this.doigt(1, null, null, false);
  },
  /* lente dérive de caméra pendant qu'on lit */
  derive(facteur, dur) {
    const z0 = VZ.z, cx = W / 2 + VZ.x, cy = H / 2 + VZ.y;
    this.anime(dur, (k, lin) => this.zoomLibre(z0 * (1 + (facteur - 1) * lin), cx, cy));
  },
  /* saut vers une autre galaxie : aspiration, puis accélération */
  async sauter(gid) {
    closePanel(); this.vue(this.cadreScene(gid), 0);
    evt("saut");
    if (A().son) A().son.effet("trou");
    state.warp = { t0: performance.now(), gid, sid: null, pid: null, bascule: false };
    refreshHUD();
    await attendre(REDUCED ? 50 : 1700);
  },
  async ecrire(champ, texte) {
    for (const ch of texte) {
      champ.value += ch;
      champ.dispatchEvent(new Event("input", { bubbles: true }));
      await attendre(115);
    }
  },
  async defiler(el, haut, dur) {
    const y0 = el.scrollTop;
    await this.anime(dur, k => { el.scrollTop = y0 + (haut - y0) * k; });
  },
  carte(html, classe) {
    const c = this.el.querySelector("#rCarte");
    if (!html) { c.classList.remove("visible"); setTimeout(() => { if (!c.classList.contains("visible")) c.hidden = true; }, 600); return c; }
    c.className = "r-carte " + (classe || "");
    c.innerHTML = html; c.hidden = false;
    this._legT = temps(); this._legMs = lecture(html);
    void c.offsetWidth;
    c.classList.add("visible");
    return c;
  },

  /* ============================================================
     LE RÉCIT
     ============================================================ */
  async lancer(rejouer) {
    if (window.GALAPSY_AUDIO && GALAPSY_AUDIO.actif()) return;
    this.construire();
    const j = ++this.jeton;
    this.basculerPause(false);
    this.en_cours = true;
    const el = this.el;
    el.hidden = false;
    el.classList.remove("transparent", "prelude", "fini");
    document.body.classList.add("en-recit");
    if (FILM) document.body.classList.add("en-film");
    this.carte(null);
    const porte = !!document.getElementById("gate");
    const N = GAL.length;
    const etapes = [];
    const b = (f) => etapes.push(f);
    const escale = (g) => {
      const i = GAL.indexOf(g) + 1;
      this.hud(Lf("cap · escale {i}/{n} · {g} · sonde active", { i: deux(i), n: deux(N), g: g.n.toLowerCase() }));
      this.legende(Lf("escale {i} · {g}", { i, g: g.n }), esc(g.th));
    };

    // 1. journal de bord
    if (porte && !rejouer) b(async () => {
      el.classList.add("prelude");
      this.hud("");
      this.legende("journal de bord", T("recit.prelude"));
      await this.pause(4800);
      el.classList.remove("prelude");
    });
    // 2. la question, puis le Big Bang
    if (porte) b(async () => {
      this.hud("cap · singularité · vitesse 0 · sonde prête");
      this.legende("", "");
      this.vue(this.cadre(.95), 0);
      if (FILM) {
        await this.pause(6500);
        await this.toucherElement("#ignite");
        document.getElementById("ignite").click();
      } else {
        el.classList.add("transparent");
        this.legende("t = 0", T("recit.porte"));
        await new Promise(res => {
          const bt = document.getElementById("ignite");
          const fin = () => { if (bt) bt.removeEventListener("click", fin); this._annuler = null; res(); };
          if (bt) bt.addEventListener("click", fin); else fin();
          this.suivant = null; this._annuler = fin;
        });
        el.classList.remove("transparent");
      }
      if (!this.ok(j)) return;
      evt("bigbang");
      this.hud("cap · première dispersion");
      this.legende("première dispersion", T("recit.dispersion"));
      this.vue(this.cadre(), 7000);
      await this.pause(7600);
    });
    // 3. le relevé
    b(async () => {
      if (disp.hidden) openDisp();
      this.hud("relevé de la première dispersion");
      this.legende("le relevé", T("recit.releve"));
      const zone = document.querySelector("#disp .disp-scroll");
      await attendre(1200);
      if (zone) await this.defiler(zone, Math.min(zone.scrollHeight - zone.clientHeight, 520), 4200);
      await this.pause(1400);
      if (zone) zone.scrollTop = 0;
    });
    // 4. le cosmos et ses galaxies
    b(async () => {
      disp.hidden = true; closePanel();
      if (state.level !== "cosmos") { state.level = "cosmos"; state.gal = null; state.sys = null; }
      this.hud(Lf("cap · cosmos · {n} galaxies relevées", { n: (window.LNB || NB)[N] || N }));
      this.legende("les galaxies", T("recit.galaxies"));
      this.vue(this.cadre(), 900).then(ok => ok && this.vue(this.cadre(.965), 6800));
      await this.pause(8200);
    });
    // 5. naviguer : deux doigts, glisser
    b(async () => {
      this.hud("navigation · zoom");
      this.legende("navigation", T("recit.zoom"));
      await this.vue(this.cadre(), 500);
      const g = byId("hist"), i = GAL.indexOf(g), p = vzPos(cosmosPos(i));
      await this.pincer(2.3, 1900, p.x, p.y);
      await attendre(500);
      await this.glisser(-innerWidth * .12, innerHeight * .06, 1500);
      await attendre(400);
      const c = this.cadre();
      await this.pincer(c.z, 1600, innerWidth / 2, innerHeight / 2);
      await this.vue(c, 700);
      await this.pause(900);
    });
    // 6. escale 1 : entrer dans une galaxie
    b(async () => {
      this.legende("", "");
      await this.vue(this.cadreScene("hist"), 800);
      await this.toucherAstre("gal", "hist");
      await attendre(800);
      escale(byId("hist"));
      await this.pause(8200);
    });
    // 7. les étoiles
    b(async () => {
      this.legende("les étoiles", T("recit.etoiles"));
      await this.pause(6800);
    });
    // 8. planètes et satellites
    b(async () => {
      this.legende("", "");
      await this.toucherAstre("sys", "alien");
      await attendre(700);
      this.hud("cap · escale 01 · l'aliénisme · orbite basse");
      this.legende("planètes et satellites", T("recit.planetes"));
      await this.pause(7600);
    });
    // 9. la fiche
    b(async () => {
      this.legende("", "");
      await this.toucherAstre("pl", "moral");
      await attendre(500);
      panelBody.scrollTop = 0;
      this.legende("la fiche", T("recit.fiche"));
      await attendre(2600);
      const st = panelBody.querySelector(".strata");
      if (st) await this.defiler(panelBody, Math.max(0, st.offsetTop - 30), 1600);
      await this.pause(4400);
    });
    // 10. les satellites et leurs couleurs
    b(async () => {
      const lunes = panelBody.querySelector(".moons");
      if (lunes) await this.defiler(panelBody, Math.max(0, lunes.offsetTop - 140), 1800);
      this.legende("les satellites", T("recit.satellites"));
      await this.pause(8600);
    });
    // 11. une étoile instable
    b(async () => {
      closePanel(); this.legende("", "");
      go("galaxy", "hist", null, innerWidth / 2, innerHeight / 2, -1);
      await attendre(900);
      await this.toucherAstre("sys", "hyst");
      await attendre(800);
      await this.toucherAstre("star", "hyst");
      await attendre(500);
      this.hud("alerte · étoile instable · l'hystérie");
      this.legende("étoile instable", T("recit.instable"));
      await this.pause(6400);
    });
    // 12. la supernova
    b(async () => {
      const s = sysById("hist", "hyst");
      if (s && s.nova && !s._done) {
        this.legende("", "");
        const bt = await this.toucherElement("#novaBtn");
        this.novaVisite = { gal: "hist", sys: "hyst" };
        evt("nova");
        if (bt) bt.click();
        await attendre(REDUCED ? 300 : 3100);
      }
      const noms = s && s.nova ? s.nova.gen.map(x => x.n) : [];
      const liste = noms.length > 1 ? noms.slice(0, -1).join(", ") + window.L(" et ") + noms[noms.length - 1] : noms.join("");
      this.hud("supernova · quatre héritiers");
      this.legende("supernova", T("recit.heritiers").replace("{heritiers}", esc(liste.toLowerCase())));
      await this.pause(8200);
    });
    // 13. le trou de ver
    b(async () => {
      this.legende("", "");
      await this.toucherAstre("sys", "krae");
      await attendre(800);
      await this.toucherAstre("pl", "schizo");
      await attendre(600);
      const saut = panelBody.querySelector(".jump");
      if (saut) panelBody.scrollTo({ top: Math.max(0, saut.offsetTop - 200) });
      this.hud("trou de ver · trois passages");
      this.legende("trou de ver", T("recit.trou"));
      await this.pause(6600);
      if (saut) {
        this.legende("", "");
        await this.toucherElement(saut);
        evt("trou");
        saut.click();
        await attendre(2000);
      }
    });
    // 14. escale 2, atteinte par le trou de ver
    b(async () => {
      escale(byId(state.gal) || byId("pheno"));
      await this.pause(8000);
    });
    // 15. les autres escales
    const deja = new Set(["hist"]);
    b(async () => {
      deja.add(state.gal);
      closePanel();
      this.legende("les escales", T("recit.escales"));
      await this.pause(3800);
    });
    GAL.forEach(g => b(async () => {
      if (deja.has(g.id)) return;
      this.legende("", "");
      this.hud("saut · vitesse lumière");
      await this.sauter(g.id);
      if (!this.ok(j)) return;
      escale(g);
      this.derive(portrait() ? 1.05 : 1.1, 6400);
      await this.pause(6900);
    }));
    // 16. la constellation
    b(async () => {
      this.legende("", "");
      await attendre(600);
      openConst();
      this.hud("journal de bord · constellation");
      this.legende("constellation", T("recit.constellation"));
      await this.pause(6400);
      this.legende("", "");
      await attendre(500);
      closeConst();
    });
    // 17. la frontière
    b(async () => {
      closePanel();
      go("cosmos", null, null, innerWidth / 2, innerHeight / 2, -1);
      await attendre(800);
      this.hud("cap · frontière · zones non cartographiées");
      this.legende("frontière", T("recit.frontiere"));
      window.GALAPSY_FRONTIERE = true;        // les six régions d'abord : c'est d'elles qu'on parle
      this.vue(this.cadre(), 1600);
      await this.pause(6800);
      window.GALAPSY_FRONTIERE = false;
    });
    // 18. la recherche
    b(async () => {
      this.legende("", "");
      await this.toucherElement("#btnCherche");
      const c = A().ouvrirRecherche("");
      const champ = c && c.querySelector("#aQ");
      if (champ) champ.blur();
      this.hud("atelier · recherche");
      this.legende("recherche", T("recit.recherche"));
      await attendre(900);
      if (champ) await this.ecrire(champ, "trauma");
      await this.pause(5200);
    });
    // 19. la création
    b(async () => {
      const c = document.querySelector(".a-feuille:not([hidden])");
      const bt = c && c.querySelector("#aCreationBtn");
      if (bt) {
        const champ = c.querySelector("#aQ");
        if (champ) { champ.value = ""; champ.dispatchEvent(new Event("input", { bubbles: true })); }
        await this.toucherElement(bt);
        bt.click();
      }
      this.hud("atelier · création");
      this.posFeuille = "haut";               // la liste des quatre types et sa règle restent entièrement visibles
      this.legende("création", T("recit.creation"));
      const types = c ? [...c.querySelectorAll(".a-type-creation")] : [];
      for (const t of types) {
        t.classList.add("surbrillance");
        await this.pause(2300);
        t.classList.remove("surbrillance");
      }
      await this.pause(1200);
      this.posFeuille = null;
    });
    // 20. les règles de la communauté
    b(async () => {
      this.legende("", "");
      await attendre(450);
      A().fermerFeuille();
      this.hud("charte · règles de la communauté");
      this.carte(`<p class="r-carte-sur">charte des contributeurs</p>
        <h2>${T("recit.regles_titre")}</h2>
        <ol class="r-regles">${[1, 2, 3, 4].map(k => `<li><span>${deux(k)}</span><p>${T("recit.regle" + k)}</p></li>`).join("")}</ol>
        <p class="r-pied">${T("recit.regles_pied")}</p>`, "r-regles-carte");
      evt("carte");
      await this.pause(12500);
    });
    // 21. gratuité et mode audio
    b(async () => {
      this.carte(`<p class="r-carte-sur">une application entièrement gratuite</p>
        <p class="r-grand">${T("recit.gratuite")}</p>
        <p class="r-moyen">${T("recit.audio")}</p>`, "r-gratuite-carte");
      evt("carte");
      await this.pause(8600);
    });
    // 22. fin
    b(async () => {
      this.carte(null);
      this.hud("");
      if (state.level === "cosmos") this.vue(this.cadre(), 600).then(ok => ok && this.vue(this.cadre(.92), 9000));
      this.legende("expansion", T("recit.expansion"));
      await this.pause(4200);
      this.legende("", "");
      el.classList.add("fini");
      this.carte(`<h2 class="wordmark">galapsy<span class="prime">′</span></h2>
        <p class="a-tag">atlas cosmique des savoirs psy</p>
        ${FILM ? "" : `<p class="r-fin">${T("recit.fin")}</p><button class="ignite" type="button" id="rExplorer">Explorer l'atlas</button>`}
        <p class="a-credit">une création d'<b>impulsion46</b></p>`, "r-fin-carte");
      evt("fin");
      const ex = el.querySelector("#rExplorer");
      if (ex) ex.onclick = ev => { ev.stopPropagation(); this.terminer(); };
      this.points(etapes.length, etapes.length);
      if (FILM) { await attendre(6500); window.__filmFini = true; }
      else await new Promise(() => { });
    });

    for (let i = 0; i < etapes.length && this.ok(j); i++) {
      this.points(etapes.length, i);
      await etapes[i]();
    }
  },

  terminer() {
    this.jeton++;
    window.GALAPSY_FRONTIERE = false;
    this.posFeuille = null;
    this.basculerPause(false);
    this.suivant = null;
    if (this._annuler) { const a = this._annuler; this._annuler = null; try { a(); } catch (e) { } }
    ecrire(CLE_INTRO, "vue");
    document.body.classList.remove("en-recit");
    this.en_cours = false;
    if (!this.el) return;
    this.el.hidden = true;
    this.el.classList.remove("prelude", "transparent", "fini");
    this.carte(null);
    this.doigt(1, null, null, false); this.doigt(2, null, null, false);
    if (!document.getElementById("gate")) {
      // le lecteur repart d'un cosmos intact : sa constellation et la supernova restent à découvrir
      state.nova = null; state.warp = null;
      if (this.novaVisite) {
        const g = byId(this.novaVisite.gal), s = g && g.sy.find(x => x.id === this.novaVisite.sys);
        if (s && s.nova && s._done) {
          s._done = false;
          for (let k = g.sy.length - 1; k >= 0; k--) if (s.nova.gen.includes(g.sy[k])) g.sy.splice(k, 1);
        }
        this.novaVisite = null;
      }
      closePanel(); disp.hidden = true; closeConst(); A().fermerFeuille();
      A().recentrer();
      if (state.level !== "cosmos") go("cosmos", null, null, innerWidth / 2, innerHeight / 2, -1);
      state.journal.length = 0;
      refreshHUD();
    }
  }
};

window.GALAPSY_RECIT = recit;
window.GALAPSY_RESERVES = () => recit.reserves();
if (A()) A().visite = recit;
const forcer = FILM || /[?&]intro\b/.test(location.search) || window.GALAPSY_APERCU === true;
if (forcer || (lire(CLE_INTRO) !== "vue" && document.getElementById("gate"))) setTimeout(() => recit.lancer(false), FILM ? 0 : 250);
})();
