/* Galapsy — service worker
   Rend l'atlas utilisable hors ligne après une première visite.
   Pour publier une mise à jour du contenu, il suffit de redéployer index.html :
   la page est toujours redemandée au réseau en premier.
   Changer VERSION seulement si les icônes ou le manifeste changent. */

const VERSION = "galapsy-v8";
const FONTS = "galapsy-polices";
const CORE = [
  "./",
  "manifest.webmanifest",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/maskable-512.png",
  "icons/apple-touch-icon.png",
  "icons/favicon-32.png",
  "confidentialite.html",
  "langue.js?v=8",
  "langue-en.js?v=8",
  "contrib.js?v=8",
  "contrib.css?v=8",
  "atlas.js?v=8",
  "audio.js?v=8",
  "recit.js?v=8",
  "atlas.css?v=8",
  "config.js?v=8",
  "polices/polices.css?v=8"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(VERSION).then((cache) => cache.addAll(CORE)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION && k !== FONTS).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  if (req.mode === "navigate") {
    event.respondWith(page(event));
  } else if (url.origin === self.location.origin && /\/(icons|polices|voix)\//.test(url.pathname)) {
    event.respondWith(cacheFirst(req));
  } else if (url.origin === self.location.origin) {
    event.respondWith(fraisEnFond(event));
  } else if (url.hostname === "fonts.googleapis.com" || url.hostname === "fonts.gstatic.com") {
    event.respondWith(fonts(event));
  }
});

/* Page : réseau d'abord (contenu toujours à jour), copie locale si hors ligne ou réseau trop lent. */
async function page(event) {
  const cache = await caches.open(VERSION);
  const network = fetch(event.request).then((res) => {
    if (res.ok && !res.redirected) cache.put("./", res.clone());
    return res;
  });
  event.waitUntil(network.catch(() => {}));
  const slow = new Promise((resolve) => setTimeout(resolve, 4000));
  try {
    const res = await Promise.race([network, slow]);
    if (res) return res;
  } catch (e) { /* hors ligne */ }
  const cached = await cache.match("./");
  return cached || network;
}

/* Icônes et fichiers fixes : copie locale d'abord. */
async function cacheFirst(req) {
  const cache = await caches.open(VERSION);
  const cached = await cache.match(req);
  if (cached) return cached;
  const res = await fetch(req);
  if (res.ok) cache.put(req, res.clone());
  return res;
}

/* Polices : copie locale immédiate, rafraîchie en arrière-plan. */
async function fonts(event) {
  const cache = await caches.open(FONTS);
  const cached = await cache.match(event.request);
  const network = fetch(event.request).then((res) => {
    if (res.ok || res.type === "opaque") cache.put(event.request, res.clone());
    return res;
  });
  event.waitUntil(network.catch(() => {}));
  return cached || network;
}

/* Scripts et styles : copie locale immédiate, mise à jour en arrière-plan. */
async function fraisEnFond(event) {
  const cache = await caches.open(VERSION);
  const cached = await cache.match(event.request);
  const network = fetch(event.request).then((res) => {
    if (res.ok) cache.put(event.request, res.clone());
    return res;
  });
  event.waitUntil(network.catch(() => {}));
  return cached || network;
}
